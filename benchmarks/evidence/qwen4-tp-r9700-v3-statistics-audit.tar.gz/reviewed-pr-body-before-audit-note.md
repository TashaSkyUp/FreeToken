Qwen3.8-Flash-Next at the tested upstream base (`14119b8`) rejects TP>1.
This downstream draft adapts the intermediate-axis sharding from
[#385](https://github.com/FlashML-org/FreeToken/pull/385) and adds opt-in precision
settings for two R9700s. NVFP4 expert rows/columns are sharded with their scale
geometry; fixed K tiles use FP64 between tiles and through expert/TP reductions;
attention and per-head normalization use layouts selected from unsharded head counts.

**Completed validation:** tensor parallelism at TP=1 and TP=2 on two R9700s, with the audited 100-prompt matrix, a 1,024-token limit, 440 inference responses and 400 blinded evaluations.

TP denotes GPU tensor parallelism throughout this PR. All recorded runs had multi-token prediction (MTP) and speculative decoding disabled. TP=4 and MTP remain untested.

This is an AI-assisted draft in the user's fork for human review. Related:
[#62](https://github.com/FlashML-org/FreeToken/issues/62) and
[AMD roadmap #541](https://github.com/FlashML-org/FreeToken/issues/541).

### Audited 1,024-token reproduction

The full matrix uses **100 distinct prompts**, ten per category, plus ten cache
repeats per configuration: **440 inference responses**. V1 is the original five-flag
profile; V2 adds FP64 reductions and stable attention. Both TP modes use the same
profile for each cross-TP comparison. Every configuration uses cleaned source
`4aed3f5c7ae3054fb3813de304ef2b820c804642`; all 503 Python engine hashes agree.
No engine code changed in this evidence follow-up.

| Measurement | V1 | V2 |
| --- | ---: | ---: |
| Exact TP=1/TP=2 core text pairs | 77/100 | 100/100 |
| Strict checks, TP=1 | 38/42 | 38/42 |
| Strict checks, TP=2 | 38/42 | 38/42 |
| Capped core responses, TP1 + TP2 | 0/200 | 0/200 |

All core requests report zero cached input. Output agreement is separate from
correctness: common arithmetic/counting errors remain. V2 also changes TP=1
arithmetic, so its cross-TP agreement does not prove a general answer-quality gain.

A fresh-context agent audited the prompts without outputs or keys; a second audited
the exact decoded user turns. Ambiguous contracts and a formula shortcut were fixed.
All 100 final inputs round-trip through the checkpoint tokenizer exactly. One answer
key is corrected: the historical Unicode-copy test expected NFD while its tokenizer
input was NFC. The old reported 35/42 and 34/42 become 35/41 and 34/41 valid cases;
old archives are preserved. The new cohort has an NFC-stable payload, 41 unchanged
keys and one explicit correction. New prompts/cap/rubric require within-cohort comparisons.

### Blinded quality and time measurements

Two comparisons use `codex exec`, `gpt-6.1-terra`, `max` reasoning, at most 20
concurrent calls: V1 TP1 versus V2 TP1, and V2 TP1 versus V2 TP2. Each has 100
forward evaluations, then 100 with reversed submission and A/B order. Judges see
only requests, delivered texts and finish reasons. The independently audited rubric
separates correctness from format/completeness and semantic similarity.

| Comparison | Correctness, left / right | Instruction/completeness, left / right | Semantic similarity |
| --- | ---: | ---: | ---: |
| V1 TP1 / V2 TP1 | 3.595 / 3.605 | 3.970 / 3.970 | 3.755 |
| V2 TP1 / V2 TP2 | 3.630 / 3.630 | 3.965 / 3.965 | 4.000 |

Accepted judgments / actual CLI calls / identical-output control errors: profile-quality: 200/200/0; tp-quality: 200/200/0.
Ratings are secondary evidence; one judgment per order confounds order effects with judge variance.

The 60 short prompts with identical text, token count and finish reason in all four configurations give:

| Configuration | Median TTFT, s | Median request, s | Median decode, ms/token | Median decode, tok/s |
| --- | ---: | ---: | ---: | ---: |
| V1-TP1 | 11.133 | 12.004 | 75.746 | 13.203 |
| V1-TP2 | 5.819 | 6.512 | 54.775 | 18.257 |
| V2-TP1 | 11.134 | 12.027 | 78.929 | 12.673 |
| V2-TP2 | 5.825 | 6.550 | 59.179 | 16.898 |

This is one sequential pass, ordered V2 TP2, V1 TP2, V1 TP1, V2 TP1, with existing
disk/JIT caches and no timed warmup phase. Startup, long-input, cache-hit and SSE
delivery measurements are retained separately, including p95 distributions.
Auto expert cache residency differs between TP modes and is part of the observed speed.
This is not a confidence interval or isolated communication-scaling measurement.

### Hardware, reproduction and checks

2 x Radeon AI PRO R9700 32 GiB, gfx1201; Ryzen 9 3900X; 109.375 GiB visible RAM;
Ubuntu 24.04.4 / Linux 7.0.14-12-pve; Python 3.12.3; Torch 2.14.1+rocm7.2;
HIP 7.2.53211; ROCm SDK 7.2.3; triton-rocm 3.8.0. Communication is torch.distributed
with task-local RCCL 2.27.7 and `--disable-pynccl`; an extra RX 9070 XT is excluded.
Checkpoint: [RadixArk/Qwen3.8-Flash-Next-NVFP4](https://huggingface.co/RadixArk/Qwen3.8-Flash-Next-NVFP4),
revision `7b719225242aacd3dbd3f9407468c2ee9a9d2594`.

Exact matrix controller command (scratch harness and dependencies are in the archive):

```bash
source /root/experiments/FreeToken/.local-build/activate-rocm.sh
cd /root/experiments/FreeToken/.local-build/qwen38-repro/prompt-audit-v3-nfc
/root/experiments/FreeToken/.venv/bin/python run_inference.py
```

Requests use chat-templated `/v1/completions`, `enable_thinking=False`, an empty
closed think block, temperature=0, top_k=1, top_p=1, no penalties and max_tokens=1024.
All 69 existing targeted checks pass: 54 config/weight and 15 precision-path checks.
Actual commands/logs are retained; no maintained test file or tolerance was added.
All seven switches remain disabled by default. Other checkpoints, hardware,
communication backends and TP degrees remain unqualified.

[Exact server command, methodology and historical evidence](https://github.com/TashaSkyUp/FreeToken/blob/draft/qwen4-tp-precision-r9700/docs/qwen4-exp-tp-r9700.md) and the
[hashed v3 evidence archive](https://github.com/TashaSkyUp/FreeToken/blob/draft/qwen4-tp-precision-r9700/benchmarks/evidence/qwen4-tp-r9700-v3.tar.gz) preserve all prompts, audits, 440 responses,
400 accepted judgments, invocation receipts, failure catalogs, timing/resource data,
tests and source/library hashes. Weights, credentials and raw Codex CLI events are omitted.

