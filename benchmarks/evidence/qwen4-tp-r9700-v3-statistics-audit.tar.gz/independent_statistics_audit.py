"""Recompute published v3 statistics without importing the reporting helpers."""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import math
import re
import tarfile
import unicodedata
import numpy as np

ROOT = Path(__file__).resolve().parent
TREE = Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-pr')
ARCHIVE = TREE/'benchmarks/evidence/qwen4-tp-r9700-v3.tar.gz'
problems = []
checked = Counter()

def read(path):
    return json.loads(Path(path).read_text())

def lines(path):
    return [json.loads(s) for s in Path(path).read_text().splitlines() if s.strip()]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify(condition, where):
    checked[where.split('/')[0]] += 1
    if not condition:
        problems.append(where)

def compare(actual, expected, where):
    if isinstance(expected, dict):
        for key, value in expected.items():
            compare(actual[key], value, where+'/'+key)
    elif isinstance(expected, (float, int)) and not isinstance(expected, bool):
        verify(isinstance(actual, (float, int)) and math.isclose(actual, expected, rel_tol=1e-10, abs_tol=1e-10), where)
    else:
        verify(actual == expected, where)

def dist(values):
    a = np.array([v for v in values if v is not None], dtype=float)
    if not len(a):
        return {'n': 0}
    out = dict(n=len(a), mean=float(a.mean()), min=float(a.min()), max=float(a.max()))
    out.update({f'p{q}': float(np.percentile(a, q, method='linear')) for q in (50,90,95,99)})
    return out

def json_value_equal(left, right):
    try:
        x, y = json.loads(left), json.loads(right)
    except ValueError:
        return False
    return isinstance(x, (dict,list)) and isinstance(y, (dict,list)) and json.dumps(x,sort_keys=True,ensure_ascii=False) == json.dumps(y,sort_keys=True,ensure_ascii=False)

def fixed(prompt, text):
    expected, actual = prompt['expected'], text.strip()
    if expected is None:
        return None
    if isinstance(expected, (dict,list)):
        return json_value_equal(actual, json.dumps(expected,ensure_ascii=False))
    if prompt['name'] == 'weighted-average':
        if not re.fullmatch(r'[+-]?(?:(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|\d+/\d+)',actual,flags=re.ASCII):
            return False
        try:
            return Fraction(actual) == Fraction(expected)
        except (ValueError,ZeroDivisionError):
            return False
    return actual == expected

def perf(rows):
    multi = [r for r in rows if r['usage']['completion_tokens'] > 1]
    return dict(requests=len(rows),completion_tokens=sum(r['usage']['completion_tokens'] for r in rows),
        total_client_request_seconds=sum(r['wall_seconds'] for r in rows),
        ttft_seconds=dist([r['ttft_seconds'] for r in rows]),response_seconds=dist([r['wall_seconds'] for r in rows]),
        engine_decode_ms_per_token=dist([r['timings']['predicted_per_token_ms'] for r in multi]),
        engine_decode_tokens_per_second=dist([r['timings']['predicted_per_second'] for r in multi]),
        client_decode_tokens_per_second=dist([r['decode_tokens_per_second'] for r in multi]),
        engine_queue_ms=dist([r['timings']['queue_ms'] for r in rows]),cache_tokens=dist([r['cache_n'] for r in rows]),
        finish_reasons=dict(Counter(r['finish_reason'] for r in rows)))

manifest = read(ROOT/'manifest.json')
published = read(ROOT/'cohort-summary.json')
prompts = read(ROOT/'prompts.json')
by_name = {p['name']:p for p in prompts}
verify(len(prompts) == len(by_name) == 100, 'inputs/distinct-prompts')
verify(sha((ROOT/'prompts.json').read_bytes()) == manifest['prompts_sha256'], 'inputs/frozen-prompts-hash')
verify(sha((ROOT/'actual-user-turns-blind.json').read_bytes()) == manifest['independently_reviewed_user_turns_sha256'], 'inputs/frozen-user-turns-hash')
verify(Counter(p['category'] for p in prompts) == manifest['categories'], 'inputs/categories')
verify(all(unicodedata.normalize('NFC',p['user_text']) == p['user_text'] for p in prompts), 'inputs/nfc')
verify(sum(p['expected'] is not None for p in prompts) == 42, 'inputs/fixed-key-count')
verify(sum(p['cache_probe'] for p in prompts) == 10, 'inputs/cache-probe-count')
critical_keys={'fraction-sum':str(Fraction(5,12)+Fraction(7,18)),
    'modular-power':str(pow(7,8,13)),
    'weighted-average':str(Fraction(10*4+20*7+30*10,60)),
    'quoted-instruction':str(len(re.findall(r'<data>([^<>]*)</data>',by_name['quoted-instruction']['user_text'])[-1].split()))}
verify(all(by_name[n]['expected']==v for n,v in critical_keys.items()),'inputs/four-shared-failure-answer-keys')
labels = ['v1-tp1','v1-tp2','v2-tp1','v2-tp2']
rows = {k:lines(ROOT/f'inference/{k}-responses.jsonl') for k in labels}
core = {k:{r['name']:r for r in v if r['kind']=='core'} for k,v in rows.items()}
common = [p['name'] for p in prompts if p['category'] != 'long-context' and len({(core[k][p['name']]['text'],core[k][p['name']]['finish_reason'],core[k][p['name']]['usage']['completion_tokens']) for k in labels}) == 1]
verify(common == published['same_outputs_all_four_short'], 'timing/common-output-membership')
configs, settings_all, sse_count = {}, {}, 0
for label in labels:
    values, cold = rows[label], core[label]
    repeats = [r for r in values if r['kind']=='cache-repeat']
    verify(Counter(r['kind'] for r in values) == {'core':100,'cache-repeat':10}, 'inference/'+label+'/population')
    verify(set(cold) == set(by_name), 'inference/'+label+'/unique-core')
    verify({r['name'] for r in repeats} == {p['name'] for p in prompts if p['cache_probe']}, 'inference/'+label+'/repeat-membership')
    for row in values:
        p = by_name[row['name']]
        loc = 'inference/'+label+'/'+row['kind']+'/'+row['name']
        verify(row['prompt_sha256'] == p['sha256'] == sha(p['prompt'].encode()), loc+'/prompt-hash')
        verify(row['usage']['prompt_tokens'] == p['tokens'] == len(p['input_ids']), loc+'/prompt-tokens')
        verify(row['max_tokens'] == 1024 and row['usage']['completion_tokens'] <= 1024, loc+'/cap')
        verify(row['finish_reason']=='stop' and row['sse_done'], loc+'/finish')
        verify(sha(row['text'].encode()) == row['text_sha256'], loc+'/text-hash')
        raw = read(ROOT/'inference/sse'/row['sse_delivery_file'])
        chunks, usage, timing, finish_reason, first, done = [],None,None,None,None,False
        for e in raw['events']:
            line = e['line'].strip()
            if line == 'data: [DONE]':
                done = True
            elif line.startswith('data: '):
                payload=json.loads(line[6:])
                for choice in payload.get('choices',[]):
                    text=choice.get('text','')
                    if text and first is None:
                        first=e['seconds']
                    chunks.append(text)
                    finish_reason=choice.get('finish_reason') or finish_reason
                usage=payload.get('usage',usage)
                timing=payload.get('timings',timing)
        verify(''.join(chunks)==row['text'] and usage==row['usage'] and timing==row['timings'] and finish_reason==row['finish_reason'] and done,loc+'/raw-sse')
        # The SSE observer and request parser take separate perf_counter samples.
        # Inspect agreement within 5 ms; their first-chunk timestamps are not identical.
        verify(abs(first-row['ttft_seconds']) < 0.005 and abs(raw['events'][-1]['seconds']-row['wall_seconds']) < 0.005,loc+'/sse-client-timing')
        sse_count += 1
    settings=read(ROOT/f'inference/{label}-settings.json'); settings_all[label]=settings
    verify(settings['main_sha']=='4aed3f5c7ae3054fb3813de304ef2b820c804642' and len(settings['source_hashes'])==503,'source/'+label+'/identity')
    verify(not settings['tracing'] and not settings['replay'],'source/'+label+'/instrumentation-off')
    wanted={'FREETOKEN_TP_PRECISE','FREETOKEN_GDN_SNAPSHOT_FP32','FREETOKEN_ROUTER_FP32','FREETOKEN_STABLE_LINEAR','FREETOKEN_RESIDUAL_FP32'}
    if label.startswith('v2'): wanted|={'FREETOKEN_TP_REDUCTION_FP64','FREETOKEN_STABLE_ATTENTION'}
    observed={k for k,v in settings['environment'].items() if k.startswith('FREETOKEN_') and v}
    verify(observed==wanted and all(settings['environment'][k]=='1' for k in wanted),'source/'+label+'/precision-profile')
    verify(settings['command'][settings['command'].index('--tp-size')+1]==label[-1],'source/'+label+'/tp-degree')
    log=(ROOT/f'inference/{label}-server.log').read_text()
    verify('speculative_algorithm=None' in log and not any('speculative' in str(x) or 'mtp' in str(x).lower() for x in settings['command']), 'source/'+label+'/mtp-disabled')
    cache=re.findall(r'resolved moe_cache_size=(\d+) num_pages=(\d+)',log)
    verify(len(cache)==1, 'source/'+label+'/resolved-cache')
    passes={p['name']:fixed(p,cold[p['name']]['text']) for p in prompts if p['expected'] is not None}
    configs[label]=dict(core_responses=len(cold),cache_repeat_attempts=len(repeats),fixed_checks=len(passes),fixed_passes=sum(passes.values()),fixed_failures=[n for n,v in passes.items() if not v],
        capped_core=sum(r['finish_reason']=='length' for r in cold.values()),capped_all=sum(r['finish_reason']=='length' for r in values),
        max_completion_tokens=max(r['usage']['completion_tokens'] for r in values),completion_tokens=sum(r['usage']['completion_tokens'] for r in values),
        cache_hits=sum(r['cache_n']>0 for r in repeats),cache_fixed_checks=sum(by_name[r['name']]['expected'] is not None for r in repeats),
        cache_fixed_passes=sum(fixed(by_name[r['name']],r['text']) for r in repeats if by_name[r['name']]['expected'] is not None),
        cold_repeat_exact_matches=sum(r['text']==cold[r['name']]['text'] for r in repeats),
        cold_repeat_exact_or_json_value_matches=sum(r['text']==cold[r['name']]['text'] or json_value_equal(r['text'],cold[r['name']]['text']) for r in repeats),
        startup_to_healthy_seconds=read(ROOT/f'inference/{label}-summary.json')['ready_seconds'],expert_slots_per_rank=int(cache[0][0]),kv_pages=int(cache[0][1]),
        short_uncached=perf([r for r in cold.values() if r['category']!='long-context']),long_uncached=perf([r for r in cold.values() if r['category']=='long-context']),
        cache_hit_requests=perf([r for r in repeats if r['cache_n']>0]),same_outputs_all_four=perf([cold[n] for n in common]),
        all_core_uncached=all(r['cache_n']==0 for r in cold.values()),inference_source_sha=settings['main_sha'])
    compare(configs[label],published['configurations'][label],'statistics/'+label)
verify(all(s['source_hashes']==settings_all[labels[0]]['source_hashes'] for s in settings_all.values()),'source/four-mode-source-equality')
comparisons={}
for name,a,b in [('v1-cross-tp','v1-tp1','v1-tp2'),('v2-cross-tp','v2-tp1','v2-tp2'),('tp1-profile','v1-tp1','v2-tp1')]:
    different=[p['name'] for p in prompts if core[a][p['name']]['text']!=core[b][p['name']]['text']]
    comparisons[name]=dict(left=a,right=b,exact_matches=100-len(different),differing_names=different)
    compare(comparisons[name],published['comparisons'][name],'statistics/'+name)
for tp in (1,2):
    a,b=core[f'v1-tp{tp}'],core[f'v2-tp{tp}']
    costs=dict(identical_output_requests=len(common),response_percent=dist([100*(b[n]['wall_seconds']/a[n]['wall_seconds']-1) for n in common]),
        ttft_percent=dist([100*(b[n]['ttft_seconds']/a[n]['ttft_seconds']-1) for n in common]),
        decode_ms_per_token_percent=dist([100*(b[n]['timings']['predicted_per_token_ms']/a[n]['timings']['predicted_per_token_ms']-1) for n in common if a[n]['usage']['completion_tokens']>1]))
    compare(costs,published['paired_v2_time_cost_percent'][f'tp{tp}'],'timing/paired-cost-tp'+str(tp))
service=lines(ROOT/'inference/service-observations.jsonl')
svc=dict(samples=len(service),busy_samples=sum(bool(r.get('comfy_running') or r.get('comfy_pending')) for r in service),observation_errors=sum('observation_error' in r for r in service))
compare(svc,published['service_observations'],'resources/service')
resource=lines(ROOT/'inference/resource-timeline.jsonl')
for label in labels:
    selected=[r for r in resource if r['state'].get('label')==label]
    rr=dict(samples=len(selected),ram_available_GiB=dist([r['memory']['MemAvailable']/2**30 for r in selected]),host_cpu_cores=dist([r['server'].get('cpu_cores_used_interval') for r in selected]),process_rss_GiB=dist([r['server']['rss_bytes']/2**30 for r in selected]))
    compare(rr,published['resource_summary'][label],'resources/'+label)

quality={}
for kind,aliases in [('profile-quality',{'profile1':'v1-tp1','profile2':'v2-tp1'}),('tp-quality',{'tp1':'v2-tp1','tp2':'v2-tp2'})]:
    qroot=ROOT/'quality'/kind/'terra-max-judgments'; qm=read(qroot/'manifest.json'); summary=read(qroot/'summary.json')
    names=list(aliases); mapped=defaultdict(list); events=[]; controls=0
    result_files=sorted(qroot.glob('forward/*/result.json'))+sorted(qroot.glob('reversed/*/result.json'))
    verify(len(result_files)==200, 'judges/'+kind+'/result-count')
    verify(len(list(qroot.glob('*/*/attempt-*/invocation.json')))==200,'judges/'+kind+'/invocation-count')
    verify(sha((qroot/'rubric.txt').read_bytes())==qm['rubric_sha256'] and sha(json.dumps(read(qroot/'schema.json'),sort_keys=True).encode())==qm['schema_sha256'],'judges/'+kind+'/frozen-rubric-and-schema')
    for f in result_files:
        result=read(f); payload=read(f.parent/'judge-input.json'); invocation=read(f.parent/'attempt-01/invocation.json'); p=by_name[result['sample_name']]
        loc='judges/'+kind+'/'+result['phase']+'/'+p['name']
        verify(result['model']=='gpt-6.1-terra' and result['reasoning_effort']=='max' and result['attempt']==1 and not result['previous_failures'],loc+'/model-and-attempt')
        cmd=invocation['command']
        verify(cmd[cmd.index('--model')+1]=='gpt-6.1-terra' and 'model_reasoning_effort="max"' in cmd and '--ignore-user-config' in cmd and '--ephemeral' in cmd and 'web_search="disabled"' in cmd,loc+'/cli-settings')
        verify(result['judge_input_sha256']==sha(json.dumps(payload,ensure_ascii=False,sort_keys=True).encode()),loc+'/input-hash')
        verify(payload['original_request']==p['user_text'],loc+'/original-request')
        verify(set(payload)=={'original_request','response_A','response_B','generation_limit_note'},loc+'/blind-payload-fields')
        order=names if result['phase']=='forward' else names[::-1]
        verify(result['presentation']==dict(zip(('A','B'),order)),loc+'/presentation')
        for letter,alias in result['presentation'].items():
            src=core[aliases[alias]][p['name']]
            verify(payload['response_'+letter]==dict(text=src['text'],finish_reason=src['finish_reason']),loc+'/source-'+letter)
        same=payload['response_A']['text']==payload['response_B']['text']
        verify(result['identical_source_text']==same,loc+'/identical-flag')
        verify(read(f.parent/'attempt-01/last-message.json')==result['judgment'],loc+'/accepted-last-message')
        scores={}
        for dimension in ('correctness','instruction_following_completeness'):
            d=result['judgment'][dimension]
            scores[dimension]={alias:d[letter.lower()+'_score'] for letter,alias in result['presentation'].items()}
            verify(all(isinstance(s,int) and 0<=s<=4 for s in scores[dimension].values()),loc+'/'+dimension+'/bounds')
            if same:
                verify(d['a_score']==d['b_score'],loc+'/'+dimension+'/identical-control')
        sem=result['judgment']['semantic_similarity']
        if same:
            controls+=1
            verify(sem['score']==4 and sem['difference_kind']=='identical',loc+'/semantic-control')
        mapped[p['name']].append(dict(scores=scores,semantic=sem,identical=same))
        events.extend([(datetime.fromisoformat(result['started_utc']),1),(datetime.fromisoformat(result['completed_utc']),-1)])
    peak=current=0
    for _,change in sorted(events,key=lambda v:(v[0],v[1])):
        current+=change; peak=max(peak,current)
    verify(peak==summary['max_observed_concurrency']==20,'judges/'+kind+'/concurrency')
    accepted=[read(f) for f in result_files]
    verify(max(r['completed_utc'] for r in accepted if r['phase']=='forward') < min(r['started_utc'] for r in accepted if r['phase']=='reversed'),'judges/'+kind+'/forward-completes-before-reverse')
    compare(dict(evaluations=len(result_files),distinct_samples=len(mapped),main_run_cli_invocations=len(result_files)),{k:summary[k] for k in ('evaluations','distinct_samples','main_run_cli_invocations')},'judges/'+kind+'/totals')
    computed={}
    for group,selection in [('all_samples',list(mapped)),('differing_outputs',[n for n,v in mapped.items() if not v[0]['identical']])]:
        total=len(selection); selected=[r for n in selection for r in mapped[n]]
        stats=dict(samples=total,semantic_score_mean=sum(r['semantic']['score'] for r in selected)/len(selected) if selected else None,
            semantic_score_agreement=sum(mapped[n][0]['semantic']['score']==mapped[n][1]['semantic']['score'] for n in selection),
            semantic_kind_agreement=sum(mapped[n][0]['semantic']['difference_kind']==mapped[n][1]['semantic']['difference_kind'] for n in selection),
            semantic_difference_kinds=dict(Counter(r['semantic']['difference_kind'] for r in selected)))
        for dimension in ('correctness','instruction_following_completeness'):
            outcomes=Counter(); flips=0; agree={a:0 for a in names}
            for n in selection:
                pair=[r['scores'][dimension] for r in mapped[n]]
                signs=[int(s[names[1]]>s[names[0]])-int(s[names[1]]<s[names[0]]) for s in pair]
                outcomes[('tie' if signs[0]==0 else names[1]+'_better' if signs[0]>0 else names[0]+'_better') if signs[0]==signs[1] else 'order_sensitive']+=1
                flips+=signs[0]*signs[1]==-1
                for a in names: agree[a]+=pair[0][a]==pair[1][a]
            means={a:sum(r['scores'][dimension][a] for r in selected)/len(selected) if selected else None for a in names}
            stats[dimension]={**{a+'_mean':means[a] for a in names},'mean_'+names[1]+'_minus_'+names[0]:means[names[1]]-means[names[0]] if selected else None,
                'paired_assessable_samples':total,'stable_outcomes':dict(outcomes),'outcome_agreement':total-outcomes['order_sensitive'],
                **{a+'_score_agreement':agree[a] for a in names},'direction_flips':flips}
        compare(stats,summary[group],'judges/'+kind+'/'+group)
        computed[group]=stats
    quality[kind]=dict(evaluations=len(result_files),max_concurrency=peak,identical_control_evaluations=controls,**computed)

archive_hash=sha(ARCHIVE.read_bytes())
with tarfile.open(ARCHIVE) as tar:
    members=tar.getmembers(); ns=[m.name for m in members]
    am=read_data=json.load(tar.extractfile('MANIFEST.json'))
    verify(len(ns)==len(set(ns)),'archive/unique-paths')
    verify(set(ns)==set(am)|{'MANIFEST.json'},'archive/manifest-coverage')
    for m in members:
        verify(m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts,'archive/safe-path/'+m.name)
        if m.name=='MANIFEST.json': continue
        b=tar.extractfile(m).read()
        verify(len(b)==am[m.name]['bytes'] and sha(b)==am[m.name]['sha256'],'archive/payload/'+m.name)
        if m.name.startswith('prompt-audit-v3-nfc/'):
            local=ROOT/m.name.removeprefix('prompt-audit-v3-nfc/')
            # The packager's redirected log was still open when its snapshot was made.
            # Its later completion output is separate from the frozen benchmark evidence.
            if local.is_file() and local.name!='package-controller.log': verify(sha(local.read_bytes())==sha(b),'archive/local-equality/'+m.name)
    verify(not any(PurePosixPath(n).name in {'events.jsonl','auth.json','.env'} or n.endswith(('.safetensors','.gguf','.pt','.pth')) for n in ns),'archive/exclusions')
    engine=settings_all[labels[0]]['source_hashes']
    archived_source=json.load(tar.extractfile('prompt-audit-v3-nfc/final-source-verification.json'))
    verify(archived_source['verified_files']==503 and archived_source['hashes']==engine,'archive/all-503-engine-source-hashes')
    source_tree=Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-fp64')
    verify(all(sha((source_tree/path).read_bytes())==h for path,h in engine.items()),'source/all-503-live-engine-files')

historical={}
old_roots={'v1':ROOT.parent/'validation100','v2':ROOT.parent/'divergence-v2/validation100-fp64'}
old_core={}
for version,base in old_roots.items():
    oldp=read(base/'prompts.json'); oldrows={tp:lines(base/f'tp{tp}-responses.jsonl') for tp in (1,2)}
    old_core[version]={tp:{r['name']:r for r in values if r['kind']=='core'} for tp,values in oldrows.items()}
    oldc=old_core[version]; summary=read(base/'summary.json'); counts={}
    for tp in (1,2):
        def legacy_answer(p,text):
            if p['name']=='ordering': return [v.strip() for v in text.strip().split(',')]==p['expected'].split(',')
            if p['name']=='graph-path': return set(text.strip().splitlines())==set(p['expected'].splitlines())
            return fixed(p,text)
        valid=[p for p in oldp if p['expected'] is not None and p['name']!='unicode-preserve']
        total=sum(legacy_answer(p,oldc[tp][p['name']]['text']) for p in valid)
        verify(total==summary['known_answer_passes'][f'tp{tp}'],'historical/'+version+f'/fixed-tp{tp}')
        repeats=[r for r in oldrows[tp] if r['kind']=='cache-repeat']
        counts[f'tp{tp}']=dict(valid_fixed_passes=total,valid_fixed_total=len(valid),core_capped=sum(r['finish_reason']=='length' for r in oldc[tp].values()),
            cache_hits=sum(r['cache_n']>0 for r in repeats),cold_repeat_exact=sum(r['text']==oldc[tp][r['name']]['text'] for r in repeats))
    matches=sum(oldc[1][p['name']]['text']==oldc[2][p['name']]['text'] for p in oldp)
    verify(matches==summary['exact_core_matches' if version=='v1' else 'after_exact_matches'],'historical/'+version+'/exact-pairs')
    historical[version]=dict(core_exact=matches,configurations=counts)
    if version=='v1':
        short=[p['name'] for p in oldp if p['category']!='long-context' and len({(oldc[tp][p['name']]['text'],oldc[tp][p['name']]['finish_reason'],oldc[tp][p['name']]['usage']['completion_tokens']) for tp in (1,2)})==1]
        for tp in (1,2): compare(perf([oldc[tp][n] for n in short]),summary['performance'][f'tp{tp}']['matched_short'],'historical/v1/matched-short-'+str(tp))
        historical[version]['matched_short_requests']=len(short)
verify(sum(old_core['v1'][1][n]['text']!=old_core['v2'][1][n]['text'] for n in old_core['v1'][1])==35,'historical/v2/tp1-profile-changes')
fresh_root=ROOT.parent/'divergence-v2/fresh-ab'; fresh=read(fresh_root/'summary.json'); fresh_perfs={}
for label in labels:
    timed=[r for r in lines(fresh_root/f'{label}-responses.jsonl') if r['kind']=='timed']
    fresh_perfs[label]=perf(timed)
    compare(fresh_perfs[label],fresh['results'][label]['performance'],'historical/fresh-ab/'+label)
historical['fresh_ab']=fresh_perfs
for tp in (1,2):
    a,b=fresh_perfs[f'v1-tp{tp}'],fresh_perfs[f'v2-tp{tp}']
    for key in ('ttft_seconds','response_seconds','engine_decode_ms_per_token'):
        compare(100*(b[key]['p50']/a[key]['p50']-1),fresh['v2_median_time_cost_percent'][f'tp{tp}'][key],'historical/fresh-cost-'+str(tp)+'/'+key)
main_s=read(ROOT.parent/'pr-draft/main-branch-summary.json')
for old in main_s['summaries']:
    data=lines(ROOT.parent/'pr-draft'/f'{old["label"]}-responses.jsonl'); p=perf(data)
    compare(dict(median_decode_tokens_per_second=p['engine_decode_tokens_per_second']['p50'],median_ttft_seconds=p['ttft_seconds']['p50'],median_response_seconds=p['response_seconds']['p50']),
        {k:old[k] for k in ('median_decode_tokens_per_second','median_ttft_seconds','median_response_seconds')},'historical/main-ab/'+old['label'])
for label,base,aliases in [('v1-tp',ROOT.parent/'validation100/terra-max-judgments',['tp1','tp2']),('v1-v2-profiles',ROOT.parent/'divergence-v2/profile-quality/terra-max-judgments',['profile1','profile2'])]:
    results=[read(p) for phase in ('forward','reversed') for p in sorted((base/phase).glob('*/result.json'))]
    summary=read(base/'summary.json'); means={}
    for dim in ('correctness','instruction_following_completeness'):
        scores=defaultdict(list)
        for result in results:
            for letter,alias in result['presentation'].items(): scores[alias].append(result['judgment'][dim][letter.lower()+'_score'])
        means[dim]={alias:sum(scores[alias])/len(scores[alias]) for alias in aliases}
        for alias in aliases: compare(means[dim][alias],summary['all_samples'][dim][alias+'_mean'],'historical/judges/'+label+'/'+dim+'/'+alias)
    historical[label+'-judge-means']=means

logroot=ROOT.parent/'divergence-v2'; logsummary=read(logroot/'verified-logit-summary.json')
counts={int(r['request_id'].removeprefix('cmpl-')):r['usage']['completion_tokens'] for r in lines(logroot/'stable-tp1-replay-responses.jsonl')}
logit_results={}; bit_equal=0
for name,left,right in [('v1','baseline-tp1','baseline-tp2-replay'),('fp64_only','fp64-tp1-replay','fp64-tp2-replay'),('v2','stable-tp1-replay','stable-tp2-replay')]:
    lf,rf=logroot/(left+'-trace'),logroot/(right+'-trace')
    arows,brows=lines(lf/'tokens.jsonl'),lines(rf/'tokens.jsonl')
    lookup={(r['key'],r['step']):r for r in brows}; rms_squares=[]; kls=[]; disagreements=0
    verify(len(arows)==len(brows)==309,'historical/logits/'+name+'/dispatch-count')
    for arow in arows:
        brow=lookup[(arow['key'],arow['step'])]
        a0,b0=np.load(lf/arow['logits']),np.load(rf/brow['logits'])
        verify(a0.dtype==b0.dtype==np.float32 and a0.shape==b0.shape,'historical/logits/'+name+'/shape-'+str(arow['uid'])+'-'+str(arow['step']))
        if name=='v2': bit_equal+=bool(np.array_equal(a0.view(np.uint32),b0.view(np.uint32)))
        if arow['step']>=counts[arow['uid']]: continue
        a,b=a0.astype(np.float64),b0.astype(np.float64)
        verify(np.isfinite(a).all() and np.isfinite(b).all(),'historical/logits/'+name+'/finite-'+str(arow['uid'])+'-'+str(arow['step']))
        delta=a-b; rms_squares.append(float(np.var(delta)))
        logp=a-np.logaddexp.reduce(a.ravel()); logq=b-np.logaddexp.reduce(b.ravel())
        kls.append(float(np.sum(np.exp(logp)*(logp-logq))))
        disagreements+=int(np.argmax(a)!=np.argmax(b))
    result=dict(visible_positions=len(kls),greedy_disagreements=disagreements,mean_kl_nats=float(np.mean(kls)),centered_logit_rms=float(np.sqrt(np.mean(rms_squares))))
    compare(result,logsummary['stages'][name],'historical/logits/'+name+'/metrics')
    logit_results[name]=result
verify(bit_equal==logsummary['raw_bit_identical_dispatches']==309,'historical/logits/v2/all-raw-fp32-bits')
historical['aligned_logits']=dict(stages=logit_results,raw_bit_identical_v2_dispatches=bit_equal,delivered_positions=len(kls),queued_extra_dispatches=309-len(kls))
probes=read(logroot/'operator-probe.json')
rows6144=[p for p in probes if p['kind']=='bf16_row' and p['shape'][1]==6144]
verify(len(rows6144)==2 and all(1.1e-6<p['baseline']['full_rms_error']<1.3e-6 and 5.7e-8<p['candidate']['full_rms_error']<5.9e-8 and p['candidate']['split_unequal_after_fp32']==0 for p in rows6144),'historical/operators/bf16-published-rounding-and-split')
nv=[p for p in probes if p['kind']=='nvfp4_down_decode']
verify(len(nv)==2 and nv[1]['full_rms_error']<nv[0]['full_rms_error'] and nv[1]['split_unequal_after_fp32']==0,'historical/operators/nvfp4-published-direction-and-split')
historical['operator_record_sha256']=sha((logroot/'operator-probe.json').read_bytes())

tests=read(ROOT/'test-results.json')
verify(all(r['returncode']==0 for r in tests),'tests/recorded-command-results')
test_counts=[]
for name in ('config-weight-tests.log','precision-profile-tests.log'):
    text=(ROOT/name).read_text(); match=re.search(r'(\d+) passed',text)
    verify(match is not None,'tests/'+name+'/pass-count-present'); test_counts.append(int(match[1]))
verify(test_counts==[54,15],'tests/69-recorded-checks')
doc=(TREE/'docs/qwen4-exp-tp-r9700.md').read_text()
body=(ROOT/'pr-body-before-statistics-audit.txt').read_text()
for label in labels:
    p=configs[label]['same_outputs_all_four']
    fields=['ttft_seconds','response_seconds','engine_decode_ms_per_token']
    docline='| '+label.upper()+' | '+' | '.join(f'{p[k]["p50"]:.3f} / {p[k]["p95"]:.3f}' for k in fields)+f' | {p["engine_decode_tokens_per_second"]["p50"]:.3f} |'
    prline='| '+label.upper()+' | '+' | '.join(f'{p[k]["p50"]:.3f}' for k in fields)+f' | {p["engine_decode_tokens_per_second"]["p50"]:.3f} |'
    verify(docline in doc,'published/latest-latency-doc/'+label)
    verify(prline in body,'published/latest-latency-pr/'+label)
for kind,left,right in [('profile-quality','V1 TP1','V2 TP1'),('tp-quality','V2 TP1','V2 TP2')]:
    q=quality[kind]['all_samples']; aliases=['profile1','profile2'] if kind=='profile-quality' else ['tp1','tp2']
    line=f'| {left} / {right} | '+ ' | '.join(' / '.join(f'{q[d][a+"_mean"]:.3f}' for a in aliases) for d in ('correctness','instruction_following_completeness'))+f' | {q["semantic_score_mean"]:.3f} |'
    verify(line in doc and line in body,'published/latest-judge-table/'+kind)
for literal in ('| V1-TP1 | 77/100 | 38/42 | 0/100 | 317 |','| V1-TP2 | 77/100 | 38/42 | 0/100 | 266 |','| V2-TP1 | 100/100 | 38/42 | 0/100 | 615 |','| V2-TP2 | 100/100 | 38/42 | 0/100 | 615 |'):
    verify(literal in doc,'published/latest-count-table/'+literal.split('|')[1].strip())
report=dict(audited_utc=datetime.now(timezone.utc).isoformat(),status='pass' if not problems else 'needs-review',
    method='Independent recomputation from frozen records; no report aggregation helper imported; NumPy linear percentiles.',
    inference_responses=sum(len(v) for v in rows.values()),distinct_prompts=len(prompts),fixed_checks_per_configuration=42,
    configurations=configs,comparisons=comparisons,common_short_prompt_count=len(common),sse_reconstructions=sse_count,
    quality=quality,historical_recomputed=historical,critical_answer_keys=critical_keys,service_observations=svc,recorded_targeted_tests=sum(test_counts),
    archive=dict(file=ARCHIVE.name,sha256=archive_hash,payload_members=len(am),
        snapshot_note='The archived package-controller.log is empty: packaging completion was written after the snapshot. Frozen raw data, manifest and saved completion receipt verify the archive.'),
    source_hashes={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [ROOT/'prompts.json',ROOT/'cohort-summary.json',*sorted((ROOT/'inference').glob('*-responses.jsonl'))]},
    published_document_sha256=sha(doc.encode()),reviewed_pr_body_sha256=sha(body.encode()),
    audit_script_sha256=sha(Path(__file__).read_bytes()),checks_by_area=dict(checked),discrepancies=problems,
    limits=['No new inference or judging calls; this audits the recorded cohort.',
        'Startup duration is traced to the saved controller measurement; no independent wall-clock replay.',
        'Historical text/format totals, published timing tables, mean judge ratings and aligned full-logit metrics were recomputed. Representative operator measurements were traced to saved probe records, not rerun on GPUs.',
        'Independent reference-engine accuracy, MTP and TP=4 are outside this numerical recomputation.',
        'Single sequential performance pass; the matched-output subset is conditional on observed outputs.'])
(ROOT/'independent-statistics-audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(status=report['status'],discrepancies=problems,checks_by_area=dict(checked),archive=report['archive'],sse=sse_count,core_exact={k:v['exact_matches'] for k,v in comparisons.items()},scores={k:v['fixed_passes'] for k,v in configs.items()}),indent=2))
