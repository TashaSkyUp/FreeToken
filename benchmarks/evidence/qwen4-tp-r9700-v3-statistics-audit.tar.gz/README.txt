Independent statistics audit for https://github.com/TashaSkyUp/FreeToken/pull/1

Audited November 8, 2026. Assessment: ready within the reviewed record scope.
The numerical audit is complete for the current cohort. Historical table values
and aligned-logit metrics were independently recomputed as recorded in the JSON.
This is not a full source-code review, a new inference run or a capability test.

Read independent-statistics-audit.json for detailed recomputed values and limits.
independent_statistics_audit.py does not import the original aggregation helpers;
it uses NumPy linear percentiles, direct score remapping, independent fixed-answer
checks and log-softmax calculations from the original FP32 logit arrays.
The script uses the original workspace paths and original historical raw files;
restore those paths/data to rerun it. The three earlier evidence archives retain
the original frozen data; large historical arrays remain local, as disclosed.

Coverage: all four current configurations, all core/cache responses and SSE text,
all current latency/resource distributions, every current accepted judge result
and source mapping, all v3 archive payload hashes, all 503 engine source hashes,
recorded targeted-test logs, historical text/format totals, published timing tables,
historical mean judge ratings and aligned-logit figures. Operator-probe numerical
claims are traced to saved original probe records, without rerunning GPU kernels.
Startup time is checked against the controller's saved measurement, not replayed.

The 11 numerical tables in the document and three corresponding PR tables were
reviewed as related presentations; raw-data calculations are in the JSON.
No remaining numerical mismatch was observed. Old denominator corrections now
appear beside the historical tables: 35/41 V1 and 34/41 V2 valid cases.
The original v3 archive remains unchanged at SHA256:
47ce5129da08d105d05afc39fa69192464e445a1f8bf65422fecd38fd7efc2f3

The archived packager-controller log was captured before its completion output;
its empty snapshot is not a missing inference or judge record. The source
manifest and separately saved packaging receipt establish archive integrity.

A/B labels were checked against the actual saved source outputs. Submission
queues are ascending then descending; concurrent worker start/completion order
can vary. The same V2 TP1 outputs receive different absolute average ratings in
the two independent comparison sets. These are not a shared calibrated scale.

Single-pass timings and the output-conditioned short subset are descriptive.
Matching outputs do not establish correctness or general quality noninferiority.
MTP, TP4 and an independent full-model reference engine remain untested.

MANIFEST.json hashes every other member, not itself. The snapshot of the PR body
predates the added audit paragraph; its measurement tables were checked unchanged.
The documentation snapshot contains the corrected historical labels and totals.
