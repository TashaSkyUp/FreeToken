"""Finish the paired observation after the TP1 controller exits successfully."""

import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
while not (ROOT/'baseline-tp1-summary.json').exists():
    time.sleep(2)
time.sleep(5)
groups = {}
for line in (ROOT/'baseline-tp1-trace/tokens.jsonl').read_text().splitlines():
    row=json.loads(line)
    seq=groups.setdefault(row['key'], [])
    assert row['step'] == len(seq), row
    seq.append(row['natural_token'])
(ROOT/'baseline-tp1-replay.json').write_text(json.dumps(groups, indent=2)+'\n')
subprocess.run([sys.executable, str(ROOT/'run.py'), 'baseline-tp2-replay',
                '--tp','2','--trace','--replay',str(ROOT/'baseline-tp1-replay.json')], check=True)
subprocess.run([sys.executable,str(ROOT/'compare.py'),'baseline-tp1','baseline-tp2-replay'],check=True)
