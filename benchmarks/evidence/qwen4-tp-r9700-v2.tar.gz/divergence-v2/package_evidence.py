"""Create a content-addressed evidence bundle, omitting weights and raw judge events."""

import gzip
import hashlib
import io
import json
import platform
import subprocess
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPRO=ROOT.parent
TREE=Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-fp64')
assert json.loads((ROOT/'pipeline-state.json').read_text())['stage']=='complete'
payload={}


def add(name,path):
    path=Path(path)
    if path.is_file():
        data=path.read_bytes()
        if name in payload:
            assert payload[name]==data,name
        payload[name]=data


def add_tree(folder,prefix,extensions):
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.suffix in extensions:
            add(str(Path(prefix)/path.relative_to(folder)),path)


for name in ('prompts.json','manifest.json','summary.json','tp1-responses.jsonl','tp2-responses.jsonl',
             'tp1-settings.json','tp2-settings.json','sources-before.json','sources-after.json'):
    add('validation100/'+name,REPRO/'validation100'/name)
for name in ('run.py','analyze.py','monitor.py','judge_outputs.py','analyze_judgments.py'):
    add('validation100/'+name,REPRO/'validation100'/name)
add('pr-draft/benchmark.py',REPRO/'pr-draft/benchmark.py')
for name in ('fresh-checks.json','build-compatible.log','build.log'):
    add('pr-draft/'+name,REPRO/'pr-draft'/name)
add_tree(ROOT/'validation100-fp64','divergence-v2/validation100-fp64',
         {'.json','.jsonl','.csv','.log','.patch','.py'})
add_tree(ROOT/'fresh-ab','divergence-v2/fresh-ab',{'.json','.jsonl','.log','.py'})
for path in ROOT.iterdir():
    if path.name in {'WORK_STATE.json','archive-verification.json'}:
        continue
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.patch'}:
        add('divergence-v2/'+path.name,path)
for folder in ROOT.glob('*-trace'):
    add('divergence-v2/'+folder.name+'/tokens.jsonl',folder/'tokens.jsonl')
quality=ROOT/'profile-quality'
for path in quality.rglob('*'):
    if not path.is_file():
        continue
    rel=path.relative_to(quality)
    if path.name in ('events.jsonl','stderr.log'):
        continue
    if path.suffix in {'.py','.json','.jsonl','.csv','.html','.txt'}:
        add(str(Path('divergence-v2/profile-quality')/rel),path)

arrays=[]
for folder in sorted(ROOT.glob('*-trace')):
    for path in sorted(folder.iterdir()):
        if path.suffix not in {'.npy','.npz'}:
            continue
        h=hashlib.sha256()
        with path.open('rb') as f:
            for chunk in iter(lambda:f.read(8*1024*1024),b''):
                h.update(chunk)
        arrays.append(dict(path=str(path.relative_to(ROOT)),bytes=path.stat().st_size,
                           sha256=h.hexdigest()))
payload['divergence-v2/local-array-manifest.json']=(json.dumps(dict(
    published=False,reason='Large raw logit and layer arrays remain in the original workspace.',
    files=arrays),indent=2)+'\n').encode()
payload['divergence-v2/diagnostic-source.patch']=subprocess.check_output(
    ['git','diff','--binary'],cwd='/root/experiments/FreeToken/.worktrees/qwen4-tp-accurate')
payload['divergence-v2/final-code.patch']=subprocess.check_output(
    ['git','diff','--binary','61b0189','--','python/freetoken'],cwd=TREE)
settings=json.loads((ROOT/'validation100-fp64/tp1-settings.json').read_text())
actual={str(p.relative_to(TREE)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((TREE/'python/freetoken').rglob('*.py'))}
assert actual==settings['source_hashes'],'Inference source changed since validation'
payload['divergence-v2/final-source-verification.json']=(json.dumps(dict(
    source_hashes_unchanged=True,files=len(actual),hashes=actual),indent=2)+'\n').encode()
runtime_files=[REPRO/'rccl/librccl.so',
               Path('/root/experiments/FreeToken/.venv/lib/python3.12/site-packages/torch/lib/libamdhip64.so')]
runtime_files.extend(sorted((TREE/'python/freetoken/kernel').rglob('*.so')))
libraries=[]
for path in runtime_files:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):
            h.update(chunk)
    libraries.append(dict(path=str(path),resolved=str(path.resolve()),
                          bytes=path.stat().st_size,sha256=h.hexdigest()))
payload['divergence-v2/runtime-library-hashes.json']=(json.dumps(dict(
    python=platform.python_version(),system=platform.system(),
    kernel=platform.release(),machine=platform.machine(),libraries=libraries),indent=2)+'\n').encode()
add('divergence-v2/torch-version.py',
    '/root/experiments/FreeToken/.venv/lib/python3.12/site-packages/torch/version.py')
add('docs/qwen4-exp-tp-r9700.md',TREE/'docs/qwen4-exp-tp-r9700.md')
payload['README.txt']=b'''Experimental Qwen3.8-Flash-Next NVFP4 TP precision evidence, v2.

Read docs/qwen4-exp-tp-r9700.md first. Historical v1 responses and their metadata
are under validation100/. New untraced 100-prompt inference, all 220 responses,
source hashes, commands, logs, cache checks and timing CSV are under
divergence-v2/validation100-fp64/.

verified-logit-summary.json separates 305 delivered prediction positions from
four queued extra forwards, and verifies raw FP32 bits across TP. The full NumPy
arrays remain local; local-array-manifest.json preserves their sizes and hashes.
Fresh before/after latency measurements are under fresh-ab/. The broad inference
pass had a concurrent memory workload and is not used to isolate v2 speed cost.

profile-quality/ compares OLD TP1 against NEW TP1. Its profile1/profile2 aliases
denote arithmetic profiles; both original response files retain actual tp=1.
Judge identities, forward/reversed presentation, rubric, schema, invocations,
final judgments and analysis are retained. Raw CLI events/hidden reasoning,
authentication material, model weights and RCCL/native binaries are omitted.

These are workspace-specific scratch harnesses, not new maintained test files.
They were executed under /root/experiments/FreeToken/.local-build/qwen38-repro.
Adjust local model/library/worktree paths before reproducing elsewhere. Existing
response directories are intentionally protected against overwriting.

MANIFEST.json hashes every other archive member; it does not hash itself.
'''
manifest={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
          for name,data in sorted(payload.items())}
payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
target=TREE/'benchmarks/evidence/qwen4-tp-r9700-v2.tar.gz'
with target.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode='w',fileobj=zipped) as tar:
            for name,data in sorted(payload.items()):
                info=tarfile.TarInfo(name)
                info.size=len(data)
                info.mode=0o644
                info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(target,'r:gz') as tar:
    observed={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
assert set(observed)==set(payload)
for name,meta in manifest.items():
    assert len(observed[name])==meta['bytes']
    assert hashlib.sha256(observed[name]).hexdigest()==meta['sha256']
result=dict(path=str(target),bytes=target.stat().st_size,
            sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
            archive_members=len(payload),hashed_payload_members=len(manifest),
            local_arrays=len(arrays),source_files_verified=len(actual))
(ROOT/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
