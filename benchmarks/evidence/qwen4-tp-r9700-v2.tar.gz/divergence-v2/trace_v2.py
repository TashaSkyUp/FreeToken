"""Scratch-only observation and teacher forcing; never imported by the PR branch."""

import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch
from freetoken.distributed import get_tp_info

_batch = None
_replay = None
_snapshots = {}


def key(req):
    ids = req.input_ids[:req.prompt_len].tolist()
    return hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest()


def begin(batch):
    global _batch
    _batch = batch
    _snapshots.clear()


def snapshot(name, value):
    if _batch is not None and _batch.is_prefill:
        _snapshots[name] = value.detach().float().cpu().numpy().copy()


def finish(batch, logits, sampled):
    global _batch, _replay
    folder = Path(os.environ['FREETOKEN_TRACE_V2'])
    rank = get_tp_info().rank
    folder.mkdir(parents=True, exist_ok=True)
    natural = sampled.detach().cpu().tolist()
    if path := os.environ.get('FREETOKEN_REPLAY_V2'):
        if _replay is None:
            _replay = json.loads(Path(path).read_text())
        for i, req in enumerate(batch.reqs):
            step = req.device_len - req.prompt_len - 1
            sampled[i] = _replay[key(req)][step]
    if rank == 0:
        rows = logits[:batch.size].detach().float().cpu().numpy()
        for i, (req, row) in enumerate(zip(batch.reqs, rows)):
            step = req.device_len - req.prompt_len - 1
            name = f'{req.uid}-{step:04d}.npy'
            np.save(folder / name, row)
            top = np.argsort(row)[-16:][::-1]
            entry = dict(uid=req.uid, step=step, key=key(req),
                         phase=batch.phase, prompt_len=req.prompt_len,
                         logits=name, natural_token=natural[i],
                         emitted_token=int(sampled[i]), top_ids=top.tolist(),
                         top_logits=row[top].tolist())
            with (folder/'tokens.jsonl').open('a') as out:
                out.write(json.dumps(entry)+'\n')
    if _snapshots:
        req = batch.reqs[0]
        np.savez(folder / f'layers-{req.uid}-rank{rank}.npz', **_snapshots)
    _batch = None
    _snapshots.clear()
