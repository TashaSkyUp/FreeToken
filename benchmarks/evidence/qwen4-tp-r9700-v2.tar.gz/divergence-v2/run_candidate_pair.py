import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for tp in (1,2):
    subprocess.run([sys.executable,str(ROOT/'run.py'),f'fp64-tp{tp}-replay',
        '--tp',str(tp),'--tree','qwen4-tp-accurate','--trace',
        '--replay',str(ROOT/'baseline-tp1-replay.json'),
        '--extra','FREETOKEN_TP_REDUCTION_FP64=1'],check=True)
subprocess.run([sys.executable,str(ROOT/'compare.py'),
                'fp64-tp1-replay','fp64-tp2-replay'],check=True)
