"""Check raw FP32 bits, and separate delivered predictions from queued extra forwards."""

import json
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent


def rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()]


counts={int(r['request_id'].removeprefix('cmpl-')):r['usage']['completion_tokens']
        for r in rows(ROOT/'stable-tp1-replay-responses.jsonl')}
left=rows(ROOT/'stable-tp1-replay-trace/tokens.jsonl')
right=rows(ROOT/'stable-tp2-replay-trace/tokens.jsonl')
assert len(left)==len(right)==309
visible=extras=0
for a,b in zip(left,right):
    assert (a['uid'],a['step'],a['key'])==(b['uid'],b['step'],b['key'])
    x=np.load(ROOT/'stable-tp1-replay-trace'/a['logits'],mmap_mode='r')
    y=np.load(ROOT/'stable-tp2-replay-trace'/b['logits'],mmap_mode='r')
    assert x.dtype==y.dtype==np.float32 and x.shape==y.shape
    assert np.array_equal(x.view(np.uint32),y.view(np.uint32)),(a['uid'],a['step'])
    if a['step']<counts[a['uid']]:
        visible+=1
    else:
        extras+=1
stages={}
for name,file in [('v1','baseline-tp1-vs-baseline-tp2-replay.json'),
                  ('fp64_only','fp64-tp1-replay-vs-fp64-tp2-replay.json'),
                  ('v2','stable-tp1-replay-vs-stable-tp2-replay.json')]:
    report=json.loads((ROOT/file).read_text())
    metrics=[]
    for prompt in report['prompts']:
        # Each of the four requests has exactly one extra final dispatch in these runs.
        metrics.extend(prompt['metrics'][:-1])
    assert len(metrics)==visible
    stages[name]=dict(visible_positions=visible,greedy_disagreements=sum(not m['argmax_equal'] for m in metrics),
        mean_kl_nats=float(np.mean([m['kl'] for m in metrics])),
        centered_logit_rms=float(np.sqrt(np.mean([m['centered_rms']**2 for m in metrics]))))
result=dict(raw_bit_identical_dispatches=len(left),delivered_prediction_positions=visible,
            queued_extra_dispatches=extras,stages=stages,
            explanation='Four requests; one extra queued forward per request is retained in raw traces but excluded from delivered-position metrics.')
(ROOT/'verified-logit-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
