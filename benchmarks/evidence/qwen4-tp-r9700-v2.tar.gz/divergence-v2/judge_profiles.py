"""Run the established blinded judge on v1 TP1 versus v2 TP1, in both orders."""

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'validation100'
NEW=ROOT/'validation100-fp64'
SOURCE=ROOT/'profile-quality'
print('Confirming the controlled logits with all seven flags in both TP runs.',flush=True)
subprocess.run([sys.executable,str(ROOT/'run.py'),'stable-tp1-replay','--tp','1',
    '--tree','qwen4-tp-accurate','--trace','--replay',str(ROOT/'baseline-tp1-replay.json'),
    '--extra','FREETOKEN_TP_REDUCTION_FP64=1','--extra','FREETOKEN_STABLE_ATTENTION=1'],check=True)
subprocess.run([sys.executable,str(ROOT/'compare.py'),'stable-tp1-replay','stable-tp2-replay'],check=True)
aligned=json.loads((ROOT/'stable-tp1-replay-vs-stable-tp2-replay.json').read_text())
assert aligned['aggregate']==dict(steps=309,disagreements=0,mean_kl=0.0,centered_rms=0.0)
subprocess.run([sys.executable,str(ROOT/'verify_logits.py')],check=True)
SOURCE.mkdir(exist_ok=False)
for source,target in [(OLD/'prompts.json','prompts.json'),
                      (OLD/'tp1-responses.jsonl','profile1-responses.jsonl'),
                      (NEW/'tp1-responses.jsonl','profile2-responses.jsonl')]:
    shutil.copyfile(source,SOURCE/target)
identities=dict(
    profile1=dict(meaning='Previous five-flag precision profile, TP=1',source=str(OLD/'tp1-responses.jsonl')),
    profile2=dict(meaning='New seven-flag precision profile, TP=1',source=str(NEW/'tp1-responses.jsonl')),
    note='Both source response files retain their actual tp=1 field. The profile1/profile2 aliases denote arithmetic profiles, not TP sizes.')
(SOURCE/'identities.json').write_text(json.dumps(identities,indent=2)+'\n')
harness=(OLD/'judge_outputs.py').read_text()
harness=harness.replace('f\'tp{tp}-responses.jsonl\'', 'f\'profile{tp}-responses.jsonl\'')
harness=harness.replace("'tp1'","'profile1'").replace("'tp2'","'profile2'")
harness=harness.replace("'tp1-responses.jsonl'","'profile1-responses.jsonl'").replace("'tp2-responses.jsonl'","'profile2-responses.jsonl'")
harness=harness.replace('Judge frozen TP output pairs','Judge frozen arithmetic-profile output pairs')
(SOURCE/'judge_profiles.executed.py').write_text(harness)
analysis=(OLD/'analyze_judgments.py').read_text().replace('tp1','profile1').replace('tp2','profile2')
analysis=analysis.replace('TP1','v1 TP1').replace('TP2','v2 TP1')
(SOURCE/'analyze_profiles.py').write_text(analysis)
(SOURCE/'adapter-provenance.json').write_text(json.dumps(dict(
    original_harness_sha256=hashlib.sha256((OLD/'judge_outputs.py').read_bytes()).hexdigest(),
    executed_harness_sha256=hashlib.sha256(harness.encode()).hexdigest(),
    changes='Only input filenames, presentation/result aliases, and descriptive wording changed. Rubric, schema, CLI command, parser, concurrency, and reverse-order protocol unchanged.',
    comparison=identities),indent=2)+'\n')
out=SOURCE/'terra-max-judgments'
subprocess.run([sys.executable,str(SOURCE/'judge_profiles.executed.py'),
    '--source-dir',str(SOURCE),'--out-dir',str(out),
    '--model','gpt-6.1-terra','--reasoning','max','--workers','20'],check=True)
subprocess.run([sys.executable,str(SOURCE/'analyze_profiles.py'),'--run-dir',str(out)],check=True)
