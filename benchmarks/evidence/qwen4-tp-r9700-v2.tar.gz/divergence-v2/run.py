"""Sequential, source-frozen short diagnostics and later acceptance runs."""

import argparse
import json
import os
from pathlib import Path
import runpy

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
REPO = REPRO.parent.parent

parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('--tp', type=int, required=True)
parser.add_argument('--trace', action='store_true')
parser.add_argument('--replay', type=Path)
parser.add_argument('--all', action='store_true')
parser.add_argument('--names', nargs='+', default=['micro-story', 'haiku', 'sql-null', 'tp-definition'])
parser.add_argument('--tree', default='qwen4-tp-investigate')
parser.add_argument('--extra', action='append', default=[])
args = parser.parse_args()

loaded = runpy.run_path(str(REPRO/'pr-draft/benchmark.py'))
context = loaded['run'].__globals__
context['ROOT'] = ROOT
context['FLAGS'] = dict(context['FLAGS'])
for flag in args.extra:
    name, value = flag.split('=', 1)
    context['FLAGS'][name] = value
prompts = json.loads((REPRO/'validation100/prompts.json').read_text())
if not args.all:
    prompts = [next(p for p in prompts if p['name'] == name) for name in args.names]
if args.trace:
    context['FLAGS']['FREETOKEN_TRACE_V2'] = str(ROOT/(args.label+'-trace'))
    if args.replay:
        context['FLAGS']['FREETOKEN_REPLAY_V2'] = str(args.replay.resolve())
    # The benchmark explicitly sets PYTHONPATH; carry scratch hooks in its env copy.
    original_popen = context['subprocess'].Popen

    def popen(command, **kwargs):
        if 'env' in kwargs and 'PYTHONPATH' in kwargs['env']:
            kwargs['env']['PYTHONPATH'] += ':' + str(ROOT)
        return original_popen(command, **kwargs)

    context['subprocess'].Popen = popen
original_save = context['save']


def save(path, value):
    if path.name.endswith('-settings.json'):
        value = dict(value, tracing=args.trace, replay=bool(args.replay))
        value['environment'] = dict(value['environment'])
        if args.trace:
            value['environment']['PYTHONPATH'] += ':' + str(ROOT)
    original_save(path, value)


context['save'] = save
result = loaded['run'](args.label, REPO/'.worktrees'/args.tree, args.tp, True, prompts)
print(json.dumps(result, indent=2), flush=True)
