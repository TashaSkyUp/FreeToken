"""Write the measured follow-up into the existing repository document."""

import json
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent
TREE=Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-fp64')
assert json.loads((ROOT/'pipeline-state.json').read_text())['stage']=='complete'
r=json.loads((ROOT/'validation100-fp64/summary.json').read_text())
ab=json.loads((ROOT/'fresh-ab/summary.json').read_text())
logits=json.loads((ROOT/'verified-logit-summary.json').read_text())
judge=json.loads((ROOT/'profile-quality/terra-max-judgments/summary.json').read_text())
doc=TREE/'docs/qwen4-exp-tp-r9700.md'
base=subprocess.check_output(['git','show','61b0189:docs/qwen4-exp-tp-r9700.md'],cwd=TREE,text=True)
assert doc.read_text()==base, 'Preserve any independently edited documentation'
text=base.replace(
    'The precision settings are disabled by default. The measured profile enables\nall five in both TP modes; the experiment does not establish the quality or\nperformance of arbitrary subsets.',
    'The precision settings are disabled by default. The initial v1 profile enables\nthe first five settings below. The follow-up v2 profile enables all seven in both\nTP modes; arbitrary subsets have not been broadly qualified.')
needle='| `FREETOKEN_RESIDUAL_FP32` | Carry Qwen4 hyper-connection residual streams in FP32, casting normalized projection inputs and PLE inputs to their weight dtype. |'
text=text.replace(needle,needle+'\n| `FREETOKEN_TP_REDUCTION_FP64` | Accumulate fixed 64-wide BF16 dot-product tiles and NVFP4 down-projection partials in FP64; retain FP64 through expert weighting, shared/routed combination and TP reduction, then return FP32 residual updates. |\n| `FREETOKEN_STABLE_ATTENTION` | Select QSA attention tiles and per-head normalization layouts from the original head counts, so TP sharding does not change those choices. |')
text=text.replace('  divisibility check to NVFP4 slicing. The 100-prompt run was not repeated on\n  this cleaned branch; fresh checks are recorded separately in the PR body.',
    '  divisibility check to NVFP4 slicing. The v1 100-prompt run was not repeated\n  on that cleaned branch. The v2 run below uses cleaned commit `61b0189` plus\n  the archived candidate patch; its settings record every Python source hash.')
text=text.replace('export FREETOKEN_RESIDUAL_FP32=1\nPYTHONPATH=',
    'export FREETOKEN_RESIDUAL_FP32=1\nexport FREETOKEN_TP_REDUCTION_FP64=1 FREETOKEN_STABLE_ATTENTION=1\nPYTHONPATH=')
text=text.replace('Use `--tp-size 1` for TP=1. For the main baseline unset all five precision\nvariables. Current main rejects Qwen4 TP=2; there is no main TP=2 performance\nbaseline.',
    'Use `--tp-size 1` for TP=1. To reproduce v1, unset the two v2 additions.\nFor the main baseline unset all seven precision variables. Main at `14119b8`\nrejects Qwen4 TP=2; there is no main TP=2 performance baseline.')
text=text.replace('## Changes',
    'The v2 follow-up records **100/100 exact greedy text pairs**, up from 74/100.\n'
    'Both TP modes use the new profile. It changes 35/100 original TP1 answers;\n'
    'V2 TP2 matches the original V1 TP1 text in 65/100 cases. Strict known-answer/\n'
    'format checks fall from 35/42 to 34/42 per mode, and blinded quality ratings\n'
    'slightly favor V1. This is measured TP agreement, not a demonstrated answer-\n'
    'quality gain. The settings remain experimental and disabled by default.\n\n'
    '## Changes',1)
text=text.replace('expert sums and untied BF16 LM-head logits in FP32 through their relevant reductions.',
    'expert sums and untied BF16 LM-head logits in FP32 through their relevant reductions (the v2 reduction flag widens the affected row/expert paths further).')
text=text.replace('## Existing evidence','## Historical v1 evidence')
text=text.replace('exposes a roughly 60% TP=1 decode-throughput cost for the precision profile;\nTP=2 is about 1.68x main TP=1.',
    'has branch TP=1 decode throughput roughly 60% below main in that pass;\nTP=2 is about 1.68x main TP=1. It does not isolate a settled precision cost.')

parts=['','## Follow-up v2 experiment','',
 'The first remaining difference was an FP32 attention output projection. Small',
 'rounding differences then crossed BF16 normalization boundaries and grew through',
 'the decoder. Wider accumulation made the four short prefill traces identical',
 'until QSA layers. Two additional choices depended on local head counts: QSA',
 'attention tile/split selection and the per-head RMSNorm warp count. V2 uses the',
 'unsharded head counts for both choices. All switches remain opt-in.', '',
 'The operator probes use FP64 arithmetic as an independent numerical reference.',
 'Before the final FP32 cast, a tested 6,144-wide BF16 row projection RMS error fell from about',
 '`1.2e-6` to `5.8e-8`; split and unsplit results agreed after FP32 rounding.',
 'The NVFP4 down/decode probe also reduced error and eliminated the split',
 'difference after FP32 rounding. These are representative operator checks,',
 'not an independent full-model reference-engine accuracy benchmark.', '',
 'Four difficult short prompts were replayed along one fixed token path. Metrics',
 f"below cover {logits['delivered_prediction_positions']} delivered prediction positions; the raw traces also retain",
 f"{logits['queued_extra_dispatches']} extra queued final forwards. Final TP=1 and TP=2 runs both enable all seven flags.", '',
 '| Profile | Greedy disagreements | Mean KL, nats | Centered logit RMS |',
 '| --- | ---: | ---: | ---: |']
for name,label in [('v1','V1'),('fp64_only','V1 + FP64 reductions'),('v2','V2, including stable attention')]:
    s=logits['stages'][name]
    parts.append(f"| {label} | {s['greedy_disagreements']}/{s['visible_positions']} | {s['mean_kl_nats']:.9g} | {s['centered_logit_rms']:.9g} |")
parts+=['',f"The final raw FP32 logit bit patterns match at all {logits['raw_bit_identical_dispatches']} recorded dispatches.",
        'The source hashes and model settings are retained for each run.','',
 'The original 100 prompts and ten cache-repeat attempts per mode were then run',
 'with tracing and replay disabled, at the same greedy settings and 128-token cap.', '',
 '| Measurement | V1 | V2 |','| --- | ---: | ---: |',
 f"| Exact core text pairs | {r['before_exact_matches']}/100 | {r['after_exact_matches']}/100 |",
 f"| Divergent core pairs | {r['divergent_outputs_before']} | {r['divergent_outputs_after']} |",
 f"| Strict known-answer/format checks, TP=1 | 35/42 | {r['known_answer_passes']['tp1']}/{r['known_answer_total']} |",
 f"| Strict known-answer/format checks, TP=2 | 35/42 | {r['known_answer_passes']['tp2']}/{r['known_answer_total']} |", '',
 f"Divergent-output count fell by {100*r['divergent_output_reduction_fraction']:.1f}%. All core requests were uncached.",
 f"V2 also changes TP=1 arithmetic: {r['tp1_profile_text_changes']}/100 TP1 texts change between profiles. V2 TP2 matches the original V1 TP1 text in {r['old_tp1_vs_new_tp2_exact_matches']}/100 cases. The 100-pair agreement figure compares TP modes with V2 enabled in both.",
 f"Finish reasons match in {r['matching_finish_reasons']}/100 pairs and completion-token counts in {r['matching_completion_counts']}/100.",
 f"Core finish reasons: {json.dumps(r['finish_reasons'],sort_keys=True)}. Total completion tokens across the 220 responses: {r['total_generated_completion_tokens']}.",
 'Agreement is a separate measurement from answer correctness. Common wrong or',
 'incomplete answers remain. In `normalize-records`, V2 wraps the correct JSON',
 'data in Markdown fences despite a return-only-JSON instruction; this remains a',
 'strict format-check failure, not a pass obtained by stripping the fences.', '']
parts.append('Newly failing strict checks relative to V1: '+json.dumps(r['known_answer_regressions'],sort_keys=True)+'.')
for tp in (1,2):
    hits=sum(c[f'tp{tp}']['cache_n']>0 for c in r['cache_checks'])
    equals=sum(c[f'tp{tp}']['cold_repeat_text_equal'] for c in r['cache_checks'])
    parts.append(f"TP={tp}: {hits}/10 repeats actually hit the cache; {equals}/10 initial/repeat texts match.")
parts+=['',f"Cached/repeated texts match across TP in {sum(c['cross_tp_text_equal'] for c in r['cache_checks'])}/10 attempts.", '',
 'A concurrent ComfyUI workload overlapped host paging during part of the TP=1',
 '100-prompt pass. Those full-run latency observations are preserved as contended',
 'data, and are not used to isolate the cost of V2. A separate same-source A/B',
 'uses identical delivered text/token workloads, three warmups followed by three',
 'timed requests per configuration, and cold KV caches. Idle service/GPU and RAM',
 'preflight observations are retained. The ordering is V1 TP1, V2 TP1, V2 TP2,',
 'V1 TP2; this is one small sequential comparison, not a confidence interval.',
 'The controller paused between the first two legs while GPU memory was being',
 'released after shutdown. The completed V1 TP1 leg was preserved, and the',
 'remaining legs resumed after idle checks. Both harness versions are retained.', '',
 '| Configuration | Median TTFT, s | Median response, s | Median decode, ms/token | Median decode, tok/s |',
 '| --- | ---: | ---: | ---: | ---: |']
for label in ('v1-tp1','v2-tp1','v1-tp2','v2-tp2'):
    s=ab['results'][label]['performance']
    parts.append(f"| {label.upper()} | {s['ttft_seconds']['p50']:.3f} | {s['response_seconds']['p50']:.3f} | {s['engine_decode_ms_per_token']['p50']:.3f} | {s['engine_decode_tokens_per_second']['p50']:.3f} |")
parts+=['',
 f"Median decode time per token rises {ab['v2_median_time_cost_percent']['tp1']['engine_decode_ms_per_token']:.2f}% at TP1 and {ab['v2_median_time_cost_percent']['tp2']['engine_decode_ms_per_token']:.2f}% at TP2. Median response time rises {ab['v2_median_time_cost_percent']['tp1']['response_seconds']:.2f}% and {ab['v2_median_time_cost_percent']['tp2']['response_seconds']:.2f}%, respectively.",
 f"Resolved expert-cache slots are unchanged between profiles within each TP mode: {ab['resolved_cache']['v1-tp1']['expert_slots_per_rank']:,} at TP1, {ab['resolved_cache']['v1-tp2']['expert_slots_per_rank']:,} per rank at TP2, with 256 KV pages in every leg.", '',
 'The SSE delivery logs additionally preserve client text-chunk arrival times.',
 'Chunks can contain partial or multiple tokens; their gaps are not presented as',
 'individual GPU token-generation gaps. Auto expert-cache residency remains part',
 'of these end-to-end measurements.', '',
 'One old-profile TP2 timing attempt timed out in the cache-control endpoint before',
 'any inference response. Its logs are retained. That leg was restarted after an',
 'idle preflight with a three-second control-plane settling delay outside measured',
 'request intervals; the three completed legs were preserved.', '',
 'The existing blinded Terra rubric was also run on **V1 TP=1 versus V2 TP=1**',
 '(arithmetic-profile quality, not a TP1/TP2 comparison). Both original source',
 'files retain their actual TP=1 identity. One hundred pairs were judged, then',
 'resubmitted with reversed sample and A/B order, at up to 20 concurrent calls,',
 '`gpt-6.1-terra`, `max` reasoning. The previous parser correction is included.', '',
 '| Mean judge score, 0-4 | V1 TP=1 | V2 TP=1 |','| --- | ---: | ---: |']
for dim,label in [('correctness','Correctness'),('instruction_following_completeness','Instruction following/completeness')]:
    s=judge['all_samples'][dim]
    parts.append(f"| {label} | {s['profile1_mean']:.3f} | {s['profile2_mean']:.3f} |")
parts+=['',f"Accepted evaluations: {judge['evaluations']}; main CLI invocations: {judge['main_run_cli_invocations']}.",
 f"Identical-output control errors: {len(judge['identical_control_errors'])}.",
 'These ratings are secondary evidence. One judgment per order confounds order',
 'effects with judge variance, and the purpose-built prompt set does not establish',
 'general model capability or quality noninferiority.', '',
 'Correctness outcomes stable across both judging orders: '+json.dumps(judge['all_samples']['correctness']['stable_outcomes'],sort_keys=True)+'.',
 'Instruction/completeness outcomes stable across both orders: '+json.dumps(judge['all_samples']['instruction_following_completeness']['stable_outcomes'],sort_keys=True)+'.',
 'The judges consistently favored V1 on `bash-spaces` (V2 reaches the cap before',
 'finishing the shell code) and `ordered-steps` (V2 recommends SHA-256 commands',
 'after mentioning other checksum algorithms), as well as two smaller explanatory',
 'precision differences. The raw outputs and rationales are retained; exact TP',
 'agreement should not be described as a general quality improvement.', '',
 'Fifteen targeted precision-profile tests pass, including dense-oracle QSA,',
 'chunked prefill, decode/verify graph replay, GDN, NVFP4 and hyper-connections.',
 'With the precision flags disabled, the QSA file has nine passes, one skip and',
 'one failure at `test_chunked_prefill_matches_one_shot[unaligned]`. The same',
 'assertion independently fails on the unmodified `61b0189` draft tree; the',
 'all-seven-flags run passes that case. No test or tolerance was changed.', '',
 'The [v2 evidence archive](../benchmarks/evidence/qwen4-tp-r9700-v2.tar.gz)',
 'contains the frozen 100-prompt runs, operator and aligned-logit summaries,',
 'fresh timing/SSE data, profile-quality judgments, executed harnesses, settings,',
 'source hashes and test logs. Large NumPy logit/layer arrays remain local and',
 'are represented by hashes; weights, authentication data and raw Codex event',
 'logs are excluded. Other hardware, communication backends and checkpoints',
 'remain unqualified by this experiment.', '']
doc.write_text(text+'\n'.join(parts))
print(doc)
