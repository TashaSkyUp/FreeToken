"""Isolate QSA head-count-dependent norm reductions and attention launch profiles."""

import json
import sys
from pathlib import Path

import numpy as np
import torch
from safetensors import safe_open

from freetoken.kernel.triton.stable_linear import linear
from freetoken.kernel.triton.norm import gemma_rmsnorm
from freetoken.kernel.triton.qsa import qsa_sparse_paged_attention

ROOT=Path(__file__).resolve().parent
STABLE='--stable' in sys.argv
MODEL=Path('/models-fast/206-comfyui-models/LLM/Qwen3.8-Flash-Next-NVFP4')
raw=json.loads((MODEL/'config.json').read_text())
cfg=raw.get('text_config',raw)
mapping=json.loads((MODEL/'model.safetensors.index.json').read_text())['weight_map']
prefix='model.language_model.layers.3.self_attn.'
weights={}
for name in ('q_proj.weight','k_proj.weight','v_proj.weight','q_norm.weight','k_norm.weight'):
    with safe_open(MODEL/mapping[prefix+name],framework='pt',device='cpu') as f:
        weights[name]=f.get_tensor(prefix+name).cuda()
print('index_config', {k:v for k,v in cfg.items() if 'index' in k},flush=True)
report=[]
for uid in range(4):
    source=np.load(ROOT/f'fp64-tp1-replay-trace/layers-{uid}-rank0.npz')
    x=torch.from_numpy(source['03/attn_in']).cuda().bfloat16()
    m=x.shape[0]
    qg=linear(x,weights['q_proj.weight']).reshape(m,24,512)
    q=qg[:,:,:256].contiguous()
    k=linear(x,weights['k_proj.weight']).reshape(m,2,256)
    v=linear(x,weights['v_proj.weight']).reshape(m,2,256)
    qn=gemma_rmsnorm(q.reshape(-1,256),weights['q_norm.weight'],cfg['rms_norm_eps']).reshape_as(q)
    kn=gemma_rmsnorm(k.reshape(-1,256),weights['k_norm.weight'],cfg['rms_norm_eps']).reshape_as(k)
    split_q=torch.cat([gemma_rmsnorm(s.contiguous().reshape(-1,256),weights['q_norm.weight'],
                       cfg['rms_norm_eps'], tuning_rows=m*24 if STABLE else None).reshape(m,12,256) for s in q.split(12,dim=1)],dim=1)
    split_k=torch.cat([gemma_rmsnorm(s.contiguous().reshape(-1,256),weights['k_norm.weight'],
                       cfg['rms_norm_eps'], tuning_rows=m*2 if STABLE else None).reshape(m,1,256) for s in k.split(1,dim=1)],dim=1)
    nbad=(qn!=split_q).nonzero().cpu().tolist()
    width=cfg['indexer_budget']+cfg['indexer_compress_ratio']-1
    ids=torch.arange(width,device='cuda',dtype=torch.int32).repeat(m,1)
    ids.masked_fill_(ids>torch.arange(m,device='cuda')[:,None],-1)
    kp=torch.zeros((1,64,2,256),device='cuda',dtype=torch.bfloat16)
    vp=torch.zeros_like(kp)
    kp[0,:m]=kn;vp[0,:m]=v
    table=torch.zeros((1,1),device='cuda',dtype=torch.int32)
    req=torch.zeros(m,device='cuda',dtype=torch.int32)
    a=qsa_sparse_paged_attention(qn,kp,vp,ids,table,req)
    b=torch.cat([qsa_sparse_paged_attention(qn[:,j*12:(j+1)*12].contiguous(),
                    kp[:,:,j:j+1].contiguous(),vp[:,:,j:j+1].contiguous(),ids,table,req,
                    tuning_num_kv_heads=2 if STABLE else None)
                 for j in range(2)],dim=1)
    report.append(dict(tokens=m,selection_width=width,stable=STABLE,q_norm_unequal=len(nbad),q_norm_locations=nbad,
                       k_norm_unequal=int((kn!=split_k).sum()),
                       attention_unequal=int((a!=b).sum()),
                       attention_max_abs=float((a.float()-b.float()).abs().max())))
(ROOT/f'attention-probe-{"stable" if STABLE else "baseline"}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
