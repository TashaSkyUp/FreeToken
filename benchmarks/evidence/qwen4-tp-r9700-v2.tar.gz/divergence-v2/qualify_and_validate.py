import json
import os
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
TREE=Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-fp64')
trace=json.loads((ROOT/'fp64-tp1-replay-vs-stable-tp2-replay.json').read_text())
assert trace['aggregate']['steps']==309
assert trace['aggregate']['disagreements']==0
assert trace['aggregate']['mean_kl']==0
env=os.environ.copy()
for name in tuple(env):
    if name.startswith('FREETOKEN_') and name!='FREETOKEN_ROCM_ARCH':
        del env[name]
env.update(PYTHONPATH=str(TREE/'python'),HIP_VISIBLE_DEVICES='0',OMP_NUM_THREADS='4')
command=[sys.executable,'-m','pytest','tests/models/qwen4_exp/test_qsa_backend.py','-q']
with (ROOT/'default-qsa-tests.log').open('w') as log:
    subprocess.run(command,cwd=TREE,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
(ROOT/'qualification.json').write_text(json.dumps(dict(
    precision_profile_tests=dict(passed=15,deselected=27,seconds=48.07,log='precision-v2-tests.log'),
    default_profile_qsa=dict(command=command,passed=True,log='default-qsa-tests.log'),
    aligned_trace=trace['aggregate']),indent=2)+'\n')
print('Qualification passed; starting untraced 100-prompt validation.',flush=True)
subprocess.run([sys.executable,str(ROOT/'validate100.py')],check=True)
subprocess.run([sys.executable,str(ROOT/'analyze100.py')],check=True)
