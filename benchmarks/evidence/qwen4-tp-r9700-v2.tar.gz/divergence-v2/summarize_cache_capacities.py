import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parent
assert json.loads((ROOT/'pipeline-state.json').read_text())['stage']=='complete'
path=ROOT/'fresh-ab/summary.json'
summary=json.loads(path.read_text())
resolved={}
for label in summary['results']:
    matches=re.findall(r'resolved moe_cache_size=(\d+) num_pages=(\d+)',
                       (ROOT/f'fresh-ab/{label}-server.log').read_text())
    assert len(matches)==1
    slots,pages=map(int,matches[0])
    resolved[label]=dict(expert_slots_per_rank=slots,kv_pages=pages)
assert resolved['v1-tp1']==resolved['v2-tp1']
assert resolved['v1-tp2']==resolved['v2-tp2']
summary['resolved_cache']=resolved
for path in (ROOT/'fresh-ab/summary.json', ROOT/'fresh-ab-summary.json'):
    path.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(resolved,indent=2))
