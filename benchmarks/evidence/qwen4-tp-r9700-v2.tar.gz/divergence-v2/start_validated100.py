import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
trace=json.loads((ROOT/'fp64-tp1-replay-vs-stable-tp2-replay.json').read_text())
assert trace['aggregate']==dict(steps=309,disagreements=0,mean_kl=0.0,centered_rms=0.0)
assert '15 passed' in (ROOT/'precision-v2-tests.log').read_text()
assert '1 failed, 9 passed, 1 skipped' in (ROOT/'default-qsa-tests.log').read_text()
assert '1 failed' in (ROOT/'default-qsa-baseline-reproduction.log').read_text()
(ROOT/'qualification.json').write_text(json.dumps(dict(
    precision_profile_tests=dict(passed=15,deselected=27,seconds=48.07,log='precision-v2-tests.log'),
    default_profile_qsa=dict(passed=9,skipped=1,failed=1,log='default-qsa-tests.log',
        failure='test_chunked_prefill_matches_one_shot[unaligned]',
        baseline_reproduction='Same assertion also fails on unmodified 61b0189 draft tree; default-qsa-baseline-reproduction.log',
        precision_profile='The unaligned case passes with all seven precision flags enabled.'),
    aligned_trace=trace['aggregate']),indent=2)+'\n')
print('Target precision checks passed. Default-profile failure independently reproduced on unchanged draft.',flush=True)
subprocess.run([sys.executable,str(ROOT/'validate100.py')],check=True)
subprocess.run([sys.executable,str(ROOT/'analyze100.py')],check=True)
