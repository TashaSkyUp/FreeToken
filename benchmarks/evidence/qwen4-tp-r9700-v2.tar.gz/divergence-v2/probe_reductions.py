"""Scratch probe: sharded reductions against FP64 arithmetic, independent of TP1 output."""

import json
import os
from pathlib import Path

import torch

from freetoken.kernel.triton.stable_linear import fp32_linear, reduction_linear
from freetoken.kernel import nvfp4_moe

torch.manual_seed(73)
device='cuda'
report=[]


def metrics(a,b,ref):
    return dict(split_unequal_after_fp32=int((a.float()!=b.float()).sum()),
                split_max_abs=float((a-b).abs().max()),
                full_max_error=float((a.double()-ref).abs().max()),
                full_rms_error=float((a.double()-ref).square().mean().sqrt()),
                split_rms_error=float((b.double()-ref).square().mean().sqrt()))


for m,k,n in [(1,6144,2560),(35,6144,2560),(1,640,2560),(35,640,2560)]:
    x=torch.randn(m,k,device=device,dtype=torch.bfloat16)
    w=torch.randn(n,k,device=device,dtype=torch.bfloat16)/64
    ref=x.double()@w.double().T
    os.environ['FREETOKEN_STABLE_LINEAR']='1'
    full=fp32_linear(x,w)
    split=fp32_linear(x[:,:k//2],w[:,:k//2])+fp32_linear(x[:,k//2:],w[:,k//2:])
    base=metrics(full,split,ref)
    os.environ['FREETOKEN_TP_REDUCTION_FP64']='1'
    full=reduction_linear(x,w)
    split=reduction_linear(x[:,:k//2],w[:,:k//2])+reduction_linear(x[:,k//2:],w[:,k//2:])
    better=metrics(full,split,ref)
    report.append(dict(kind='bf16_row',shape=[m,k,n],baseline=base,candidate=better))

e,n,k,topk=2,256,640,2
packed=torch.randint(0,256,(e,n,k//2),device=device,dtype=torch.uint8)
scale=(torch.rand(e,n,k//16,device=device)+.1).to(torch.float8_e4m3fn)
glob=torch.rand(e,n,device=device)*.01
weights=torch.rand(1,topk,device=device)
ids=torch.arange(e,device=device,dtype=torch.int32).reshape(1,topk)
x=torch.randn(topk,k,device=device,dtype=torch.bfloat16)
lut=torch.tensor([0,.5,1,1.5,2,3,4,6,-0.,-.5,-1,-1.5,-2,-3,-4,-6],device=device,dtype=torch.float64)
codes=torch.stack((packed&15,packed>>4),-1).reshape(e,n,k).long()
base_weights=lut[codes]*scale.double().repeat_interleave(16,-1)
ref=torch.einsum('ek,enk->en',x.double(),base_weights)*glob.double()*weights.reshape(-1,1).double()
for dtype in (torch.float32,torch.float64):
    y=torch.empty((1,topk,n),device=device,dtype=dtype)
    nvfp4_moe.decode_gemm_marlin(x,packed,scale,glob,y,weights,ids,True,True)
    split=[]
    for lo,hi in [(0,k//2),(k//2,k)]:
        yy=torch.empty_like(y)
        nvfp4_moe.decode_gemm_marlin(x[:,lo:hi].contiguous(),packed[:,:,lo//2:hi//2].contiguous(),
            scale[:,:,lo//16:hi//16].contiguous(),glob,yy,weights,ids,True,True)
        split.append(yy)
    report.append(dict(kind='nvfp4_down_decode',dtype=str(dtype),**metrics(y,split[0]+split[1],ref.unsqueeze(0))))
    assert torch.isfinite(y).all()
out=Path(__file__).with_name('operator-probe.json')
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
