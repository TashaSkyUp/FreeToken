"""Same-source v1/v2 A/B: identical output workload, cold KV, separate warmups."""

import argparse
import hashlib
import json
import os
import runpy
import time
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--resume',action='store_true')
args=parser.parse_args()
DATA=ROOT/'validation100-fp64'
OUT=ROOT/'fresh-ab'
TREE=Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-fp64')
helpers=runpy.run_path(str(ROOT.parent/'validation100/analyze.py'))
performance=helpers['performance']
distribution=helpers['distribution']
loaded=runpy.run_path(str(ROOT.parent/'pr-draft/benchmark.py'))
ctx=loaded['run'].__globals__
original_complete=ctx['complete']
original_post=ctx['post']
v1_flags=dict(ctx['FLAGS'])
v2_flags=dict(v1_flags,FREETOKEN_TP_REDUCTION_FP64='1',FREETOKEN_STABLE_ATTENTION='1')
all_prompts=json.loads((DATA/'prompts.json').read_text())
summary=json.loads((DATA/'summary.json').read_text())
reference={r['name']:r for r in map(json.loads,(DATA/'tp1-responses.jsonl').read_text().splitlines()) if r['kind']=='core'}
eligible=[p for p in all_prompts if p['name'] in summary['all_four_same_outputs_short']
          and p['tokens']<64
          and reference[p['name']]['usage']['completion_tokens']>=16]
eligible.sort(key=lambda p:(-reference[p['name']]['usage']['completion_tokens'],p['index']))
selected=[]
for p in eligible:
    if p['category'] not in {v['category'] for v in selected}:
        selected.append(p)
    if len(selected)==3:
        break
for p in eligible:
    if len(selected)==3:
        break
    if p not in selected:
        selected.append(p)
assert len(selected)==3


def preflight():
    with urllib.request.urlopen('http://127.0.0.1:8188/queue',timeout=5) as r:
        queue=json.load(r)
    mem={k:int(v.split()[0])*1024 for k,v in
         (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())}
    gpus=[]
    for d in Path('/sys/class/drm').glob('card*/device'):
        try:
            total=int((d/'mem_info_vram_total').read_text())
            used=int((d/'mem_info_vram_used').read_text())
            if total>30*2**30:
                gpus.append(dict(pci=d.resolve().name,total_bytes=total,used_bytes=used,
                                 busy_percent=int((d/'gpu_busy_percent').read_text())))
        except OSError:
            pass
    result=dict(utc=ctx['now'](),comfy_running=len(queue.get('queue_running',[])),
                comfy_pending=len(queue.get('queue_pending',[])),available_ram_bytes=mem['MemAvailable'],
                swap_used_bytes=mem['SwapTotal']-mem['SwapFree'],gpus=gpus)
    if result['comfy_running'] or result['comfy_pending']:
        raise RuntimeError(dict(preflight='ComfyUI is active',**result))
    if mem['MemAvailable']<80*2**30 or len(gpus)!=2 or any(g['used_bytes']>2*2**30 or g['busy_percent']>10 for g in gpus):
        raise RuntimeError(dict(preflight='Insufficient idle resources for timing',**result))
    return result


def wait_idle():
    deadline=time.monotonic()+45
    while True:
        try:
            return preflight()
        except RuntimeError as error:
            if OUT.exists():
                with (OUT/'idle-waits.jsonl').open('a') as log:
                    log.write(json.dumps(dict(utc=ctx['now'](),observed=error.args[0]))+'\n')
            if time.monotonic()>=deadline:
                raise
            time.sleep(2)


initial=wait_idle()
OUT.mkdir(exist_ok=args.resume)
ctx['ROOT']=OUT
selection=dict(
    rule='Longest common-output prompts with <64 input tokens to avoid TP2 prefix snapshots, prefer three categories; >=16 completion tokens.',
    prompts=selected,preflight=initial,order=['v1-tp1','v2-tp1','v2-tp2','v1-tp2'],
    warmups_per_mode=3,timed_requests_per_mode=3)
if args.resume:
    previous=json.loads((OUT/'selection.json').read_text())
    assert {k:v for k,v in previous.items() if k!='preflight'}=={k:v for k,v in selection.items() if k!='preflight'}
else:
    (OUT/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
harness=Path(__file__).read_bytes()
(OUT/('executed-'+hashlib.sha256(harness).hexdigest()[:12]+'.py')).write_bytes(harness)
active=[]
active_started=0.0
label=''
calls=0


class ObservedResponse:
    def __init__(self,response):
        self.response=response

    def __enter__(self):
        self.response.__enter__()
        return self

    def __exit__(self,*args):
        return self.response.__exit__(*args)

    def __iter__(self):
        for raw in self.response:
            active.append((time.perf_counter()-active_started,raw))
            yield raw


def post(path,body,timeout=900):
    # Health may precede the IPC control plane settling on a fresh backend.
    # This delay is outside complete() and all measured request intervals.
    if path.startswith('/v1/cache/flush') and calls==0:
        time.sleep(3)
    response=original_post(path,body,timeout)
    return ObservedResponse(response) if path=='/v1/completions' else response


def complete(tp,p,kind,flush):
    global active,active_started,calls
    kind='warmup' if calls<3 else 'timed'
    calls+=1
    active=[]
    active_started=time.perf_counter()
    row=original_complete(tp,p,kind,flush)
    times=[]
    for stamp,raw in active:
        line=raw.decode().strip()
        if not line.startswith('data:') or line[5:].strip()=='[DONE]':
            continue
        event=json.loads(line[5:])
        if any(c.get('text') for c in event.get('choices',[])):
            times.append(stamp)
    gaps=[1000*(b-a) for a,b in zip(times,times[1:])]
    row['client_nonempty_text_chunks']=len(times)
    row['client_text_chunk_gap_ms']=distribution(gaps)
    row['client_text_chunk_gaps_ms']=gaps
    event_file=f'{label}-{row["request_id"]}-sse.json'
    row['sse_delivery_file']=event_file
    (OUT/event_file).write_text(json.dumps(dict(label=label,name=p['name'],kind=kind,
        events=[dict(seconds=stamp,line=raw.decode()) for stamp,raw in active]),indent=2)+'\n')
    return row


ctx['post']=post
ctx['complete']=complete
snapshots=[]
for label,tp,flags in [('v1-tp1',1,v1_flags),('v2-tp1',1,v2_flags),
                      ('v2-tp2',2,v2_flags),('v1-tp2',2,v1_flags)]:
    result_file=OUT/f'{label}-summary.json'
    if args.resume and result_file.exists():
        settings=json.loads((OUT/f'{label}-settings.json').read_text())
        assert settings['source_hashes']==ctx['hashes'](TREE)
        assert {k:settings['environment'].get(k) for k in flags}==flags
        existing=list(map(json.loads,(OUT/f'{label}-responses.jsonl').read_text().splitlines()))
        assert [r['name'] for r in existing]==[p['name'] for p in selected+selected]
        assert len(existing)==6 and sum(r['kind']=='timed' for r in existing)==3
        assert all(r['cache_n']==0 for r in existing)
        saved=OUT/f'{label}-preflight.json'
        observed=json.loads(saved.read_text()) if saved.exists() else previous['preflight']
        snapshots.append(dict(label=label,**observed))
        print(json.dumps(dict(event='preserving-completed-leg',label=label)),flush=True)
        continue
    observed=wait_idle()
    (OUT/f'{label}-preflight.json').write_text(json.dumps(observed,indent=2)+'\n')
    snapshots.append(dict(label=label,**observed))
    calls=0
    ctx['FLAGS']=flags
    loaded['run'](label,TREE,tp,True,selected+selected)
    wait_idle()
data={}
for label in ('v1-tp1','v2-tp1','v1-tp2','v2-tp2'):
    data[label]=[r for r in map(json.loads,(OUT/f'{label}-responses.jsonl').read_text().splitlines()) if r['kind']=='timed']
    assert len(data[label])==3
for p in selected:
    values=[next(r for r in data[key] if r['name']==p['name']) for key in data]
    assert len({r['text'] for r in values})==1
    assert len({r['usage']['completion_tokens'] for r in values})==1
    assert all(r['cache_n']==0 for r in values)
results={key:dict(performance=performance(values),client_text_chunk_gap_ms=distribution(
    [gap for row in values for gap in row['client_text_chunk_gaps_ms']])) for key,values in data.items()}
cost={f'tp{tp}':{metric:100*(results[f'v2-tp{tp}']['performance'][metric]['p50']/
                           results[f'v1-tp{tp}']['performance'][metric]['p50']-1)
    for metric in ('ttft_seconds','response_seconds','engine_decode_ms_per_token')} for tp in (1,2)}
result=dict(results=results,v2_median_time_cost_percent=cost,preflights=snapshots,
    identical_text_and_token_workloads=True,timed_requests_per_mode=3,
    limitation='One small sequential A/B after three warmups per mode. Cold KV but warm code and repeated prompts. Client text chunks can contain partial or multiple tokens; chunk gaps are not token-gap ground truth.')
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
(ROOT/'fresh-ab-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(cost,indent=2),flush=True)
