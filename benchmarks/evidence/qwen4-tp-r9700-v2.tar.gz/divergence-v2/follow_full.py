"""Continue quality review and isolated timings after the frozen inference pass."""

import json
import subprocess
import sys
import time
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def state(stage,**extra):
    value=dict(stage=stage,utc=datetime.now(timezone.utc).isoformat(),**extra)
    temp=ROOT/'pipeline-state.tmp'
    temp.write_text(json.dumps(value,indent=2)+'\n')
    temp.replace(ROOT/'pipeline-state.json')
    print(json.dumps(value),flush=True)


state('waiting-for-full-validation')
try:
    while True:
        try:
            run=json.loads((ROOT/'validation100-fp64/state.json').read_text())
            if run['stage']=='failed':
                raise RuntimeError(run)
            report=json.loads((ROOT/'validation100-fp64/summary.json').read_text())
            if run['stage']=='complete':
                break
        except (OSError,ValueError):
            pass
        time.sleep(2)
    assert report['after_exact_matches']>=87, report['after_exact_matches']
    assert report['all_core_uncached']
    state('blinded-profile-quality',exact_pairs=report['after_exact_matches'])
    subprocess.run([sys.executable,str(ROOT/'judge_profiles.py')],check=True)
    state('fresh-before-after-timings')
    subprocess.run([sys.executable,str(ROOT/'fresh_ab.py')],check=True)
    state('complete')
except BaseException as error:
    state('failed',error=repr(error))
    raise
