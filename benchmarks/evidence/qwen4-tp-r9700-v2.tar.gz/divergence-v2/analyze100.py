"""Analyze frozen before/after TP evidence, retaining independent known-answer checks."""

import csv
import hashlib
import json
import runpy
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'validation100-fp64'
OLD=ROOT.parent/'validation100'
helpers=runpy.run_path(str(OLD/'analyze.py'))
performance=helpers['performance']
check_answer=helpers['check_answer']
json_equal=helpers['json_equal']
diff=helpers['diff']


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


prompts=json.loads((OUT/'prompts.json').read_text())
manifest=json.loads((OUT/'manifest.json').read_text())
assert hashlib.sha256((OUT/'prompts.json').read_bytes()).hexdigest()==manifest['prompts_sha256']
old={tp:rows(OLD/f'tp{tp}-responses.jsonl') for tp in (1,2)}
new={tp:rows(OUT/f'tp{tp}-responses.jsonl') for tp in (1,2)}
core={tp:{r['name']:r for r in new[tp] if r['kind']=='core'} for tp in (1,2)}
prior={tp:{r['name']:r for r in old[tp] if r['kind']=='core'} for tp in (1,2)}
cached={tp:{r['name']:r for r in new[tp] if r['kind']=='cache-repeat'} for tp in (1,2)}
for tp in (1,2):
    assert len(new[tp])==110
    assert Counter(r['kind'] for r in new[tp])=={'core':100,'cache-repeat':10}
    assert len(core[tp])==100 and len(cached[tp])==10
    settings=json.loads((OUT/f'tp{tp}-settings.json').read_text())
    summary=json.loads((OUT/f'tp{tp}-summary.json').read_text())
    assert not settings['tracing'] and not settings['replay']
    assert summary['source_hashes_unchanged']
    for p in prompts:
        r=core[tp][p['name']]
        assert r['prompt_sha256']==p['sha256'] and r['cache_n']==0
        assert r['expected_prompt_tokens']==r['usage']['prompt_tokens']==p['tokens']
        assert r['sse_done'] and r['usage']['completion_tokens']<=p['max_tokens']
comparisons=[]
checks=[]
cache_checks=[]
for p in prompts:
    name=p['name']
    a,b=core[1][name],core[2][name]
    oa,ob=prior[1][name],prior[2][name]
    eq=a['text']==b['text']
    comparisons.append(dict(index=p['index'],name=name,category=p['category'],
        before_equal=oa['text']==ob['text'],after_equal=eq,
        after_json_value_equal=json_equal(a['text'],b['text']),
        tp1_changed=oa['text']!=a['text'],tp2_changed=ob['text']!=b['text'],
        finish_reason_equal=a['finish_reason']==b['finish_reason'],
        completion_count_equal=a['usage']['completion_tokens']==b['usage']['completion_tokens'],
        **({} if eq else diff(a['text'],b['text']))))
    expected={f'tp{tp}':check_answer(p,core[tp][name]['text']) for tp in (1,2)}
    if expected['tp1'] is not None:
        checks.append(dict(name=name,expected=p['expected'],**expected,
            before_tp1=check_answer(p,oa['text']),before_tp2=check_answer(p,ob['text'])))
    if p['cache_probe']:
        cache_checks.append(dict(name=name,**{
            f'tp{tp}':dict(cache_n=cached[tp][name]['cache_n'],
                cold_repeat_text_equal=core[tp][name]['text']==cached[tp][name]['text'],
                cold_repeat_json_value_equal=json_equal(core[tp][name]['text'],cached[tp][name]['text']))
            for tp in (1,2)},cross_tp_text_equal=cached[1][name]['text']==cached[2][name]['text']))
matched=[p['name'] for p in prompts if p['category']!='long-context'
    and len({core[tp][p['name']]['text'] for tp in (1,2)})==1
    and len({core[tp][p['name']]['usage']['completion_tokens'] for tp in (1,2)})==1]
common=[p['name'] for p in prompts if p['category']!='long-context'
    and len({group[tp][p['name']]['text'] for group in (core,prior) for tp in (1,2)})==1
    and len({group[tp][p['name']]['usage']['completion_tokens'] for group in (core,prior) for tp in (1,2)})==1
    and len({group[tp][p['name']]['finish_reason'] for group in (core,prior) for tp in (1,2)})==1]
timing={}
for label,group in (('before',prior),('after',core)):
    timing[label]={f'tp{tp}':{
        'short_uncached':performance([r for r in group[tp].values() if r['category']!='long-context']),
        'long_uncached':performance([r for r in group[tp].values() if r['category']=='long-context']),
        'same_outputs_all_four_modes':performance([group[tp][name] for name in common]),
        'new_matched_short':performance([group[tp][name] for name in matched]),
    } for tp in (1,2)}
before_bad=sum(not r['before_equal'] for r in comparisons)
after_bad=sum(not r['after_equal'] for r in comparisons)
report=dict(utc=datetime.now(timezone.utc).isoformat(),prompts=100,
    before_exact_matches=100-before_bad,after_exact_matches=100-after_bad,
    divergent_outputs_before=before_bad,divergent_outputs_after=after_bad,
    divergent_output_reduction_fraction=(before_bad-after_bad)/before_bad,
    tp1_profile_text_changes=sum(c['tp1_changed'] for c in comparisons),
    old_tp1_vs_new_tp2_exact_matches=sum(prior[1][p['name']]['text']==core[2][p['name']]['text'] for p in prompts),
    byte_identical_plus_json_value_equal=sum(r['after_equal'] or r['after_json_value_equal'] is True for r in comparisons),
    matching_finish_reasons=sum(r['finish_reason_equal'] for r in comparisons),
    matching_completion_counts=sum(r['completion_count_equal'] for r in comparisons),
    all_core_uncached=True,comparisons=comparisons,known_answer_checks=checks,
    known_answer_total=len(checks),known_answer_passes={f'tp{tp}':sum(c[f'tp{tp}'] for c in checks) for tp in (1,2)},
    known_answer_regressions={f'tp{tp}':[c['name'] for c in checks if c[f'before_tp{tp}'] and not c[f'tp{tp}']] for tp in (1,2)},
    finish_reasons={f'tp{tp}':dict(Counter(r['finish_reason'] for r in core[tp].values())) for tp in (1,2)},
    total_generated_completion_tokens=sum(r['usage']['completion_tokens'] for group in new.values() for r in group),
    cache_checks=cache_checks,new_matched_short=matched,all_four_same_outputs_short=common,
    timing=timing,run_summaries=json.loads((OUT/'run-summary.json').read_text()),
    limitations=[
        'Purpose-built set, one sequential pass; output agreement is separate from correctness.',
        'Before full100 used the preserved experimental e5856ac-based tree; after uses cleaned 14119b8-based tree plus v2. Small fresh controlled traces reproduce the remaining baseline problem.',
        'Auto expert cache differs across TP modes, so throughput includes cache residency benefits.',
        'Before/after full100 timings were taken at different times. Same-output subset controls token workload but does not establish a confidence interval.',
        'Per-request decode ms/token is an aggregate, not a distribution of individual token gaps.',
        'No NVIDIA, CPU/hybrid, other checkpoint, or TP>2 qualification.',
    ])
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
with (OUT/'timings.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=['tp','name','kind','input_tokens','output_tokens','ttft_seconds','wall_seconds','decode_ms_per_token','decode_tokens_per_second','cache_n'])
    writer.writeheader()
    for tp in (1,2):
        for r in new[tp]:
            writer.writerow(dict(tp=tp,name=r['name'],kind=r['kind'],input_tokens=r['usage']['prompt_tokens'],
                output_tokens=r['usage']['completion_tokens'],ttft_seconds=r['ttft_seconds'],wall_seconds=r['wall_seconds'],
                decode_ms_per_token=r['timings']['predicted_per_token_ms'],
                decode_tokens_per_second=r['timings']['predicted_per_second'],cache_n=r['cache_n']))
print(json.dumps({k:v for k,v in report.items() if k not in ('comparisons','timing','cache_checks','known_answer_checks')},indent=2))
