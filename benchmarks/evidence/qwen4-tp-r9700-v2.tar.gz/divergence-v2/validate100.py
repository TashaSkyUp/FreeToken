"""Run the original 100 prompts and ten cache-repeat attempts with tracing disabled."""

import hashlib
import json
import runpy
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPRO=ROOT.parent
REPO=REPRO.parent.parent
OUT=ROOT/'validation100-fp64'
TREE=REPO/'.worktrees/qwen4-tp-fp64'
OUT.mkdir(exist_ok=False)
for name in ('prompts.json','manifest.json'):
    shutil.copyfile(REPRO/'validation100'/name,OUT/name)
prompts=json.loads((OUT/'prompts.json').read_text())
manifest=json.loads((OUT/'manifest.json').read_text())
assert len(prompts)==100
assert hashlib.sha256((OUT/'prompts.json').read_bytes()).hexdigest()==manifest['prompts_sha256']
loaded=runpy.run_path(str(REPRO/'pr-draft/benchmark.py'))
ctx=loaded['run'].__globals__
ctx['ROOT']=OUT
ctx['FLAGS']=dict(ctx['FLAGS'],FREETOKEN_TP_REDUCTION_FP64='1')
ctx['FLAGS']['FREETOKEN_STABLE_ATTENTION']='1'
append_original=ctx['append']
complete_original=ctx['complete']
by_name={p['name']:p for p in prompts}
save=ctx['save']
now=ctx['now']
original_popen=subprocess.Popen
current=dict(stage='starting',utc=now())


def state(**values):
    current.update(values,utc=now())
    save(OUT/'state.json',current)
    append_original(OUT/'run.log',dict(current))


def popen(command,**kwargs):
    proc=original_popen(command,**kwargs)
    if '--tp-size' in command:
        state(stage='loading',tp=int(command[command.index('--tp-size')+1]),server_pid=proc.pid)
    return proc


def complete(tp,p,kind,flush):
    state(stage='request',tp=tp,name=p['name'],index=p['index'],kind=kind)
    return complete_original(tp,p,kind,flush)


def append(path,row):
    append_original(path,row)
    p=by_name[row['name']]
    if row['kind']=='core' and p['cache_probe']:
        cached=complete(row['tp'],p,'cache-repeat',None)
        cached['label']=row['label']
        append_original(path,cached)
        print(json.dumps(dict(event='cache-repeat',tp=row['tp'],name=p['name'],
                              cache_n=cached['cache_n'],wall_seconds=cached['wall_seconds'])),flush=True)


ctx['append']=append
ctx['complete']=complete
subprocess.Popen=popen
patch=subprocess.check_output(['git','diff','--binary'],cwd=TREE)
(OUT/'candidate.patch').write_bytes(patch)
(OUT/'provenance.json').write_text(json.dumps(dict(
    utc=datetime.now(timezone.utc).isoformat(),tree=str(TREE),
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE,text=True).strip(),
    patch_sha256=hashlib.sha256(patch).hexdigest(),
    tracing=False,replay=False,temperature=0,top_k=1,top_p=1,
    limitation='One sequential pass; auto expert cache; per-request timing includes disk PLE and expert offload.'),indent=2)+'\n')
state(stage='starting')
shutil.copyfile(REPRO/'validation100/monitor.py',OUT/'monitor.py')
monitor=original_popen([sys.executable,str(OUT/'monitor.py')])
results=[]
try:
    for tp in (1,2):
        results.append(loaded['run'](f'tp{tp}',TREE,tp,True,prompts))
        state(stage='mode-complete',tp=tp)
    (OUT/'run-summary.json').write_text(json.dumps(results,indent=2)+'\n')
    state(stage='complete')
except BaseException as error:
    state(stage='failed',error=repr(error))
    raise
finally:
    monitor.wait(timeout=10)
