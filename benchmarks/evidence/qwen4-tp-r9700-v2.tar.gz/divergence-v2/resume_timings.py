import json
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def state(stage,**extra):
    value=dict(stage=stage,utc=datetime.now(timezone.utc).isoformat(),**extra)
    temp=ROOT/'pipeline-state.tmp'
    temp.write_text(json.dumps(value,indent=2)+'\n')
    temp.replace(ROOT/'pipeline-state.json')
    print(json.dumps(value),flush=True)


state('resuming-fresh-before-after-timings')
try:
    subprocess.run([sys.executable,str(ROOT/'fresh_ab.py'),'--resume'],check=True)
    state('complete')
except BaseException as error:
    state('failed',error=repr(error))
    raise
