"""Compare aligned next-token distributions and eager prefill layer snapshots."""

import argparse
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('left')
parser.add_argument('right')
args = parser.parse_args()


def entries(label):
    folder = ROOT/(label+'-trace')
    grouped = {}
    for s in (folder/'tokens.jsonl').read_text().splitlines():
        row = json.loads(s)
        grouped.setdefault(row['key'], []).append(row)
    return folder, grouped


def difference(a, b):
    d = a.astype(np.float64) - b.astype(np.float64)
    return dict(rms=float(np.sqrt(np.mean(d*d))), max_abs=float(np.abs(d).max()),
                unequal=int(np.count_nonzero(d)), count=d.size)


lf, left = entries(args.left)
rf, right = entries(args.right)
result = dict(left=args.left, right=args.right, prompts=[])
for key, la in left.items():
    if key not in right:
        continue
    rb = right[key]
    assert len(la) == len(rb), (len(la), len(rb))
    prompt = dict(key=key, prompt_tokens=la[0]['prompt_len'], steps=len(la),
                  disagreements=[], metrics=[])
    for ea, eb in zip(la, rb):
        assert ea['step'] == eb['step']
        a = np.load(lf/ea['logits']).astype(np.float64)
        b = np.load(rf/eb['logits']).astype(np.float64)
        assert np.isfinite(a).all() and np.isfinite(b).all()
        d = a-b
        d -= d.mean()
        aa = a-a.max()
        bb = b-b.max()
        aa -= np.log(np.exp(aa).sum())
        bb -= np.log(np.exp(bb).sum())
        kl = float((np.exp(aa)*(aa-bb)).sum())
        metric = dict(step=ea['step'], centered_rms=float(np.sqrt(np.mean(d*d))),
                      kl=kl, argmax_equal=int(a.argmax()) == int(b.argmax()))
        prompt['metrics'].append(metric)
        if not metric['argmax_equal']:
            prompt['disagreements'].append(dict(step=ea['step'],
                tp1_token=int(a.argmax()), tp2_token=int(b.argmax()),
                tp1_margin=float(a[a.argmax()]-a[b.argmax()]),
                tp2_margin=float(b[b.argmax()]-b[a.argmax()])))
    an = np.load(lf/f'layers-{la[0]["uid"]}-rank0.npz')
    bn = np.load(rf/f'layers-{rb[0]["uid"]}-rank0.npz')
    prompt['layers'] = {name:difference(an[name], bn[name])
                        for name in an.files if name in bn and an[name].shape == bn[name].shape}
    result['prompts'].append(prompt)
metrics = [m for p in result['prompts'] for m in p['metrics']]
result['aggregate'] = dict(steps=len(metrics), disagreements=sum(not m['argmax_equal'] for m in metrics),
    mean_kl=float(np.mean([m['kl'] for m in metrics])),
    centered_rms=float(np.sqrt(np.mean([m['centered_rms']**2 for m in metrics]))))
out = ROOT/(args.left+'-vs-'+args.right+'.json')
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result['aggregate'], indent=2))
for p in result['prompts']:
    print(json.dumps(dict(prompt_tokens=p['prompt_tokens'], disagreements=p['disagreements'],
                         first_layers={k:v for k,v in p['layers'].items() if k.startswith(('00/','01/','02/','03/'))}),indent=2))
