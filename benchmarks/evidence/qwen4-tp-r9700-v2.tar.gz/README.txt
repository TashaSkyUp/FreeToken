Experimental Qwen3.8-Flash-Next NVFP4 TP precision evidence, v2.

Read docs/qwen4-exp-tp-r9700.md first. Historical v1 responses and their metadata
are under validation100/. New untraced 100-prompt inference, all 220 responses,
source hashes, commands, logs, cache checks and timing CSV are under
divergence-v2/validation100-fp64/.

verified-logit-summary.json separates 305 delivered prediction positions from
four queued extra forwards, and verifies raw FP32 bits across TP. The full NumPy
arrays remain local; local-array-manifest.json preserves their sizes and hashes.
Fresh before/after latency measurements are under fresh-ab/. The broad inference
pass had a concurrent memory workload and is not used to isolate v2 speed cost.

profile-quality/ compares OLD TP1 against NEW TP1. Its profile1/profile2 aliases
denote arithmetic profiles; both original response files retain actual tp=1.
Judge identities, forward/reversed presentation, rubric, schema, invocations,
final judgments and analysis are retained. Raw CLI events/hidden reasoning,
authentication material, model weights and RCCL/native binaries are omitted.

These are workspace-specific scratch harnesses, not new maintained test files.
They were executed under /root/experiments/FreeToken/.local-build/qwen38-repro.
Adjust local model/library/worktree paths before reproducing elsewhere. Existing
response directories are intentionally protected against overwriting.

MANIFEST.json hashes every other archive member; it does not hash itself.
