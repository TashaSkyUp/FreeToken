"""Build a reproducible, hashed evidence archive without credentials or CLI event logs."""

import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
REPO = REPRO.parent.parent
TREE = REPO / '.worktrees/qwen4-tp-pr'
OUT = TREE / 'benchmarks/evidence/qwen4-tp-r9700.tar.gz'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def build():
    if not (ROOT / 'main-branch-summary.json').exists():
        raise RuntimeError('Fresh main/branch comparison has not completed')
    historical = json.loads((REPRO / 'validation100/sources-before.json').read_text())
    for name, want in historical.items():
        source = (REPRO / name[6:] if name.startswith('repro/')
                  else REPO / '.worktrees/qwen38-tp' / name)
        if sha(source.read_bytes()) != want:
            raise RuntimeError(f'Historical source no longer matches: {name}')
    files = {}

    def add(prefix, names):
        for name in names:
            source = REPRO / prefix / name
            files[str(Path(prefix) / name)] = source.read_bytes()

    add('', ['environment.json', 'serve.sh', 'serve-precise.sh',
             'current-main-with-precision.patch', 'prompts.json',
             'tp1-speed-responses.jsonl', 'tp2-speed-responses.jsonl',
             'residual-free-tp1-responses.jsonl', 'residual-free-tp2-responses.jsonl'])
    add('iterations', ['final-free-metrics.json', 'snapshot-state-proof.json',
                      'linear-shape-proof.json', 'stable-linear-proof.json',
                      'MEASUREMENT.txt', 'inference-precision-fix.patch'])
    add('validation100', ['prompts.json', 'manifest.json', 'summary.json',
                         'tp1-responses.jsonl', 'tp2-responses.jsonl',
                         'tp1-server.log', 'tp2-server.log',
                         'tp1-settings.json', 'tp2-settings.json',
                         'sources-before.json', 'sources-after.json', 'timings.csv',
                         'RESULTS.txt', 'README.txt', 'report.html',
                         'latency.png', 'timeline.png', 'latency.svg', 'timeline.svg',
                         'resource-timeline.jsonl',
                         'run.py', 'prepare.py', 'monitor.py', 'analyze.py', 'plot.py'])
    add('validation100/terra-max-judgments', [
        'summary.json', 'paired-summary.json', 'judgments.jsonl', 'scores.csv',
        'RESULTS.txt', 'README.txt', 'rubric.txt', 'schema.json', 'manifest.json',
        'verification.json', 'parser-fix-provenance.json', 'judge_outputs.executed.py'])
    add('validation100', ['judge_outputs.py', 'analyze_judgments.py'])
    add('pr-draft', ['benchmark.py', 'package_evidence.py', 'benchmark.log', 'main-branch-summary.json',
                     'config-weight-tests.log', 'precision-gpu-tests.log',
                     'build-compatible.log', 'build.log', 'fresh-checks.json',
                     'main-tp2-refusal.json', 'ast-comparison.json'])
    for label in ('main-tp1', 'branch-tp1', 'branch-tp2'):
        add('pr-draft', [f'{label}-{suffix}' for suffix in (
            'responses.jsonl', 'settings.json', 'server.log', 'summary.json')])
    add('pr-draft/memory-pressure-attempt', ['NOTE.txt'])
    notes = (
        'Historical 100-prompt measurements are from e5856ac plus the archived experimental patch.\n'
        'All 500 frozen source/launcher/library hashes were verified before packaging.\n'
        'Fresh branch checks and the three-prompt main/branch A/B use base 14119b8.\n'
        'The complete 100-prompt run was not repeated on the cleaned branch.\n'
        'Historical trace/replay hooks are in the archived patch but were disabled for ordinary generation.\n'
        'The reusable Codex judge parser was repaired after the run; the executed version is archived separately.\n'
        'No model weights, RCCL binaries, authentication files or raw Codex CLI events are distributed.\n'
        'Paths in the launchers/settings describe the original machine; adapt them for a new checkout.\n'
        'The prefix-cache rebuild e2e gate was not run: no suitable small supported checkpoint is installed.\n'
    )
    files['README.txt'] = notes.encode()
    manifest = dict(format_version=1, historical_base='e5856ac471ec4747ada27f0ba506b816f1506593',
                    fresh_base='14119b8cbb8bd0a1e20410d5f1371f2412a6f338',
                    historical_frozen_files_verified=len(historical),
                    files={name: dict(bytes=len(data), sha256=sha(data))
                           for name, data in sorted(files.items())})
    files['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open('wb') as target:
        with gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, data in sorted(files.items()):
                    member = tarfile.TarInfo(name)
                    member.size = len(data)
                    member.mode = 0o644
                    archive.addfile(member, io.BytesIO(data))
    with tarfile.open(OUT, 'r:gz') as archive:
        for name, expected in manifest['files'].items():
            data = archive.extractfile(name).read()
            if len(data) != expected['bytes'] or sha(data) != expected['sha256']:
                raise RuntimeError(f'Archive verification failed: {name}')
    print(json.dumps(dict(path=str(OUT), bytes=OUT.stat().st_size,
                         sha256=sha(OUT.read_bytes()), verified_members=len(manifest['files']))))


if __name__ == '__main__':
    build()
