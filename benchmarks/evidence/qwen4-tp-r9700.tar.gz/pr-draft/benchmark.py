"""Small, sequential main/branch end-to-end comparison; preserve every response."""

import ast
import hashlib
import json
import os
import signal
import statistics
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
REPO = REPRO.parent.parent
URL = 'http://127.0.0.1:2959'
FLAGS = {name: '1' for name in (
    'FREETOKEN_TP_PRECISE', 'FREETOKEN_GDN_SNAPSHOT_FP32',
    'FREETOKEN_ROUTER_FP32', 'FREETOKEN_STABLE_LINEAR', 'FREETOKEN_RESIDUAL_FP32',
)}

# Reuse the frozen SSE validation/client functions without running its controller.
client_source = REPRO / 'validation100/run.py'
parsed = ast.parse(client_source.read_text())
functions = {'now', 'digest', 'save', 'get', 'post', 'flush_cache', 'complete', 'append', 'stop'}
module = ast.Module(body=[n for n in parsed.body
                         if isinstance(n, ast.FunctionDef) and n.name in functions], type_ignores=[])
exec(compile(module, str(client_source), 'exec'), globals())


def hashes(tree):
    return {str(p.relative_to(tree)): digest(p)
            for p in sorted((tree / 'python/freetoken').rglob('*.py'))}


def run(label, tree, tp, precise, prompts):
    out = ROOT / f'{label}-responses.jsonl'
    if out.exists():
        raise RuntimeError(f'Refusing to overwrite {out}')
    env = os.environ.copy()
    for name in tuple(env):
        if name.startswith('FREETOKEN_'):
            del env[name]
    env.update(PYTHONPATH=str(tree / 'python'), HIP_VISIBLE_DEVICES='0,1',
               OMP_NUM_THREADS='4', OMP_WAIT_POLICY='PASSIVE')
    env['LD_PRELOAD'] = ':'.join((
        str(REPO / '.venv/lib/python3.12/site-packages/torch/lib/libamdhip64.so'),
        str(REPRO / 'rccl/librccl.so'),
    ))
    if precise:
        env.update(FLAGS)
    command = [sys.executable, '-m', 'freetoken.cli', 'serve',
               '--model', '/models-fast/206-comfyui-models/LLM/Qwen3.8-Flash-Next-NVFP4',
               '--served-model-name', 'qwen38-repro', '--tp-size', str(tp),
               '--disable-pynccl', '--moe-strategy', 'offload', '--expert-load', 'parallel',
               '--quant-backend', 'moe.nvfp4=triton', '--ple-backend', 'disk',
               '--text-model-only', '--moe-cache-auto', '--kv-reserve-tokens', '16384',
               '--num-tokens', '16384', '--max-seq-len-override', '16384',
               '--memory-ratio', '0.90', '--max-running-requests', '1',
               '--cuda-graph-max-bs', '1', '--max-prefill-length', '1024',
               '--enable-timings-report', '--enable-cache-report',
               '--reasoning-parser', 'off', '--host', '127.0.0.1', '--port', '2959']
    before = hashes(tree)
    save(ROOT / f'{label}-settings.json', dict(
        utc=now(), tree=str(tree), main_sha=subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip(), command=command,
        environment={name: env[name] for name in (
            'PYTHONPATH', 'HIP_VISIBLE_DEVICES', 'OMP_NUM_THREADS', 'OMP_WAIT_POLICY',
            'LD_PRELOAD', *FLAGS) if name in env}, source_hashes=before,
        tracing=False, replay=False, prompts=prompts))
    print(json.dumps(dict(event='starting', label=label, utc=now())), flush=True)
    proc = None
    start = time.monotonic()
    try:
        with (ROOT / f'{label}-server.log').open('w') as log:
            proc = subprocess.Popen(command, cwd=tree, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 600
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError(f'{label} exited: {proc.returncode}')
                try:
                    health = get('/health')
                except (OSError, ValueError):
                    health = {}
                if health.get('status') == 'ok':
                    break
                if health.get('status') == 'error':
                    raise RuntimeError(health)
                time.sleep(2)
            else:
                raise TimeoutError(f'{label} startup')
            ready_seconds = time.monotonic() - start
            rows = []
            for prompt in prompts:
                flush = flush_cache()
                row = complete(tp, prompt, 'core', flush)
                row['label'] = label
                if row['cache_n'] != 0:
                    raise RuntimeError('Main/branch comparison unexpectedly reused a prefix')
                append(out, row)
                rows.append(row)
                print(json.dumps(dict(event='response', label=label, name=prompt['name'],
                      tokens=row['usage']['completion_tokens'], ttft=row['ttft_seconds'],
                      decode=row['timings']['predicted_per_second'])), flush=True)
            after = hashes(tree)
            if after != before:
                raise RuntimeError('Inference sources changed during run')
            result = dict(label=label, tp=tp, precision=precise, ready_seconds=ready_seconds,
                          source_hashes_unchanged=True, requests=len(rows),
                          median_decode_tokens_per_second=statistics.median(
                              row['timings']['predicted_per_second'] for row in rows),
                          median_ttft_seconds=statistics.median(row['ttft_seconds'] for row in rows),
                          median_response_seconds=statistics.median(row['wall_seconds'] for row in rows))
            save(ROOT / f'{label}-summary.json', result)
            return result
    finally:
        stop(proc)


if __name__ == '__main__':
    all_prompts = json.loads((REPRO / 'validation100/prompts.json').read_text())
    names = ('first-nonrepeating-anchor', 'tank-anchor', 'json-extract')
    prompts = [next(p for p in all_prompts if p['name'] == name) for name in names]
    try:
        get('/health')
    except OSError:
        pass
    else:
        raise RuntimeError('Port 2959 is already in use')
    summaries = []
    for label, dirname, tp, precise in (
        ('main-tp1', 'qwen4-tp-main', 1, False),
        ('branch-tp1', 'qwen4-tp-pr', 1, True),
        ('branch-tp2', 'qwen4-tp-pr', 2, True),
    ):
        summaries.append(run(label, REPO / '.worktrees' / dirname, tp, precise, prompts))
    save(ROOT / 'main-branch-summary.json', dict(utc=now(), summaries=summaries,
         limitation='Three uncached short prompts per configuration; one sequential pass. '
                    'Not a confidence interval, long-context benchmark, or fixed-cache scaling test.'))
    print(json.dumps(summaries, indent=2), flush=True)
