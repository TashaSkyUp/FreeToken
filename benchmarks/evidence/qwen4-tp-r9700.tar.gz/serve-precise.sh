#!/usr/bin/env bash
set -euo pipefail
export FREETOKEN_TP_PRECISE=1
export FREETOKEN_GDN_SNAPSHOT_FP32=1
export FREETOKEN_ROUTER_FP32=1
export FREETOKEN_STABLE_LINEAR=1
export FREETOKEN_RESIDUAL_FP32=1
exec /root/experiments/FreeToken/.local-build/qwen38-repro/serve.sh "${1:-2}"
