Historical 100-prompt measurements are from e5856ac plus the archived experimental patch.
All 500 frozen source/launcher/library hashes were verified before packaging.
Fresh branch checks and the three-prompt main/branch A/B use base 14119b8.
The complete 100-prompt run was not repeated on the cleaned branch.
Historical trace/replay hooks are in the archived patch but were disabled for ordinary generation.
The reusable Codex judge parser was repaired after the run; the executed version is archived separately.
No model weights, RCCL binaries, authentication files or raw Codex CLI events are distributed.
Paths in the launchers/settings describe the original machine; adapt them for a new checkout.
The prefix-cache rebuild e2e gate was not run: no suitable small supported checkpoint is installed.
