import json
from datetime import datetime
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
report = json.loads((ROOT / 'summary.json').read_text())
rows = {tp: [json.loads(l) for l in (ROOT / f'tp{tp}-responses.jsonl').read_text().splitlines()] for tp in (1, 2)}
core = {tp: [r for r in rs if r['kind'] == 'core'] for tp, rs in rows.items()}
colors = {1: '#2166ac', 2: '#df7b21'}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.alpha': .18,
                     'savefig.facecolor': 'white'})

fig, axs = plt.subplots(2, 2, figsize=(13, 9), constrained_layout=True)
for tp in (1, 2):
    rs = core[tp]
    x = [r['index'] for r in rs]
    axs[0, 0].plot(x, [r['ttft_seconds'] for r in rs], '.-', color=colors[tp], label=f'TP={tp}', markersize=3, lw=1)
    axs[0, 1].plot(x, [r['wall_seconds'] for r in rs], '.-', color=colors[tp], label=f'TP={tp}', markersize=3, lw=1)
    multi = [r for r in rs if r['usage']['completion_tokens'] > 1]
    axs[1, 0].plot([r['index'] for r in multi], [r['timings']['predicted_per_token_ms'] for r in multi],
                    '.-', color=colors[tp], label=f'TP={tp}', markersize=3, lw=1)
    cold = {r['name']: r for r in rs if r['category'] == 'long-context'}
    cache = {r['name']: r for r in rows[tp] if r['kind'] == 'cache-repeat'}
    names = sorted(cold, key=lambda k: cold[k]['usage']['prompt_tokens'])
    for source, style, label in [(cold, 'o-', 'uncached'), (cache, 's--', 'cached')]:
        active = [n for n in names if source is cold or source[n]['cache_n'] > 0]
        axs[1, 1].plot([cold[n]['usage']['prompt_tokens'] for n in active],
                      [source[n]['ttft_seconds'] for n in active], style,
                      color=colors[tp], label=f'TP={tp} {label}', markersize=4, lw=1)
    misses = [n for n in names if cache[n]['cache_n'] == 0]
    if misses:
        axs[1, 1].scatter([cold[n]['usage']['prompt_tokens'] for n in misses],
                         [cache[n]['ttft_seconds'] for n in misses], marker='x',
                         color=colors[tp], label=f'TP={tp} repeat, no cache hit')
for ax in axs.flat:
    ax.legend(frameon=False, fontsize=9)
for ax in [axs[0, 0], axs[0, 1], axs[1, 0]]:
    ax.set_xlabel('Distinct prompt index (same order in both modes)')
    ax.axvline(90.5, ls=':', color='#7a8694', lw=1)
axs[0, 0].set(title='Time to first returned text', ylabel='Seconds')
axs[0, 1].set(title='Complete response latency', ylabel='Seconds')
axs[1, 0].set(title='Mean decode time per token, per request', ylabel='Milliseconds / token')
axs[1, 1].set(title='Long-context first-token latency', ylabel='Seconds', xlabel='Input tokens')
fig.suptitle('100 paired Qwen3.8 outputs: latency in time units\nSingle sequential pass per mode; initial requests retained; up to 128 output tokens', fontsize=14)
for suffix in ['png', 'svg']:
    fig.savefig(ROOT / f'latency.{suffix}', dpi=170)
plt.close(fig)

timeline = [json.loads(l) for l in (ROOT / 'resource-timeline.jsonl').read_text().splitlines()]
stages = [json.loads(l) for l in (ROOT / 'run.log').read_text().splitlines()]
t0 = datetime.fromisoformat(next(r['utc'] for r in stages if r.get('stage') == 'loading'))


def minute(utc):
    return (datetime.fromisoformat(utc) - t0).total_seconds() / 60


fig, axs = plt.subplots(4, 1, figsize=(13, 12), sharex=True, constrained_layout=True)
for tp in (1, 2):
    for kind, marker in [('core', 'o'), ('cache-repeat', 'x')]:
        rs = [r for r in rows[tp] if r['kind'] == kind]
        axs[0].scatter([minute(r['utc']) for r in rs], [r['wall_seconds'] for r in rs],
                       color=colors[tp], marker=marker, s=18,
                       label=f'TP={tp} {kind}')
xs = [minute(r['utc']) for r in timeline]
gpu_colors = {'0000:25:00.0': '#326f9e', '0000:30:00.0': '#a05b9e'}
for pci, color in gpu_colors.items():
    ds = [next(d for d in r['devices'] if d['pci'] == pci) for r in timeline]
    axs[1].plot(xs, [d['gpu_busy_percent'] for d in ds], color=color, lw=.7, alpha=.8, label=f'R9700 {pci}')
    axs[2].plot(xs, [d['vram_used_bytes']/2**30 for d in ds], color=color, lw=1, label=f'VRAM {pci}')
axs[2].plot(xs, [(r['memory']['MemTotal']-r['memory']['MemAvailable'])/2**30 for r in timeline],
            color='#1d7955', lw=1, label='Host RAM: total minus available')
axs[3].plot(xs, [r['server'].get('cpu_cores_used_interval', np.nan) for r in timeline],
            color='#745b24', lw=.7, label='Server process tree')
for ax in axs:
    ax.legend(loc='upper left', frameon=False, fontsize=9)
    for s in stages:
        if s.get('stage') == 'loading' and s.get('tp') == 2:
            ax.axvline(minute(s['utc']), color='#56616e', ls='--', lw=1)
axs[0].set(title='Response completion times (each marker is one output)', ylabel='Response seconds')
axs[1].set(title='GPU activity (1-second samples)', ylabel='GPU busy %', ylim=(-3, 103))
axs[2].set(title='Host and GPU memory', ylabel='GiB')
axs[3].set(title='CPU usage of the server and child processes', ylabel='CPU cores used', xlabel='Elapsed minutes from first server launch')
fig.suptitle('Performance over elapsed time\nDashed line: TP2 launch; resource sampling begins during the first TP1 request', fontsize=14)
for suffix in ['png', 'svg']:
    fig.savefig(ROOT / f'timeline.{suffix}', dpi=170)
plt.close(fig)
(ROOT / 'plot-metadata.json').write_text(json.dumps(dict(matplotlib=matplotlib.__version__, numpy=np.__version__), indent=2)+'\n')
