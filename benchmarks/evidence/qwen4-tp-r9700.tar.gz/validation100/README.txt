This directory contains a local, frozen 100-prompt TP1/TP2 validation run.

Open report.html after the run completes. RESULTS.txt and summary.json contain
the numerical summary; timings.csv has one timing row for each response.
latency.png/svg compare time to first token, response time, and decode time.
timeline.png/svg show the progression of responses and resource use over time.

The 100 distinct prompts contain ten examples in each of ten categories:
coding, arithmetic, logic, structured output, text transformations, multilingual
responses, instruction following, writing, systems, and long-context retrieval.
The original three regression cases are included as named anchors. Each of the
ten long-context prompts gets one immediate cached repeat, outside the core 100.
This gives 110 responses per TP mode, 220 responses in total.

prompts.json is immutable after generation and is hashed by manifest.json.
All requests use greedy generation with a maximum of 128 completion tokens.
Long responses can therefore finish with reason=length. A length cap is not a
network or engine failure; the returned text and finish reason are preserved.
Known-answer/format checks are independent of cross-TP text agreement.

run.py launches one mode at a time using ../serve-precise.sh. Both modes have
all five precision flags, the same checkpoint, order, and request settings.
No token replay or full-logit tracing is enabled. The script rejects incomplete
SSE streams, missing timings, incorrect usage totals, and unexpected endings.
It checks all Python inference-source and launcher hashes before/after each mode.
It terminates only its own process group when a mode ends or encounters an error.

TP1 supports prefix-cache flush before each distinct prompt. TP2 rejects that
operation, so every prompt has an unrelated prefix; actual cached-token counts
are recorded and checked in the final analysis. Long repeats intentionally avoid
the flush. A repeat only demonstrates cache behavior when cache_n is positive.
The expert offload cache remains active and its automatically chosen capacity
differs with GPU count. This is a practical end-to-end comparison of those
configurations, not a pure communication or linear-scaling benchmark.

Time-domain measurements:
- Client TTFT: request start to first nonempty returned text event.
- Client response latency: request start to the SSE [DONE] marker.
- Engine decode milliseconds/token and tokens/second: server timing counters;
  requests with fewer than two completion tokens are excluded from decode stats.
  Percentiles describe per-request means, not individual inter-token gaps.
- Queue time: server timing counter in milliseconds.
- Startup: process launch to health status=ok; existing disk/JIT caches retained.
- Resource samples: 1 Hz sysfs sensors and /proc counters, with UTC/monotonic
  timestamps, stage, and active prompt. Sampling starts during the first TP1
  request; startup duration comes from controller timestamps. These are coarse
  resource samples, not per-kernel traces. Process-tree
  RSS can count shared pages in more than one process; host available RAM is also
  recorded. CPU usage is in CPU-core equivalents, not percent of all host cores.
- Single sequential pass per mode; latency percentiles describe this workload
  and include early slow requests. They are not confidence intervals over trials.

Local scope:
FreeToken current-main e5856ac471ec4747ada27f0ba506b816f1506593 with a local
PR385 TP adaptation and opt-in precision fixes in .worktrees/qwen38-tp.
Checkpoint RadixArk/Qwen3.8-Flash-Next-NVFP4, revision
7b719225242aacd3dbd3f9407468c2ee9a9d2594. Two R9700s; host expert offload;
task-local RCCL override. See ../environment.json and the server logs.
The main source installation is unchanged. No upstream changes are published.

This is a purpose-built regression set, not a random sample or an independent
reference-engine accuracy evaluation. Matching response text does not establish
bitwise logit parity or guarantee identical behavior on all future prompts.

To repeat without overwriting evidence, create a fresh sibling directory,
copy prepare.py, run.py, monitor.py, analyze.py, plot.py, prompts.json, and
manifest.json there, and launch run.py from that directory with the repository's
.venv/bin/python. Run monitor.py alongside it. Run analyze.py after completion,
then plot.py in an environment containing matplotlib and numpy. Both wrappers
bind localhost port 2959 and require the already downloaded checkpoint.
