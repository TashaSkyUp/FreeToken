Completed blinded Codex evaluation: 100 TP1/TP2 output pairs, two orders.

Open report.html for all scores, rationales, original requests, and responses.
RESULTS.txt is the short numerical report. scores.csv has 200 evaluation rows.
paired-summary.json maps both orders to the original TP identities.
judgments.jsonl contains the accepted raw judgments and call metadata.

Model: gpt-6.1-terra, reasoning effort max. This was the latest Terra listed in
the CLI model catalog on 2026-11-07; see model-catalog-evidence.json. The model ID
is pinned for the entire run. Existing Codex ChatGPT authentication was used.

Three dimensions, all scored 0-4:
- Correctness: factual, mathematical, logical, and technical validity of each
  response. A null score is allowed when assessment is not meaningful.
- Instruction-following and completeness: delivery of the original request,
  including required format and complete requested artifacts.
- Semantic similarity: one symmetric score comparing the response meanings.
  Different valid creative content can receive equal quality but lower similarity.

The judge receives the original request, A/B text, and finish reasons. It does
not receive TP identities, inference speed, prior judgments, or reference labels.
The original 128-token completion cap is disclosed so truncation is visible;
the rubric still penalizes incomplete delivered responses. The 74 identical
source pairs are retained as controls. The 26 differing pairs are summarized
separately so identical controls do not conceal their behavior.

Forward: sample submission order 1 to 100, A=TP1, B=TP2.
Reversed: submission order 100 to 1, A=TP2, B=TP1.
There is a full barrier between passes. Each pass uses a rolling pool of up to
20 CLI processes. Actual start/completion order within that pool varies.
All 200 accepted judgments were collected; observed maximum concurrency was 20.

Rerun into a fresh output directory, from this README's parent directory:

  python3 judge_outputs.py --out-dir terra-max-rerun --workers 20 \
    --model gpt-6.1-terra --reasoning max

The script validates source hashes and run configuration. An interrupted run can
be resumed with the same command and unchanged script. Successful results are
reused; incomplete calls get bounded retries. --prepare-only creates the frozen
manifest without model calls. --smoke evaluates the first sample and preserves
that result for a subsequent full run under identical settings.

Summarize a completed run:

  python3 analyze_judgments.py --run-dir terra-max-rerun

Model calls run in an empty temporary working directory, read-only, with shell,
apps/plugins, hooks, browsing, and delegation disabled. No inference outputs or
repository source were changed. Prompts and response files remain hash-identical.

Parser correction and invocation accounting:
The main run made 242 CLI invocations to obtain its 200 accepted judgments.
42 already-completed calls were unnecessarily retried because the initial parser
misclassified the CLI's informational WebSockets-to-HTTPS fallback notice as an
unexpected item. All receipts are preserved. This rejection did not depend on
the judgment scores. The reusable script now accepts that notice only alongside
a successful, schema-valid turn. Its corrected parser was checked offline against
all 242 recorded invocations; no extra model calls were made for that check.
The script actually used for the run is archived as judge_outputs.executed.py,
matching manifest.json's harness hash. parser-fix-provenance.json records the
post-run correction. Three earlier preflight calls are preserved in the sibling
terra-max-preflight-parser-notices directory and excluded from the main data.

One evaluation per presentation order cannot isolate position bias from ordinary
judge variability. The report therefore says order-sensitive, not proven bias.
These model judgments do not establish ground-truth accuracy or numerical/logit
parity. Review the cases and rationales before treating differences as material.
