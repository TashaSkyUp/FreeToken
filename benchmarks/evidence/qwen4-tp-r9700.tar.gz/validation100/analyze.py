import csv
import difflib
import hashlib
import html
import json
import math
import statistics
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def quantile(values, q):
    s = sorted(v for v in values if v is not None and math.isfinite(v))
    if not s:
        return None
    z = (len(s) - 1) * q
    lo = int(z)
    return s[lo] + (s[min(lo+1, len(s)-1)] - s[lo]) * (z-lo)


def distribution(values):
    values = [v for v in values if v is not None and math.isfinite(v)]
    return dict(n=len(values), mean=statistics.mean(values) if values else None,
                min=min(values) if values else None, p50=quantile(values, .5),
                p90=quantile(values, .9), p95=quantile(values, .95),
                p99=quantile(values, .99), max=max(values) if values else None)


def performance(rows):
    multi = [r for r in rows if r['usage']['completion_tokens'] > 1]
    return dict(requests=len(rows),
                completion_tokens=sum(r['usage']['completion_tokens'] for r in rows),
                total_client_request_seconds=sum(r['wall_seconds'] for r in rows),
                ttft_seconds=distribution([r['ttft_seconds'] for r in rows]),
                response_seconds=distribution([r['wall_seconds'] for r in rows]),
                engine_decode_ms_per_token=distribution([r['timings']['predicted_per_token_ms'] for r in multi]),
                engine_decode_tokens_per_second=distribution([r['timings']['predicted_per_second'] for r in multi]),
                client_decode_tokens_per_second=distribution([r['decode_tokens_per_second'] for r in multi]),
                engine_queue_ms=distribution([r['timings']['queue_ms'] for r in rows]),
                cache_tokens=distribution([r['cache_n'] for r in rows]),
                finish_reasons=dict(Counter(r['finish_reason'] for r in rows)))


def check_answer(p, text):
    expected = p['expected']
    if expected is None:
        return None
    actual = text.strip()
    if isinstance(expected, (dict, list)):
        try:
            parsed = json.loads(actual)
            return json.dumps(parsed, sort_keys=True, ensure_ascii=False) == json.dumps(expected, sort_keys=True, ensure_ascii=False)
        except ValueError:
            return False
    if p['name'] == 'ordering':
        return [v.strip() for v in actual.split(',')] == expected.split(',')
    if p['name'] == 'graph-path':
        return set(actual.splitlines()) == set(expected.splitlines())
    return actual == expected


def diff(a, b):
    n = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
    return dict(first_different_character=n, common_prefix_characters=n,
                tp1_excerpt=a[max(0,n-60):n+140], tp2_excerpt=b[max(0,n-60):n+140],
                character_similarity=difflib.SequenceMatcher(None, a, b, autojunk=False).ratio())


def json_equal(a, b):
    try:
        x, y = json.loads(a), json.loads(b)
    except ValueError:
        return None
    if not isinstance(x, (dict, list)) or not isinstance(y, (dict, list)):
        return None
    return json.dumps(x, sort_keys=True, ensure_ascii=False) == json.dumps(y, sort_keys=True, ensure_ascii=False)


def analyze():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    assert hashlib.sha256((ROOT / 'prompts.json').read_bytes()).hexdigest() == manifest['prompts_sha256']
    prompts = json.loads((ROOT / 'prompts.json').read_text())
    data = {tp: load_rows(ROOT / f'tp{tp}-responses.jsonl') for tp in (1, 2)}
    for tp, rows in data.items():
        assert len(rows) == 110, (tp, len(rows))
        assert Counter(r['kind'] for r in rows) == {'core': 100, 'cache-repeat': 10}
        assert all(r['sse_done'] for r in rows)
        for p in prompts:
            matching = [r for r in rows if r['name'] == p['name']]
            assert len(matching) == (2 if p['cache_probe'] else 1)
            assert all(r['prompt_sha256'] == p['sha256'] for r in matching)
            assert all(r['usage']['prompt_tokens'] == p['tokens'] for r in matching)
    assert json.loads((ROOT / 'sources-before.json').read_text()) == json.loads((ROOT / 'sources-after.json').read_text())
    core = {tp: {r['name']: r for r in data[tp] if r['kind'] == 'core'} for tp in (1, 2)}
    cached = {tp: {r['name']: r for r in data[tp] if r['kind'] == 'cache-repeat'} for tp in (1, 2)}
    comparisons = []
    quality = []
    for p in prompts:
        a, b = core[1][p['name']], core[2][p['name']]
        eq = a['text'] == b['text']
        row = dict(index=p['index'], name=p['name'], category=p['category'],
                   input_tokens=p['tokens'], exact_text_equal=eq,
                   json_value_equal=json_equal(a['text'], b['text']),
                   finish_reason_equal=a['finish_reason'] == b['finish_reason'],
                   completion_token_count_equal=a['usage']['completion_tokens'] == b['usage']['completion_tokens'],
                   tp1_cache_n=a['cache_n'], tp2_cache_n=b['cache_n'],
                   ttft_speedup_tp2=a['ttft_seconds']/b['ttft_seconds'],
                   response_speedup_tp2=a['wall_seconds']/b['wall_seconds'],
                   **({} if eq else diff(a['text'], b['text'])))
        comparisons.append(row)
        checks = {f'tp{tp}': check_answer(p, core[tp][p['name']]['text']) for tp in (1, 2)}
        if checks['tp1'] is not None:
            quality.append(dict(name=p['name'], category=p['category'], expected=p['expected'], **checks))
    cache_checks = []
    for p in prompts:
        if not p['cache_probe']:
            continue
        name = p['name']
        cache_checks.append(dict(name=name, input_tokens=p['tokens'],
            tp1_cold_cache_equal=core[1][name]['text'] == cached[1][name]['text'],
            tp2_cold_cache_equal=core[2][name]['text'] == cached[2][name]['text'],
            cached_cross_tp_equal=cached[1][name]['text'] == cached[2][name]['text'],
            tp1_cold_cache_json_value_equal=json_equal(core[1][name]['text'], cached[1][name]['text']),
            tp2_cold_cache_json_value_equal=json_equal(core[2][name]['text'], cached[2][name]['text']),
            cached_cross_tp_json_value_equal=json_equal(cached[1][name]['text'], cached[2][name]['text']),
            tp1_cache_n=cached[1][name]['cache_n'], tp2_cache_n=cached[2][name]['cache_n'],
            tp1_cache_hit=cached[1][name]['cache_n'] > 0,
            tp2_cache_hit=cached[2][name]['cache_n'] > 0))
    timing = {}
    matched_names = {r['name'] for r in comparisons if r['exact_text_equal']
                     and r['completion_token_count_equal'] and r['finish_reason_equal']}
    for tp in (1, 2):
        rows = list(core[tp].values())
        timing[f'tp{tp}'] = dict(
            core_all=performance(rows),
            short_uncached=performance([r for r in rows if r['category'] != 'long-context']),
            long_uncached=performance([r for r in rows if r['category'] == 'long-context']),
            long_cached=performance([r for r in cached[tp].values() if r['cache_n'] > 0]),
            long_repeat_cache_miss=performance([r for r in cached[tp].values() if r['cache_n'] == 0]),
            matched_core=performance([r for r in rows if r['name'] in matched_names]),
            matched_short=performance([r for r in rows if r['name'] in matched_names and r['category'] != 'long-context']),
            by_category={c: performance([r for r in rows if r['category'] == c]) for c in manifest['categories']})
    stages = [r for r in load_rows(ROOT / 'run.log') if 'stage' in r]
    for tp in (1, 2):
        t = {r['stage']: datetime.fromisoformat(r['utc']) for r in stages if r.get('tp') == tp}
        timing[f'tp{tp}']['startup_to_health_ready_seconds'] = (t['generating'] - t['loading']).total_seconds()
        timing[f'tp{tp}']['workload_elapsed_seconds'] = (t['mode-complete'] - t['generating']).total_seconds()
    categories = {c: dict(total=10, exact_matches=sum(r['exact_text_equal'] for r in comparisons if r['category'] == c))
                  for c in manifest['categories']}
    report = dict(manifest=manifest, exact_core_matches=sum(r['exact_text_equal'] for r in comparisons),
         matching_finish_reasons=sum(r['finish_reason_equal'] for r in comparisons),
         matching_completion_token_counts=sum(r['completion_token_count_equal'] for r in comparisons),
         core_comparisons=100, exact_cache_cross_tp_matches=sum(r['cached_cross_tp_equal'] for r in cache_checks),
         cache_comparisons=10, cache_checks=cache_checks, by_category=categories,
         all_core_uncached=all(r['tp1_cache_n'] == r['tp2_cache_n'] == 0 for r in comparisons),
         known_answer_checks=quality,
         known_answer_passes={f'tp{tp}': sum(q[f'tp{tp}'] for q in quality) for tp in (1, 2)},
         performance=timing, comparisons=comparisons,
         prompt_source_and_launch_hashes_verified=True,
         total_generated_completion_tokens=sum(r['usage']['completion_tokens'] for rows in data.values() for r in rows))
    timeline = load_rows(ROOT / 'resource-timeline.jsonl')
    resources = {}
    for tp in (1, 2):
        samples = [r for r in timeline if r['state'].get('tp') == tp and r['state']['stage'] in ('request', 'cache-repeat')]
        gpu = {}
        for pci in sorted({d['pci'] for r in samples for d in r['devices']}):
            ds = [d for r in samples for d in r['devices'] if d['pci'] == pci]
            gpu[pci] = {key: distribution([d[key] for d in ds]) for key in
                        ['gpu_busy_percent', 'vram_used_bytes', 'power_watts', 'junction_celsius']}
        resources[f'tp{tp}'] = dict(samples=len(samples),
             minimum_available_ram_gib=min(r['memory']['MemAvailable'] for r in samples)/2**30,
             peak_server_tree_rss_gib=max(r['server']['rss_bytes'] for r in samples)/2**30,
             server_cpu_cores=distribution([r['server'].get('cpu_cores_used_interval') for r in samples]), gpus=gpu)
    report['resources'] = resources
    (ROOT / 'summary.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
    fields = ['index', 'name', 'category', 'kind', 'prompt_tokens', 'completion_tokens',
              'finish_reason', 'utc', 'cache_n', 'ttft_seconds', 'wall_seconds',
              'decode_ms_per_token', 'decode_tokens_per_second', 'queue_ms']
    with (ROOT / 'timings.csv').open('w') as f:
        w = csv.DictWriter(f, fieldnames=['tp']+fields)
        w.writeheader()
        for tp in (1, 2):
            for r in data[tp]:
                w.writerow(dict(tp=tp, **({k:r[k] for k in fields if k in r} | dict(
                    prompt_tokens=r['usage']['prompt_tokens'], completion_tokens=r['usage']['completion_tokens'],
                    decode_ms_per_token=r['timings']['predicted_per_token_ms'],
                    decode_tokens_per_second=r['timings']['predicted_per_second'],
                    queue_ms=r['timings']['queue_ms']))))
    lines = [f"Expanded Qwen3.8 TP comparison: {report['exact_core_matches']}/100 exact core text matches.",
       f"Repeat cross-TP matches: {report['exact_cache_cross_tp_matches']}/10.",
       f"Core finish reasons equal: {report['matching_finish_reasons']}/100; completion token counts equal: {report['matching_completion_token_counts']}/100.",
       f"Initial/repeat text equality: TP1 {sum(c['tp1_cold_cache_equal'] for c in cache_checks)}/10; TP2 {sum(c['tp2_cold_cache_equal'] for c in cache_checks)}/10.",
       f"Actual cache-hit repeats: TP1 {sum(c['tp1_cache_hit'] for c in cache_checks)}/10; TP2 {sum(c['tp2_cache_hit'] for c in cache_checks)}/10.",
       f"All core requests actually uncached: {report['all_core_uncached']}.",
       f"Known-answer/format checks (separate from parity): {report['known_answer_passes']}, out of {len(quality)} per mode.",
       f"Completion tokens generated: {report['total_generated_completion_tokens']}.", '',
       'Latency p50/p95, seconds. Decode p50/p95, milliseconds per token.',
       'Mode / subset                    TTFT           response          decode']
    for tp in (1, 2):
        for subset in ['short_uncached', 'long_uncached', 'long_cached', 'long_repeat_cache_miss', 'matched_short']:
            s = timing[f'tp{tp}'][subset]
            if not s['requests']:
                continue
            def pair(k):
                return f"{s[k]['p50']:.3f}/{s[k]['p95']:.3f}"
            lines.append(f"TP{tp} {subset:24} {pair('ttft_seconds'):17} {pair('response_seconds'):17} {pair('engine_decode_ms_per_token')}")
        lines.append(f"TP{tp} startup: {timing[f'tp{tp}']['startup_to_health_ready_seconds']:.3f}s; workload: {timing[f'tp{tp}']['workload_elapsed_seconds']:.3f}s")
    lines += ['', 'Differences:'] + [json.dumps(r) for r in comparisons if not r['exact_text_equal']]
    lines += ['', 'All 220 responses completed with validated SSE end markers, usage, and finish reasons.',
        'Greedy temperature=0, top_k=1, top_p=1, no penalties; maximum 128 completion tokens.',
        '100 distinct frozen prompts, ten categories of ten, identical order in both modes.',
        'Three original regression anchors are included; cached repeats are counted separately.',
        'Checkpoint RadixArk/Qwen3.8-Flash-Next-NVFP4 @ 7b719225242aacd3dbd3f9407468c2ee9a9d2594.',
        'Experimental current-main e5856ac + PR385 TP port + all five precision flags.',
        'Both modes use host expert offload; auto expert-cache capacity differs with GPU count.',
        'Decode timing comes from engine counters. SSE timing measures client first content and stream completion.',
        'Decode percentiles are across per-request mean ms/token, not individual inter-token gaps.',
        'Resource sampling is once per second and starts during the first TP1 request.',
        'Startup means process launch to health-ready; existing disk and JIT caches are retained.',
        'Single sequential pass per mode; no forced token replay or full-logit tracing.',
        'Matched-short timing is limited to identical output text, token count, and finish reason.',
        'Equality is UTF-8 response-text equality plus separate completion-count/finish checks.',
        'No claim of bitwise logit parity, universal quality, or a reference-engine accuracy benchmark.',
        'No unpatched 100-prompt control was run; this run alone cannot quantify before/after improvement.',
        'The 128-token cap can truncate answers; finish reasons are retained for every output.',
        'See summary.json, timings.csv, prompts.json, tp*-responses.jsonl, tp*-server.log, and resource-timeline.jsonl.']
    (ROOT / 'RESULTS.txt').write_text('\n'.join(lines)+'\n')
    return report, prompts, data, timeline


def make_html(report, prompts, data):
    esc = html.escape
    parts = ['<!doctype html><html lang="en"><meta charset="utf-8">',
      '<meta name="viewport" content="width=device-width, initial-scale=1">',
      '<title>Qwen3.8: 100 paired outputs and latency</title>',
      '<style>body{font:16px/1.5 system-ui;max-width:1120px;margin:40px auto;padding:0 24px;color:#142334;background:#f6f8fb}h1{line-height:1.2}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:white;padding:16px;border:1px solid #d5dce5;border-radius:8px;font:13px/1.55 ui-monospace,monospace}details{margin:12px 0;background:#edf1f7;padding:12px;border-radius:8px}summary{cursor:pointer;font-weight:650}table{border-collapse:collapse;width:100%;background:white}td,th{text-align:left;padding:9px;border-bottom:1px solid #d5dce5}.ok{color:#12693a}.bad{color:#a12c24}img{width:100%;background:white}.note{color:#415368}.two{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:750px){.two{display:block}}</style>',
      '<h1>Qwen3.8-Flash-Next: 100 paired outputs</h1>',
      f"<p><strong>{report['exact_core_matches']}/100 distinct prompts produce identical TP1 and TP2 text.</strong> Ten additional cache-repeat attempts per mode are evaluated separately, with actual cache hits recorded.</p>",
      '<p class="note">Two R9700s; local experimental TP build with the five precision fixes. Greedy generation, 128-token maximum, identical prompts and order, one sequential pass per mode.</p>',
      '<h2>Latency in time units</h2><p>Every output has client time to first token and total response time, engine decode milliseconds per token, queue time, and an absolute completion timestamp. Initial requests are retained. Short, long, and cached requests are separate.</p>',
      '<img src="latency.png" alt="Paired request latency, decode time, and long-context cache latency">',
      '<img src="timeline.png" alt="Performance, RAM, and GPU utilization over elapsed time">',
      '<pre>'+esc((ROOT/'RESULTS.txt').read_text())+'</pre>',
      '<h2>Inspectable outputs</h2><p>Expand a row to inspect the input and response. Exact equality uses the complete returned text; finish reason and generated token counts are checked separately.</p>']
    core = {tp: {r['name']: r for r in data[tp] if r['kind'] == 'core'} for tp in (1,2)}
    for p, c in zip(prompts, report['comparisons']):
        a, b = core[1][p['name']], core[2][p['name']]
        tag = 'MATCH' if c['exact_text_equal'] else 'DIFFERENT'
        parts += [f"<details><summary class=\"{'ok' if c['exact_text_equal'] else 'bad'}\">{p['index']:03d} · {esc(p['category'])} · {esc(p['name'])} · {tag}</summary>",
          f"<p>Input {p['tokens']} tokens. TP1/TP2 generated {a['usage']['completion_tokens']}/{b['usage']['completion_tokens']} tokens; finish {esc(a['finish_reason'])}/{esc(b['finish_reason'])}.</p>",
          f"<p>TP1 TTFT {a['ttft_seconds']:.3f}s, total {a['wall_seconds']:.3f}s; TP2 TTFT {b['ttft_seconds']:.3f}s, total {b['wall_seconds']:.3f}s.</p>",
          '<details><summary>Input</summary><pre>'+esc(p['user_text'] or p['prompt'])+'</pre></details>']
        if c['exact_text_equal']:
            parts += ['<p>Identical TP1 and TP2 output:</p><pre>'+esc(a['text'])+'</pre>']
        else:
            parts += ['<div class="two"><div><b>TP1</b><pre>'+esc(a['text'])+'</pre></div><div><b>TP2</b><pre>'+esc(b['text'])+'</pre></div></div>']
        parts += ['</details>']
    parts += ['<h2>Raw evidence</h2><p><a href="timings.csv">Per-request timings CSV</a> · <a href="summary.json">Summary JSON</a> · <a href="prompts.json">Frozen prompts</a> · <a href="tp1-responses.jsonl">TP1 responses</a> · <a href="tp2-responses.jsonl">TP2 responses</a> · <a href="resource-timeline.jsonl">Resource time series</a></p></html>']
    (ROOT / 'report.html').write_text('\n'.join(parts))


if __name__ == '__main__':
    report, prompts, data, timeline = analyze()
    make_html(report, prompts, data)
    print((ROOT / 'RESULTS.txt').read_text())
