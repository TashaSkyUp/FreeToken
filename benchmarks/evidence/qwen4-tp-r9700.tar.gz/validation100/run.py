import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
REPO = REPRO.parent.parent
TREE = REPO / '.worktrees/qwen38-tp'
URL = 'http://127.0.0.1:2959'
FLAGS = {k: '1' for k in ['FREETOKEN_TP_PRECISE', 'FREETOKEN_GDN_SNAPSHOT_FP32',
                          'FREETOKEN_ROUTER_FP32', 'FREETOKEN_STABLE_LINEAR',
                          'FREETOKEN_RESIDUAL_FP32']}


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    temp.replace(path)


def state(**kw):
    save(ROOT / 'state.json', dict(utc=now(), **kw))
    print(json.dumps(dict(utc=now(), **kw)), flush=True)


def source_hashes():
    result = {str(p.relative_to(TREE)): digest(p)
              for p in sorted((TREE / 'python/freetoken').rglob('*.py'))}
    for name in ['serve.sh', 'serve-precise.sh', 'rccl/librccl.so']:
        result['repro/' + name] = digest(REPRO / name)
    return result


def get(path):
    with urllib.request.urlopen(URL + path, timeout=5) as r:
        return json.load(r)


def post(path, body, timeout=900):
    return urllib.request.urlopen(urllib.request.Request(
        URL + path, data=json.dumps(body).encode(),
        headers={'Content-Type': 'application/json'}), timeout=timeout)


def flush_cache():
    try:
        with post('/v1/cache/flush?timeout=60', {}, timeout=90) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        data = json.loads(e.read())
        if e.code != 503 or data.get('status') != 'unsupported':
            raise
    if data.get('status') not in ('ok', 'unsupported'):
        raise RuntimeError(data)
    return data


def complete(tp, p, kind, flush):
    body = dict(model='qwen38-repro', prompt=p['prompt'], max_tokens=p['max_tokens'],
                temperature=0, top_k=1, top_p=1, stream=True,
                stream_options={'include_usage': True},
                presence_penalty=0, frequency_penalty=0)
    start = time.perf_counter()
    first = None
    texts = []
    usage = None
    timings = None
    reason = None
    request_id = None
    done = False
    with post('/v1/completions', body) as response:
        for raw in response:
            line = raw.decode('utf-8').strip()
            if not line.startswith('data:'):
                continue
            payload = line[5:].strip()
            if payload == '[DONE]':
                done = True
                break
            event = json.loads(payload)
            if event.get('error'):
                raise RuntimeError(event['error'])
            request_id = event.get('id', request_id)
            for c in event.get('choices', []):
                if c.get('index', 0) != 0:
                    raise RuntimeError('Unexpected multiple choices')
                delta = c.get('text', '')
                if delta:
                    if first is None:
                        first = time.perf_counter()
                    texts.append(delta)
                if c.get('finish_reason'):
                    reason = c['finish_reason']
            if event.get('usage'):
                usage = event['usage']
            if event.get('timings'):
                timings = event['timings']
    end = time.perf_counter()
    text = ''.join(texts)
    if not (done and usage and timings and request_id and text and first):
        raise RuntimeError(dict(incomplete_stream=True, done=done, usage=usage,
                                timings=timings, request_id=request_id, text=text))
    if reason not in ('stop', 'length'):
        raise RuntimeError(dict(finish_reason=reason))
    n = usage['completion_tokens']
    if not (0 < n <= p['max_tokens']):
        raise RuntimeError(dict(completion_tokens=n))
    if reason == 'length' and n != p['max_tokens']:
        raise RuntimeError(dict(length_mismatch=n))
    if usage['prompt_tokens'] != p['tokens']:
        raise RuntimeError(dict(prompt_token_mismatch=(usage['prompt_tokens'], p['tokens'])))
    if usage['total_tokens'] != usage['prompt_tokens'] + n:
        raise RuntimeError(dict(total_token_mismatch=usage))
    return dict(tp=tp, index=p['index'], name=p['name'], category=p['category'],
                kind=kind, utc=now(), prompt_sha256=p['sha256'],
                expected_prompt_tokens=p['tokens'], max_tokens=p['max_tokens'],
                request_id=request_id, text=text,
                text_sha256=hashlib.sha256(text.encode()).hexdigest(),
                finish_reason=reason, usage=usage, timings=timings,
                cache_n=timings['cache_n'], flush=flush, sse_done=done,
                ttft_seconds=first-start, wall_seconds=end-start,
                decode_tokens_per_second=None if n < 2 else (n-1)/(end-first))


def append(path, value):
    with path.open('a') as f:
        f.write(json.dumps(value, ensure_ascii=False) + '\n')
        f.flush()
        os.fsync(f.fileno())


def stop(proc):
    if proc is None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        proc.wait(timeout=20)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=10)


def run_mode(tp, prompts, hashes):
    proc = None
    env = os.environ.copy()
    for k in list(env):
        if k.startswith('FREETOKEN_'):
            del env[k]
    env.update(FLAGS)
    output = ROOT / f'tp{tp}-responses.jsonl'
    if output.exists():
        raise RuntimeError(f'Refusing to overwrite {output}')
    save(ROOT / f'tp{tp}-settings.json', dict(tp=tp, environment=FLAGS,
         replay=False, tracing=False, request_order=[p['name'] for p in prompts],
         prompt_manifest_sha256=digest(ROOT / 'prompts.json'),
         launch=[str(REPRO / 'serve-precise.sh'), str(tp)], started_utc=now()))
    try:
        if source_hashes() != hashes:
            raise RuntimeError('Inference sources changed after freeze')
        with (ROOT / f'tp{tp}-server.log').open('w') as log:
            proc = subprocess.Popen([str(REPRO / 'serve-precise.sh'), str(tp)],
                                    env=env, stdout=log, stderr=subprocess.STDOUT,
                                    start_new_session=True)
            state(stage='loading', tp=tp, server_pid=proc.pid)
            deadline = time.monotonic() + 1800
            while time.monotonic() < deadline:
                if proc.poll() is not None:
                    raise RuntimeError(f'TP{tp} server exited: {proc.returncode}')
                try:
                    h = get('/health')
                except (OSError, ValueError):
                    h = {}
                if h.get('status') == 'ok':
                    break
                if h.get('status') == 'error':
                    raise RuntimeError(h)
                time.sleep(3)
            else:
                raise TimeoutError('Server startup exceeded 30 minutes')
            state(stage='generating', tp=tp, completed_core=0, completed_cache=0)
            cache_count = 0
            for i, p in enumerate(prompts):
                if proc.poll() is not None:
                    raise RuntimeError('Server exited during generation')
                if digest(ROOT / 'prompts.json') != manifest['prompts_sha256']:
                    raise RuntimeError('Prompt manifest changed')
                flush = flush_cache()
                state(stage='request', tp=tp, current_index=p['index'], name=p['name'],
                      completed_core=i, completed_cache=cache_count)
                row = complete(tp, p, 'core', flush)
                append(output, row)
                print(json.dumps(dict(event='completed', tp=tp, index=p['index'],
                      name=p['name'], kind='core', cache_n=row['cache_n'],
                      tokens=row['usage']['completion_tokens'],
                      wall_seconds=row['wall_seconds'], hash=row['text_sha256'])), flush=True)
                if p['cache_probe']:
                    state(stage='cache-repeat', tp=tp, current_index=p['index'],
                          name=p['name'], completed_core=i+1, completed_cache=cache_count)
                    cached = complete(tp, p, 'cache-repeat', None)
                    append(output, cached)
                    cache_count += 1
                    print(json.dumps(dict(event='completed', tp=tp, index=p['index'],
                          name=p['name'], kind='cache-repeat', cache_n=cached['cache_n'],
                          tokens=cached['usage']['completion_tokens'],
                          wall_seconds=cached['wall_seconds'], hash=cached['text_sha256'])), flush=True)
            if source_hashes() != hashes:
                raise RuntimeError('Inference sources changed during run')
            state(stage='mode-complete', tp=tp, completed_core=100, completed_cache=cache_count)
    finally:
        stop(proc)


manifest = json.loads((ROOT / 'manifest.json').read_text())
prompts = json.loads((ROOT / 'prompts.json').read_text())
assert len(prompts) == 100 and digest(ROOT / 'prompts.json') == manifest['prompts_sha256']
if (ROOT / 'sources-before.json').exists():
    raise RuntimeError('Run already initialized; preserve existing evidence')
try:
    get('/health')
except OSError:
    pass
else:
    raise RuntimeError('Port 2959 already serves another process')
hashes = source_hashes()
save(ROOT / 'sources-before.json', hashes)
try:
    for tp in [1, 2]:
        run_mode(tp, prompts, hashes)
    save(ROOT / 'sources-after.json', source_hashes())
    state(stage='complete', core_pairs=100, cache_pairs=10)
except BaseException as e:
    state(stage='failed', error=repr(e), traceback=traceback.format_exc())
    raise
