#!/usr/bin/env bash
set -euo pipefail
cd /root/experiments/FreeToken
source .local-build/activate-rocm.sh
export PYTHONPATH=/root/experiments/FreeToken/.worktrees/qwen38-tp/python:/root/experiments/FreeToken/.local-build/qwen38-repro
export HIP_VISIBLE_DEVICES=0,1
export OMP_NUM_THREADS=4
export LD_PRELOAD=/root/experiments/FreeToken/.venv/lib/python3.12/site-packages/torch/lib/libamdhip64.so:/root/experiments/FreeToken/.local-build/qwen38-repro/rccl/librccl.so
exec python -m freetoken.cli serve --model /models-fast/206-comfyui-models/LLM/Qwen3.8-Flash-Next-NVFP4 --served-model-name qwen38-repro --tp-size "$1" --disable-pynccl --moe-strategy offload --expert-load parallel --quant-backend moe.nvfp4=triton --ple-backend disk --text-model-only --moe-cache-auto --kv-reserve-tokens 16384 --num-tokens 16384 --max-seq-len-override 16384 --memory-ratio 0.90 --max-running-requests 1 --cuda-graph-max-bs 1 --max-prefill-length 1024 --enable-timings-report --enable-cache-report --reasoning-parser off --host 127.0.0.1 --port 2959
