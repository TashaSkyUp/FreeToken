Audited Qwen3.8-Flash-Next NVFP4 tensor-parallel evidence, v3.

Read docs/qwen4-exp-tp-r9700.md and prompt-audit-v3-nfc/cohort-summary.json.
The new cohort has 100 prompts, four configurations (five/seven flags x TP1/TP2),
10 cache repeats each, and 440 inference responses. All have max_tokens=1024 and
thinking disabled. Prompt specificity, actual tokenized input, answer-key and
judge-rubric audits are retained. The Unicode key correction is explicit.

The two quality directories contain 200 accepted judgments each: 100 forward,
then 100 with both submission and A/B order reversed. Codex CLI uses
gpt-6.1-terra/max, at most 20 concurrent. Profile-quality aliases refer to two
arithmetic profiles, both actual TP1. TP-quality compares V2 TP1 against V2 TP2.
Invocations, final judgments and retries are retained. Raw Codex CLI events,
hidden reasoning, authentication, native binaries and model weights are omitted.

The earlier NFC-invalid attempt is preserved locally and represented here by
its stop record and original frozen inputs; its responses are not in the new
cohort. A separate launch failure before any response is retained under
failed-startup-missing-rocm-activation. The 69 existing tests ran earlier in the
same task on identical engine source; copied logs record their real commands.

Scripts are workspace-specific scratch harnesses, not maintained project tests.
The original execution root was
/root/experiments/FreeToken/.local-build/qwen38-repro/prompt-audit-v3-nfc.
Source the local activate-rocm.sh environment (ROCM_HOME=/opt/rocm-7.2.3), then
run run_inference.py and postprocess.py. Adjust local model/library/worktree
paths elsewhere. Frozen input and result files refuse accidental overwrites.
The dependency helpers are retained at their original relative paths.

SSE text chunk times preserve client delivery observations. A chunk may contain
partial or multiple tokens; chunk gaps are not individual GPU token times.
Startup/model load, cold-prefix request latency and cache-hit latency are kept
separate. One sequential pass and automatic expert cache sizing limit inference
about general speed or pure TP communication scaling.

MANIFEST.json hashes every other archive member; it does not hash itself.
