"""Wait for all four inference legs, then analyze and run the blinded evaluations."""

import hashlib
import json
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
INFERENCE=ROOT/'inference'

def state(stage,**extra):
    data=dict(stage=stage,utc=datetime.now(timezone.utc).isoformat(),**extra)
    temp=ROOT/'pipeline-state.tmp'
    temp.write_text(json.dumps(data,indent=2)+'\n')
    temp.replace(ROOT/'pipeline-state.json')
    print(json.dumps(data),flush=True)

def run(command,log):
    with (ROOT/log).open('a') as output:
        subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,check=True)

state('waiting-for-all-four-inference-configurations')
try:
    while True:
        current=json.loads((INFERENCE/'state.json').read_text())
        if current['stage']=='failed':
            raise RuntimeError(current)
        if current['stage']=='complete':
            break
        time.sleep(10)
    state('analyzing-all-440-inference-responses')
    run([sys.executable,str(ROOT/'analyze_results.py')],'analysis.log')
    acceptance=ROOT/'judge-audit-acceptance.json'
    state('waiting-for-judge-rubric-audit-acceptance')
    while not acceptance.exists():
        time.sleep(5)
    approved=json.loads(acceptance.read_text())
    for name,digest in approved['harness_sha256'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    quality=ROOT/'quality'
    quality.mkdir(exist_ok=True)
    tasks=[dict(name='profile-quality',harness='judge-profile.executed.py',
                inputs={'profile1-responses.jsonl':'v1-tp1-responses.jsonl',
                        'profile2-responses.jsonl':'v2-tp1-responses.jsonl'},
                identities={'profile1':'V1 five-flag profile, actual TP=1',
                            'profile2':'V2 seven-flag profile, actual TP=1'}),
           dict(name='tp-quality',harness='judge-tp.executed.py',
                inputs={'tp1-responses.jsonl':'v2-tp1-responses.jsonl',
                        'tp2-responses.jsonl':'v2-tp2-responses.jsonl'},
                identities={'tp1':'V2 seven-flag profile, actual TP=1',
                            'tp2':'V2 seven-flag profile, actual TP=2'})]
    for task in tasks:
        folder=quality/task['name']
        folder.mkdir(exist_ok=True)
        for destination,source in dict(task['inputs'],**{'prompts.json':'prompts.json'}).items():
            data=(INFERENCE/source).read_bytes()
            target=folder/destination
            if target.exists():
                assert target.read_bytes()==data
            else:
                target.write_bytes(data)
        identities=dict(task['identities'],note='Judge inputs contain only the original user request, A/B text and finish reasons; source identities stay out of model context.')
        (folder/'identities.json').write_text(json.dumps(identities,indent=2)+'\n')
        state('judging-'+task['name'],model='gpt-6.1-terra',reasoning='max',workers=20,evaluations=200)
        run([sys.executable,str(ROOT/task['harness']),'--source-dir',str(folder),
             '--out-dir',str(folder/'terra-max-judgments'),'--model','gpt-6.1-terra',
             '--reasoning','max','--workers','20'],task['name']+'-controller.log')
        if task['name']=='profile-quality':
            analysis=ROOT/'analyze_profile_judgments.py'
        else:
            analysis=ROOT/'analyze_tp_judgments.py'
        run([sys.executable,str(analysis),'--run-dir',str(folder/'terra-max-judgments')],task['name']+'-analysis.log')
    state('complete',inference_responses=440,judge_evaluations=400)
except BaseException as error:
    state('failed',error=repr(error))
    raise
