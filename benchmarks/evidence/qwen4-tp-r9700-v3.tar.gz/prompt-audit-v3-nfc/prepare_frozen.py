"""Freeze the independently reviewed prompt revision and encode non-thinking turns."""

import hashlib
import json
import unicodedata
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from transformers import AutoTokenizer

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
MODEL = '/models-fast/206-comfyui-models/LLM/Qwen3.8-Flash-Next-NVFP4'
acceptance = json.loads((ROOT/'audit-acceptance.json').read_text())
reviewed_hash = acceptance['independent_review_hash']
candidate = ROOT/'revised-prompts-blind.json'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == reviewed_hash
assert (ROOT/'actual-user-turns-blind.json').read_bytes() == candidate.read_bytes()
assert (ROOT/'blind-encoded-audit.md').exists(), 'Wait for independent review artifact'
assert acceptance['remaining_material_findings'] == 0
token_audit = json.loads((ROOT/'tokenized-input-audit.json').read_text())
assert token_audit['normalizer'] == {'type':'NFC'}
assert token_audit['exact_roundtrips'] == 100 and not token_audit['roundtrip_losses']
audit = json.loads((ROOT/'answer-key-audit.json').read_text())
assert audit['fixed_answer_keys'] == 42 and audit['mismatches'] == 0
original = {p['name']:p for p in json.loads((REPRO/'divergence-v2/validation100-fp64/prompts.json').read_text())}
tokenizer = AutoTokenizer.from_pretrained(MODEL, local_files_only=True)
items = []
for revised in json.loads(candidate.read_text()):
    prior = original[revised['name']]
    assert unicodedata.normalize('NFC',revised['user_text']) == revised['user_text']
    prompt = tokenizer.apply_chat_template([{'role':'user','content':revised['user_text']}],
        tokenize=False,add_generation_prompt=True,enable_thinking=False)
    ids = tokenizer.encode(prompt,add_special_tokens=False)
    assert tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False) == prompt
    assert prompt.endswith('<think>\n\n</think>\n\n')
    assert len(ids)+1024 <= 16384
    expected = (unicodedata.normalize('NFC',prior['expected'])
                if revised['name'] == 'unicode-preserve' else prior['expected'])
    items.append(dict(revised,expected=expected,cache_probe=prior['cache_probe'],
        prompt=prompt,input_ids=ids,tokens=len(ids),max_tokens=1024,
        sha256=hashlib.sha256(prompt.encode()).hexdigest(),thinking=False))
assert len(items) == len({p['sha256'] for p in items}) == 100
assert Counter(p['category'] for p in items) == {c:10 for c in {p['category'] for p in items}}
assert sum(p['cache_probe'] for p in items) == 10
assert sum(p['expected'] is not None for p in items) == 42
assert not (ROOT/'prompts.json').exists(), 'Frozen prompts are immutable'
data = (json.dumps(items,ensure_ascii=False,indent=2)+'\n').encode()
(ROOT/'prompts.json').write_bytes(data)
manifest = dict(revision='v3-specificity-1024-nfc',created_utc=datetime.now(timezone.utc).isoformat(),
    prompts_sha256=hashlib.sha256(data).hexdigest(),independently_reviewed_user_turns_sha256=reviewed_hash,
    distinct_prompts=100,cache_repeat_requests_per_mode=10,fixed_answer_checks_per_mode=42,
    categories=dict(Counter(p['category'] for p in items)),thinking=False,max_completion_tokens=1024,
    context_limit=16384,input_tokens_min=min(p['tokens'] for p in items),input_tokens_max=max(p['tokens'] for p in items),
    input_tokens_total=sum(p['tokens'] for p in items),temperature=0,top_k=1,top_p=1,
    profiles={'v1':'Original five precision flags','v2':'Original five plus FP64 reductions and stable attention'},
    tokenizer_normalizer=token_audit['normalizer'],exact_tokenizer_roundtrips=100,
    changed_answer_keys=audit['changed_keys'],unchanged_answer_keys=41,
    modes=[1,2],inference_requests=440,
    limitations=['Purpose-built regression set, not a random or standardized capability benchmark.',
        'Prompts and token budget change together; do not attribute changes against v2 historical runs solely to inference precision.',
        'Compare profiles and TP modes within this frozen revision.',
        'Thinking-disabled greedy protocol; no claim about reasoning-enabled behavior.'])
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
