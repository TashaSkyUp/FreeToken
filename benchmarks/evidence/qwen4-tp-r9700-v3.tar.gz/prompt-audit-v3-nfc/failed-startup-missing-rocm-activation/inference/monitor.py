import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CLK = os.sysconf('SC_CLK_TCK')
PAGE = os.sysconf('SC_PAGE_SIZE')
DEVICES = [p for p in sorted(Path('/sys/class/drm').glob('card*/device'))
           if (p / 'gpu_busy_percent').exists()]


def number(p, scale=1):
    try:
        return int(p.read_text().strip()) / scale
    except (OSError, ValueError):
        return None


def process_tree(pid):
    seen = set()
    todo = [pid] if pid else []
    ticks = rss = 0
    while todo:
        pid = todo.pop()
        if pid in seen:
            continue
        seen.add(pid)
        p = Path('/proc') / str(pid)
        try:
            stat = (p / 'stat').read_text().rsplit(')', 1)[1].split()
            ticks += int(stat[11]) + int(stat[12])
            rss += int(stat[21]) * PAGE
            todo.extend(map(int, (p / 'task' / str(pid) / 'children').read_text().split()))
        except (OSError, ValueError):
            pass
    return dict(pids=sorted(seen), cpu_seconds=ticks / CLK, rss_bytes=rss)


out = ROOT / 'resource-timeline.jsonl'
# Resume appends observations; earlier timeline remains intact.
previous = None
while True:
    started = time.monotonic()
    state = json.loads((ROOT / 'state.json').read_text())
    server_pid = None
    for line in (ROOT / 'run.log').read_text().splitlines():
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get('stage') == 'loading':
            server_pid = e['server_pid']
    proc = process_tree(server_pid)
    if previous and previous[0] == server_pid:
        proc['cpu_cores_used_interval'] = max(0, (proc['cpu_seconds'] - previous[2]) / (started - previous[1]))
    previous = server_pid, started, proc['cpu_seconds']
    mem = {k.rstrip(':'): int(v.split()[0]) * 1024
           for k, v in (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())}
    devices = []
    for d in DEVICES:
        h = next((d / 'hwmon').glob('hwmon*'), None)
        devices.append(dict(pci=d.resolve().name, card=d.parent.name,
                       gpu_busy_percent=number(d / 'gpu_busy_percent'),
                       mem_busy_percent=number(d / 'mem_busy_percent'),
                       vram_used_bytes=number(d / 'mem_info_vram_used'),
                       power_watts=number(h / 'power1_average', 1e6) if h else None,
                       edge_celsius=number(h / 'temp1_input', 1000) if h else None,
                       junction_celsius=number(h / 'temp2_input', 1000) if h else None))
    row = dict(utc=datetime.now(timezone.utc).isoformat(), monotonic_seconds=started,
               state=state, server=proc, devices=devices,
               memory={k: mem[k] for k in ['MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree']},
               load_average=Path('/proc/loadavg').read_text().split()[:3])
    with out.open('a') as f:
        f.write(json.dumps(row) + '\n')
    if state['stage'] in ('complete', 'failed'):
        break
    time.sleep(max(0, 1 - (time.monotonic() - started)))
