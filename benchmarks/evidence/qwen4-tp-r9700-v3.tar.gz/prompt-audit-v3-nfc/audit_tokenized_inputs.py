"""Audit the actual tokenized user turns, including Unicode normalization."""

import hashlib
import json
import unicodedata
from pathlib import Path

from transformers import AutoTokenizer

ROOT=Path(__file__).resolve().parent
MODEL=Path('/models-fast/206-comfyui-models/LLM/Qwen3.8-Flash-Next-NVFP4')
tokenizer=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
normalizer=json.loads((MODEL/'tokenizer.json').read_text())['normalizer']
assert normalizer=={'type':'NFC'}
candidate=json.loads((ROOT/'revised-prompts-blind.json').read_text())
old={p['name']:p for p in json.loads((ROOT.parent/'prompt-audit-v3/prompts.json').read_text())}
details=[]
actual_turns=[]
for p in candidate:
    assert unicodedata.normalize('NFC',p['user_text'])==p['user_text']
    rendered=tokenizer.apply_chat_template([{'role':'user','content':p['user_text']}],
        tokenize=False,add_generation_prompt=True,enable_thinking=False)
    ids=tokenizer.encode(rendered,add_special_tokens=False)
    decoded=tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
    assert rendered==decoded,p['name']
    user=decoded.split('<|im_start|>user\n',1)[1].split('<|im_end|>\n<|im_start|>assistant',1)[0]
    assert user==p['user_text']
    assert decoded.endswith('<think>\n\n</think>\n\n')
    assert len(ids)+1024<=16384
    actual_turns.append(dict(p,user_text=user))
    details.append(dict(name=p['name'],roundtrip_exact=True,input_tokens=len(ids),
        candidate_token_ids_equal_stopped_attempt=ids==old[p['name']]['input_ids'],
        rendered_sha256=hashlib.sha256(rendered.encode()).hexdigest()))
prior_unicode=old['unicode-preserve']
prior_decoded=tokenizer.decode(prior_unicode['input_ids'],skip_special_tokens=False,clean_up_tokenization_spaces=False)
prior_payload=prior_decoded.rsplit('<data>',1)[1].split('</data>',1)[0]
audit=dict(normalizer=normalizer,actual_user_turns_checked=100,exact_roundtrips=100,
    roundtrip_losses=[],thinking=False,max_completion_tokens=1024,
    stopped_attempt_changed_inputs=[p['name'] for p in details if not p['candidate_token_ids_equal_stopped_attempt']],
    invalid_prior_unicode_case=dict(expected_codepoints=[f'U+{ord(c):04X}' for c in prior_unicode['expected']],
        actual_input_payload_codepoints=[f'U+{ord(c):04X}' for c in prior_payload],
        expected_differs_from_actual_payload=prior_unicode['expected']!=prior_payload),
    details=details)
(ROOT/'tokenized-input-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
(ROOT/'actual-user-turns-blind.json').write_text(json.dumps(actual_turns,ensure_ascii=False,indent=2)+'\n')
print('100 exact tokenizer roundtrips; actual user turns match reviewed candidate text.')
print('Changed inputs compared with stopped attempt:',audit['stopped_attempt_changed_inputs'])
