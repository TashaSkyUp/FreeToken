"""Prepare the own-fork draft description from the final audited evidence."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
assert json.loads((ROOT/'pipeline-state.json').read_text())['stage'] == 'complete'
r = json.loads((ROOT/'cohort-summary.json').read_text())
c = r['configurations']
url = 'https://github.com/TashaSkyUp/FreeToken/blob/draft/qwen4-tp-precision-r9700/'
doc = url+'docs/qwen4-exp-tp-r9700.md'
archive = url+'benchmarks/evidence/qwen4-tp-r9700-v3.tar.gz'
v1 = r['comparisons']['v1-cross-tp']['exact_matches']
v2 = r['comparisons']['v2-cross-tp']['exact_matches']
parts = [
 'Qwen3.8-Flash-Next at the tested upstream base (`14119b8`) rejects TP>1.',
 'This downstream draft adapts the intermediate-axis sharding from',
 '[#385](https://github.com/FlashML-org/FreeToken/pull/385) and adds opt-in precision',
 'settings for two R9700s. NVFP4 expert rows/columns are sharded with their scale',
 'geometry; fixed K tiles use FP64 between tiles and through expert/TP reductions;',
 'attention and per-head normalization use layouts selected from unsharded head counts.', '',
 'This is an AI-assisted draft in the user\'s fork for human review. Related:',
 '[#62](https://github.com/FlashML-org/FreeToken/issues/62) and',
 '[AMD roadmap #541](https://github.com/FlashML-org/FreeToken/issues/541).','',
 '### Audited 1,024-token reproduction','',
 'The full matrix uses **100 distinct prompts**, ten per category, plus ten cache',
 'repeats per configuration: **440 inference responses**. V1 is the original five-flag',
 'profile; V2 adds FP64 reductions and stable attention. Both TP modes use the same',
 'profile for each cross-TP comparison. Every configuration uses cleaned source',
 '`4aed3f5c7ae3054fb3813de304ef2b820c804642`; all 503 Python engine hashes agree.',
 'No engine code changed in this evidence follow-up.','',
 '| Measurement | V1 | V2 |','| --- | ---: | ---: |',
 f'| Exact TP=1/TP=2 core text pairs | {v1}/100 | {v2}/100 |',
 f'| Strict checks, TP=1 | {c["v1-tp1"]["fixed_passes"]}/42 | {c["v2-tp1"]["fixed_passes"]}/42 |',
 f'| Strict checks, TP=2 | {c["v1-tp2"]["fixed_passes"]}/42 | {c["v2-tp2"]["fixed_passes"]}/42 |',
 f'| Capped core responses, TP1 + TP2 | {c["v1-tp1"]["capped_core"]+c["v1-tp2"]["capped_core"]}/200 | {c["v2-tp1"]["capped_core"]+c["v2-tp2"]["capped_core"]}/200 |','',
 'All core requests report zero cached input. Output agreement is separate from',
 'correctness: common arithmetic/counting errors remain. V2 also changes TP=1',
 'arithmetic, so its cross-TP agreement does not prove a general answer-quality gain.','',
 'A fresh-context agent audited the prompts without outputs or keys; a second audited',
 'the exact decoded user turns. Ambiguous contracts and a formula shortcut were fixed.',
 'All 100 final inputs round-trip through the checkpoint tokenizer exactly. One answer',
 'key is corrected: the historical Unicode-copy test expected NFD while its tokenizer',
 'input was NFC. The old reported 35/42 and 34/42 become35/41 and34/41 valid cases;',
 'old archives are preserved. The new cohort has an NFC-stable payload, 41 unchanged',
 'keys and one explicit correction. New prompts/cap/rubric require within-cohort comparisons.','',
 '### Blinded quality and time measurements','',
 'Two comparisons use `codex exec`, `gpt-6.1-terra`, `max` reasoning, at most20',
 'concurrent calls: V1 TP1 versus V2 TP1, and V2 TP1 versus V2 TP2. Each has100',
 'forward evaluations, then100 with reversed submission and A/B order. Judges see',
 'only requests, delivered texts and finish reasons. The independently audited rubric',
 'separates correctness from format/completeness and semantic similarity.','',
 '| Comparison | Correctness, left / right | Instruction/completeness, left / right | Semantic similarity |',
 '| --- | ---: | ---: | ---: |']
for key,label,left,right in [('profile-quality','V1 TP1 / V2 TP1','profile1','profile2'),('tp-quality','V2 TP1 / V2 TP2','tp1','tp2')]:
    s = r['quality'][key]['all_samples']
    a,b = s['correctness'],s['instruction_following_completeness']
    parts.append(f'| {label} | {a[left+"_mean"]:.3f} / {a[right+"_mean"]:.3f} | {b[left+"_mean"]:.3f} / {b[right+"_mean"]:.3f} | {s["semantic_score_mean"]:.3f} |')
parts += ['',
 'Accepted judgments / actual CLI calls / identical-output control errors: '+
 '; '.join(f'{key}: {s["evaluations"]}/{s["main_run_cli_invocations"]}/{len(s["identical_control_errors"])}' for key,s in r['quality'].items())+'.',
 'Ratings are secondary evidence; one judgment per order confounds order effects with judge variance.','',
 f'The {len(r["same_outputs_all_four_short"])} short prompts with identical text, token count and finish reason in all four configurations give:', '',
 '| Configuration | Median TTFT, s | Median request, s | Median decode, ms/token | Median decode, tok/s |',
 '| --- | ---: | ---: | ---: | ---: |']
for label in ['v1-tp1','v1-tp2','v2-tp1','v2-tp2']:
    s = c[label]['same_outputs_all_four']
    parts.append(f'| {label.upper()} | {s["ttft_seconds"]["p50"]:.3f} | {s["response_seconds"]["p50"]:.3f} | {s["engine_decode_ms_per_token"]["p50"]:.3f} | {s["engine_decode_tokens_per_second"]["p50"]:.3f} |')
parts += ['',
 'This is one sequential pass, ordered V2 TP2, V1 TP2, V1 TP1, V2 TP1, with existing',
 'disk/JIT caches and no timed warmup phase. Startup, long-input, cache-hit and SSE',
 'delivery measurements are retained separately, including p95 distributions.',
 'Auto expert cache residency differs between TP modes and is part of the observed speed.',
 'This is not a confidence interval or isolated communication-scaling measurement.','',
 '### Hardware, reproduction and checks','',
 '2 x Radeon AI PRO R9700 32 GiB, gfx1201; Ryzen9 3900X;109.375 GiB visible RAM;',
 'Ubuntu24.04.4 / Linux7.0.14-12-pve; Python3.12.3; Torch2.14.1+rocm7.2;',
 'HIP7.2.53211; ROCm SDK7.2.3; triton-rocm3.8.0. Communication is torch.distributed',
 'with task-local RCCL2.27.7 and `--disable-pynccl`; an extra RX9070 XT is excluded.',
 'Checkpoint: [RadixArk/Qwen3.8-Flash-Next-NVFP4](https://huggingface.co/RadixArk/Qwen3.8-Flash-Next-NVFP4),',
 'revision `7b719225242aacd3dbd3f9407468c2ee9a9d2594`.','',
 'Exact matrix controller command (scratch harness and dependencies are in the archive):','',
 '```bash',
 'source /root/experiments/FreeToken/.local-build/activate-rocm.sh',
 'cd /root/experiments/FreeToken/.local-build/qwen38-repro/prompt-audit-v3-nfc',
 '/root/experiments/FreeToken/.venv/bin/python run_inference.py',
 '```','',
 'Requests use chat-templated `/v1/completions`, `enable_thinking=False`, an empty',
 'closed think block, temperature0, top_k1, top_p1, no penalties and max_tokens1024.',
 'All69 existing targeted checks pass:54 config/weight and15 precision-path checks.',
 'Actual commands/logs are retained; no maintained test file or tolerance was added.',
 'All seven switches remain disabled by default. Other checkpoints, hardware,',
 'communication backends and TP degrees remain unqualified.','',
 f'[Exact server command, methodology and historical evidence]({doc}) and the',
 f'[hashed v3 evidence archive]({archive}) preserve all prompts, audits,440 responses,',
 '400 accepted judgments, invocation receipts, failure catalogs, timing/resource data,',
 'tests and source/library hashes. Weights, credentials and raw Codex CLI events are omitted.','']
text = '\n'.join(parts)
for a,b in [('become35/41 and34/41','become35/41 and34/41'),('most20','most 20'),('has100','has 100'),('then100','then 100'),('Ryzen9','Ryzen 9'),(';109.375',';109.375'),('Ubuntu24','Ubuntu 24'),('Linux7','Linux 7'),('Python3','Python 3'),('Torch2','Torch 2'),('HIP7','HIP 7'),('SDK7','SDK 7'),('triton-rocm3','triton-rocm 3'),('RCCL2','RCCL 2'),('RX9070','RX 9070'),('temperature0','temperature=0'),('top_k1','top_k=1'),('top_p1','top_p=1'),('max_tokens1024','max_tokens=1024'),('All69','All 69'),('pass:54','pass: 54'),('and15','and 15'),('audits,440','audits, 440')]:
    text = text.replace(a,b)
text = text.replace('become35/41 and34/41','become 35/41 and 34/41').replace(';109.375','; 109.375')
(ROOT/'pr-body.txt').write_text(text)
print(ROOT/'pr-body.txt')
