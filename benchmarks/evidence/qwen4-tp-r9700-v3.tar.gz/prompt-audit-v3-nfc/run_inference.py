"""Four same-source precision/TP configurations on the frozen reviewed prompts."""

import argparse
import hashlib
import json
import runpy
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
TREE = REPRO.parent.parent / '.worktrees/qwen4-tp-fp64'
parser = argparse.ArgumentParser()
parser.add_argument('--resume', action='store_true')
args = parser.parse_args()
OUT = ROOT/'inference'
OUT.mkdir(exist_ok=args.resume)
for name in ('prompts.json','manifest.json'):
    if args.resume:
        assert (ROOT/name).read_bytes() == (OUT/name).read_bytes()
    else:
        shutil.copyfile(ROOT/name,OUT/name)
prompts = json.loads((OUT/'prompts.json').read_text())
manifest = json.loads((OUT/'manifest.json').read_text())
assert hashlib.sha256((OUT/'prompts.json').read_bytes()).hexdigest() == manifest['prompts_sha256']
loaded = runpy.run_path(str(REPRO/'pr-draft/benchmark.py'))
ctx = loaded['run'].__globals__
ctx['ROOT'] = OUT
v1 = dict(ctx['FLAGS'])
v2 = dict(v1,FREETOKEN_TP_REDUCTION_FP64='1',FREETOKEN_STABLE_ATTENTION='1')
append_original, complete_original, post_original = ctx['append'],ctx['complete'],ctx['post']
save, now = ctx['save'],ctx['now']
original_popen = subprocess.Popen
current = dict(stage='starting',utc=now())
label = ''
active = []
request_started = 0.0
first_flush = True
by_name = {p['name']:p for p in prompts}

def state(**values):
    current.update(values,utc=now())
    save(OUT/'state.json',current)
    append_original(OUT/'run.log',dict(current))

def idle():
    with urllib.request.urlopen('http://127.0.0.1:8188/queue',timeout=5) as r:
        q=json.load(r)
    mem={k:int(v.split()[0])*1024 for k,v in
         (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())}
    cards=[]
    for d in Path('/sys/class/drm').glob('card*/device'):
        try:
            if int((d/'mem_info_vram_total').read_text())>30*2**30:
                cards.append(dict(pci=d.resolve().name,used_bytes=int((d/'mem_info_vram_used').read_text()),
                                  busy_percent=int((d/'gpu_busy_percent').read_text())))
        except OSError:
            pass
    observed=dict(utc=now(),ram_available_bytes=mem['MemAvailable'],gpus=cards,
                  comfy_running=len(q.get('queue_running',[])),comfy_pending=len(q.get('queue_pending',[])))
    good=(not observed['comfy_running'] and not observed['comfy_pending']
          and mem['MemAvailable']>=80*2**30 and len(cards)==2
          and all(g['used_bytes']<2*2**30 and g['busy_percent']<=10 for g in cards))
    return good,observed

def wait_idle():
    deadline=time.monotonic()+60
    while True:
        good,observed=idle()
        if good:
            return observed
        append_original(OUT/'idle-waits.jsonl',observed)
        if time.monotonic()>=deadline:
            raise RuntimeError(dict(idle_preflight_failed=observed))
        time.sleep(2)

def popen(command,**kwargs):
    proc=original_popen(command,**kwargs)
    if '--tp-size' in command:
        state(stage='loading',label=label,tp=int(command[command.index('--tp-size')+1]),server_pid=proc.pid)
    return proc

class ObservedResponse:
    def __init__(self,response):
        self.response=response
    def __enter__(self):
        self.response.__enter__()
        return self
    def __exit__(self,*args):
        return self.response.__exit__(*args)
    def __iter__(self):
        for raw in self.response:
            active.append(dict(seconds=time.perf_counter()-request_started,line=raw.decode()))
            yield raw

def post(path,body,timeout=900):
    global first_flush
    if path.startswith('/v1/cache/flush') and first_flush:
        first_flush=False
        time.sleep(3)
    response=post_original(path,body,timeout)
    return ObservedResponse(response) if path=='/v1/completions' else response

def complete(tp,p,kind,flush):
    global request_started
    state(stage='request',label=label,tp=tp,name=p['name'],index=p['index'],kind=kind)
    active.clear()
    request_started=time.perf_counter()
    row=complete_original(tp,p,kind,flush)
    path=f'{label}-{kind}-{p["name"]}-sse.json'
    row['sse_delivery_file']=path
    save(OUT/'sse'/path,dict(label=label,name=p['name'],kind=kind,events=active.copy()))
    return row

def append(path,row):
    append_original(path,row)
    if row['kind']=='core':
        current['completed_core']+=1
    else:
        current['completed_cache']+=1
    p=by_name[row['name']]
    if row['kind']=='core' and p['cache_probe']:
        cached=complete(row['tp'],p,'cache-repeat',None)
        cached['label']=label
        append_original(path,cached)
        current['completed_cache']+=1
        print(json.dumps(dict(event='cache-repeat',label=label,name=p['name'],cache_n=cached['cache_n'])),flush=True)

ctx.update(append=append,complete=complete,post=post)
subprocess.Popen=popen
(OUT/'sse').mkdir(exist_ok=args.resume)
source=ctx['hashes'](TREE)
provenance=dict(utc=now(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=TREE,text=True).strip(),
    source_hashes=source,tracing=False,replay=False,thinking=False,max_completion_tokens=1024,
    profile_order=['v2-tp2','v1-tp2','v1-tp1','v2-tp1'])
if args.resume:
    assert json.loads((OUT/'provenance.json').read_text())['source_hashes']==source
else:
    save(OUT/'provenance.json',provenance)
state(stage='starting')
monitor_source=(REPRO/'validation100/monitor.py').read_text()
monitor_source=monitor_source.replace("assert not out.exists(), 'Preserve existing timeline'", "# Resume appends observations; earlier timeline remains intact.")
(OUT/'monitor.py').write_text(monitor_source)
monitor=original_popen([sys.executable,str(OUT/'monitor.py')])
results=[]
try:
    for label,tp,flags in [('v2-tp2',2,v2),('v1-tp2',2,v1),('v1-tp1',1,v1),('v2-tp1',1,v2)]:
        ctx['FLAGS']=flags
        first_flush=True
        current.update(completed_core=0,completed_cache=0)
        if args.resume and (OUT/f'{label}-summary.json').exists():
            existing=list(map(json.loads,(OUT/f'{label}-responses.jsonl').read_text().splitlines()))
            settings=json.loads((OUT/f'{label}-settings.json').read_text())
            assert len(existing)==110 and sum(r['kind']=='core' for r in existing)==100
            assert settings['source_hashes']==source
            assert {k:v for k,v in settings['environment'].items() if k.startswith('FREETOKEN_')}==flags
            results.append(json.loads((OUT/f'{label}-summary.json').read_text()))
            print(json.dumps(dict(event='preserving-completed-leg',label=label)),flush=True)
            continue
        observed=wait_idle()
        save(OUT/f'{label}-preflight.json',observed)
        results.append(loaded['run'](label,TREE,tp,True,prompts))
        assert current['completed_core']==100 and current['completed_cache']==10
        state(stage='mode-complete',label=label,tp=tp)
        wait_idle()
    assert ctx['hashes'](TREE)==source
    save(OUT/'run-summary.json',results)
    state(stage='complete')
except BaseException as error:
    state(stage='failed',error=repr(error))
    raise
finally:
    monitor.wait(timeout=10)
    subprocess.Popen=original_popen
