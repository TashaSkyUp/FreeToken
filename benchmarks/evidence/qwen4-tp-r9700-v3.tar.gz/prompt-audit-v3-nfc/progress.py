"""Compact, read-only progress for the long sequential benchmark."""

import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
ps={p['name']:p for p in json.loads((ROOT/'prompts.json').read_text())}
check=runpy.run_path(str(ROOT/'scoring_v3.py'))['check_answer']
result=dict(utc=datetime.now(timezone.utc).isoformat())
for label,path in [('inference',ROOT/'inference/state.json'),('pipeline',ROOT/'pipeline-state.json')]:
    if path.exists():
        result[label]=json.loads(path.read_text())
result['configurations']={}
for path in sorted((ROOT/'inference').glob('*-responses.jsonl')):
    rows=[json.loads(s) for s in path.read_text().splitlines() if s.strip()]
    core=[r for r in rows if r['kind']=='core']
    scored=[(r,check(ps[r['name']],r['text'])) for r in core if ps[r['name']]['expected'] is not None]
    result['configurations'][path.stem.removesuffix('-responses')]=dict(core=len(core),
        repeats=sum(r['kind']=='cache-repeat' for r in rows),capped=sum(r['finish_reason']=='length' for r in core),
        max_output_tokens=max((r['usage']['completion_tokens'] for r in core),default=0),
        fixed_checks_completed=len(scored),fixed_checks_passed=sum(c for _,c in scored),
        failing_names=[r['name'] for r,c in scored if not c])
result['cross_tp_completed_pairs']={}
for profile in ('v1','v2'):
    paths=[ROOT/'inference'/f'{profile}-tp{tp}-responses.jsonl' for tp in (1,2)]
    if all(path.exists() for path in paths):
        groups=[{row['name']:row for row in map(json.loads,path.read_text().splitlines()) if row['kind']=='core'} for path in paths]
        names=groups[0].keys() & groups[1].keys()
        result['cross_tp_completed_pairs'][profile]=dict(pairs=len(names),exact_matches=sum(groups[0][name]['text']==groups[1][name]['text'] for name in names))
for label in ('profile-quality','tp-quality'):
    path=ROOT/'quality'/label/'terra-max-judgments/state.json'
    if path.exists():
        state=json.loads(path.read_text())
        result[label]={k:v for k,v in state.items() if k!='active_jobs'}
print(json.dumps(result,indent=2))
