"""Update the existing draft documentation from measured audited-cohort results."""

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TREE = Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-pr')
assert json.loads((ROOT/'pipeline-state.json').read_text())['stage'] == 'complete'
r = json.loads((ROOT/'cohort-summary.json').read_text())
base = subprocess.check_output(['git', 'show', '4aed3f5:docs/qwen4-exp-tp-r9700.md'], cwd=TREE, text=True)
doc = TREE/'docs/qwen4-exp-tp-r9700.md'
assert doc.read_text() == base, 'Preserve independently edited documentation'
c = r['configurations']
tp = r['comparisons']['v2-cross-tp']
v1 = r['comparisons']['v1-cross-tp']
intro = (f'The audited 1,024-token follow-up records **{tp["exact_matches"]}/100 exact V2 TP=1/TP=2 text pairs**, '
         f'compared with {v1["exact_matches"]}/100 for V1 on the same revised prompts. '
         f'V2 strict checks pass {c["v2-tp1"]["fixed_passes"]}/42 at TP=1 and '
         f'{c["v2-tp2"]["fixed_passes"]}/42 at TP=2. '
         'Prompt specificity, tokenizer normalization, completion limits and the judging rubric were audited before the final run. '
         'The historical Unicode-copy failure had an invalid answer key under NFC input normalization and is corrected explicitly below. '
         'Output agreement remains separate from answer quality; the precision switches remain experimental and disabled by default.\n\n')
start, end = base.index('The v2 follow-up records'), base.index('## Changes')
text = base[:start]+intro+base[end:]
text = text.replace('and `max_tokens=128`.\nThe prompt manifest preserves exact text and token counts.',
                    'and `max_tokens=128` in the historical runs. The audited v3 rerun below uses `max_tokens=1024`.\nThe prompt manifests preserve exact text and token counts.')

parts = ['','## Audited prompts and 1,024-token rerun','',
 'The entire 100-prompt matrix was rerun at cleaned commit `4aed3f5c7ae3054fb3813de304ef2b820c804642`,',
 'with identical hashes for all 503 Python engine files in all four configurations.',
 'V1 enables the original five precision flags; V2 adds FP64 reductions and stable attention.',
 'Each configuration runs 100 uncached core requests and ten cache-repeat attempts:',
 '**440 inference responses**, followed by **400 blinded evaluations**. No engine code changed for this rerun.','',
 'A fresh-context agent first audited all 100 user requests without seeing outputs, scores,',
 'answer keys or the conversation. It identified 17 material ambiguities in the original set.',
 'After revision, another fresh-context audit reviewed the exact decoded user turns and found',
 'a remaining long-context shortcut: supplied formulas allowed record retrieval to be bypassed.',
 'The formulas were removed, structural validation was specified, and the final delta was',
 'independently verified. The final audit has no unresolved material finding.',
 'Arithmetic keys were independently recomputed. All 100 rendered inputs round-trip through',
 'the checkpoint tokenizer exactly; the final user-turn SHA256 is',
 '`008c85a8b27c24b2dd163b6f29f284d7f771ef4e45c6f0f9fa05111f2045dbbc`.','',
 'The tokenizer normalizes input to NFC. The historical `unicode-preserve` key required',
 'NFD `e` plus a combining accent even though the model received precomposed `é`.',
 'That historical failure must be excluded: the previously reported V1 35/42 and V2 34/42',
 'become **35/41 and 34/41 valid cases**. The old archives remain unchanged.',
 'The new cohort uses an NFC-stable payload and corrected key, retaining 42 checks;',
 'the other 41 keys are unchanged. An initial revised attempt was stopped when this issue',
 'was found; its partial responses are excluded from the final cohort and preserved locally.','',
 'Requests retain the same greedy settings and explicit `enable_thinking=False` chat template.',
 'The rendered generation prefix ends with an empty closed think block. `/v1/completions`',
 'returns raw delivered text, with the reasoning parser off; no generated text is stripped',
 'as inferred thinking. Raw SSE records reconstruct all 440 saved outputs exactly.',
 'A cap-only check of the eight historical strict failures, using',
 'their original prompts, found seven unchanged natural-stop answers. The fraction answer',
 'continued from 128 to 381 tokens and reached 29/36, but still violated the answer-only format.',
 'The larger cap matters for completion; it does not explain all historical failures.','',
 '| Configuration | Exact TP pairs | Strict passes | Capped core responses | Largest output, tokens |',
 '| --- | ---: | ---: | ---: | ---: |']
for label in ['v1-tp1','v1-tp2','v2-tp1','v2-tp2']:
    item = c[label]
    matches = v1['exact_matches'] if label.startswith('v1') else tp['exact_matches']
    parts.append(f'| {label.upper()} | {matches}/100 | {item["fixed_passes"]}/42 | {item["capped_core"]}/100 | {item["max_completion_tokens"]} |')
parts += ['', f'V2 changes {100-r["comparisons"]["tp1-profile"]["exact_matches"]}/100 TP=1 texts relative to V1. '
          f'V2 TP=2 matches the V1 TP=1 text in {r["comparisons"]["tp1-profile"]["exact_matches"]}/100 cases. '
          'The 100/100 agreement compares TP modes with the same V2 profile enabled in both.']
failures = json.loads((ROOT/'all-fixed-check-failures.json').read_text())
failure_groups = {}
for item in failures:
    failure_groups.setdefault(item['name'], {})[item['configuration']] = item
parts += ['', 'The shared remaining fixed-check failures are delivered content errors, not cutoffs:', '',
          '| Case | Expected | V1 TP1 / TP2 | V2 TP1 / TP2 |',
          '| --- | --- | --- | --- |']
for name, group in failure_groups.items():
    if len(group) != 4:
        continue
    assert all(item['finish_reason'] == 'stop' for item in group.values())
    parts.append(f'| `{name}` | `{group["v1-tp1"]["expected"]}` | `{group["v1-tp1"]["actual"]}` / `{group["v1-tp2"]["actual"]}` | `{group["v2-tp1"]["actual"]}` / `{group["v2-tp2"]["actual"]}` |')
parts += ['',
 'All fixed-check failures, with prompts, expected values and all four actual outputs,',
 'are retained in `all-fixed-check-failures.json` and the matching HTML catalog in the archive.',
 'Fixed checks assess 42 specified answers/formats; the judges assess all 100 requests.',
 'The revised contracts accept equivalent numeric spellings for the weighted average and',
 'enforce the explicitly requested ordering/spacing in two other cases. Legacy checker',
 'totals are retained too. JSON fences and altered Unicode output remain failures.','',
 f'For the {len(r["same_outputs_all_four_short"])} short prompts with identical delivered text, token count and finish reason in all four configurations:', '',
 '| Configuration | TTFT p50 / p95, s | Request p50 / p95, s | Decode p50 / p95, ms/token | Decode p50, tok/s |',
 '| --- | ---: | ---: | ---: | ---: |']
def pair(item):
    return f'{item["p50"]:.3f} / {item["p95"]:.3f}' if item['p50'] is not None else 'n/a'
for label in ['v1-tp1','v1-tp2','v2-tp1','v2-tp2']:
    item = c[label]['same_outputs_all_four']
    rate = item['engine_decode_tokens_per_second']['p50']
    parts.append(f'| {label.upper()} | {pair(item["ttft_seconds"])} | {pair(item["response_seconds"])} | {pair(item["engine_decode_ms_per_token"])} | {rate:.3f} |')
parts += ['',
 'Startup-to-healthy seconds, kept separate from request latency: '+
 ', '.join(f'{label.upper()} {c[label]["startup_to_healthy_seconds"]:.3f}' for label in c)+'.',
 'Resolved expert slots per rank / KV pages: '+
 ', '.join(f'{label.upper()} {c[label]["expert_slots_per_rank"]:,} / {c[label]["kv_pages"]}' for label in c)+'.','',
 'This is one sequential pass, ordered V2 TP2, V1 TP2, V1 TP1, V2 TP1, with existing',
 'disk/JIT caches and no timed warmup phase. The same-output subset controls delivered',
 'workload, but order and cache state remain possible influences. Auto expert cache',
 'residency differs between TP modes. Decode percentiles summarize per-request means;',
 'SSE chunk arrival gaps are retained separately and are not individual GPU token times.',
 'All 440 timing rows, long-input and cache-hit distributions, resource observations and',
 'idle preflights are included. ComfyUI was observed running or queued in '+
 f'{r["service_observations"]["busy_samples"]}/{r["service_observations"]["samples"]} sampled checks; '+
 f'{r["service_observations"]["observation_errors"]} observations failed.','',
 '| Configuration | Actual cache hits | Cold/repeat exact matches | Exact or equal JSON values | Repeat fixed checks |',
 '| --- | ---: | ---: | ---: | ---: |']
for label, item in c.items():
    parts.append(f'| {label.upper()} | {item["cache_hits"]}/10 | {item["cold_repeat_exact_matches"]}/10 | {item["cold_repeat_exact_or_json_value_matches"]}/10 | {item["cache_fixed_passes"]}/{item["cache_fixed_checks"]} |')
parts += ['',
 'The V1 cold/repeat differences are in the final validation explanation; the requested',
 'warehouse/quantity/checksum fields stay unchanged. The V2 repeat difference preserves',
 'the parsed JSON values. Every repeated fixed-answer lookup passes in all four modes.','',
 'The judging rubric was independently audited before any new evaluations. It separates',
 'correctness from completeness/format, prevents double counting, defines partial-answer',
 'handling and semantic-difference classes, and does not penalize a length flag by itself.',
 'Each comparison has 100 forward evaluations, then 100 in reversed sample and A/B order,',
 'using `codex exec`, `gpt-6.1-terra`, `max` reasoning and at most 20 concurrent calls.',
 'Judges see the original request, response texts and finish reasons; source identities',
 'and performance data are hidden. Both comparison sets use this same audited cohort.','',
 '| Comparison | Correctness, left / right | Instruction/completeness, left / right | Semantic similarity |',
 '| --- | ---: | ---: | ---: |']
for key, label, left, right in [('profile-quality','V1 TP1 / V2 TP1','profile1','profile2'),('tp-quality','V2 TP1 / V2 TP2','tp1','tp2')]:
    judged = r['quality'][key]
    values = judged['all_samples']
    correctness = values['correctness']
    instruction = values['instruction_following_completeness']
    parts.append(f'| {label} | {correctness[left+"_mean"]:.3f} / {correctness[right+"_mean"]:.3f} | {instruction[left+"_mean"]:.3f} / {instruction[right+"_mean"]:.3f} | {values["semantic_score_mean"]:.3f} |')
outcomes = r['quality']['profile-quality']['all_samples']['correctness']['stable_outcomes']
parts += ['', f'Across both presentations, profile correctness preferences have {outcomes.get("tie",0)} ties, '
          f'{outcomes.get("profile1_better",0)} favoring V1 and {outcomes.get("profile2_better",0)} favoring V2; '
          f'{outcomes.get("order_sensitive",0)} differ between presentations. All scores use 0-4 anchors.']
parts += ['',
 'Accepted evaluations / actual CLI invocations / identical-output control errors: '+
 '; '.join(f'{key}: {value["evaluations"]} / {value["main_run_cli_invocations"]} / {len(value["identical_control_errors"])}' for key,value in r['quality'].items())+'.',
 'Model judgments are secondary evidence. One evaluation per presentation confounds order',
 'effects with judge variance. New prompts, a larger cap and a revised rubric prevent',
 'direct quality-score comparisons with the historical cohort. This purpose-built set',
 'does not establish general capability or independent reference-engine accuracy.','',
 'All 69 existing targeted engine checks passed on the same source in this task:',
 '54 configuration/weight checks and 15 precision-path checks. Their actual command and',
 'result logs are retained; they were not redundantly repeated after wording-only edits.',
 'A local launch without the ROCm activation environment failed before any response;',
 'the failure log is retained, then the full matrix used the corrected launch environment.','',
 'The report formatter was corrected to display an empty differing-output group, and',
 'historical subset labels were removed. No inference or judging call was repeated;',
 'numeric results are unchanged. Original scripts and a recovery receipt are archived.','',
 'The [v3 evidence archive](../benchmarks/evidence/qwen4-tp-r9700-v3.tar.gz) includes',
 'all frozen prompts, audits, corrected-key provenance, 440 responses, 400 accepted',
 'judgments, every invocation receipt, timing/SSE data, source/library hashes and logs.',
 'Its manifest verifies every payload. Weights, credentials and raw Codex CLI events',
 'are omitted. All profiles remain opt-in, and the scope limitations above still apply.','']
text += '\n'.join(parts)
doc.write_text(text)
print(doc)
