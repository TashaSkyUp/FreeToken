"""Independently verify the fixed answer keys from arithmetic and source data."""

import csv
import io
import json
import re
import unicodedata
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
old = json.loads((REPRO / 'divergence-v2/validation100-fp64/prompts.json').read_text())
prompts = {p['name']: p for p in json.loads((ROOT / 'revised-prompts-blind.json').read_text())}
derived = {}

def number(value):
    return str(value.numerator) if isinstance(value, Fraction) and value.denominator == 1 else str(value)

derived.update({
    'integer-product': str(347 * 29),
    'fraction-sum': str(Fraction(5, 12) + Fraction(7, 18)),
    'discount-tax': format(Decimal(80) * Decimal('0.75') * Decimal('1.08'), '.2f'),
    'modular-power': str(pow(7, 8, 13)),
    'weighted-average': number(Fraction(10*4 + 20*7 + 30*10, 10+20+30)),
    'compound-growth': number(Fraction(500) * Fraction(120, 100) * Fraction(80, 100)),
    'unit-conversion': str(int(Decimal('2.5') * 60 * 60)),
    'probability': str(Fraction(3, 5) * Fraction(2, 4)),
    'ordering': ','.join(['Ada', 'Ben', 'Cara', 'Dev']),
    'set-intersection': sorted({2,4,6,8} & {1,2,3,4}),
    'boolean-expression': str((True and False) or not False).lower(),
    'schedule': (datetime(2000,1,1,9,45) + timedelta(minutes=95)).strftime('%H:%M'),
    'balance': str(int(Fraction(-5-3, 1-2))),
})
x = Fraction(11+1, 2+1)
y = x-1
derived['linear-system'] = f'x={number(x)},y={number(y)}'
edges = {'A':['B','C'], 'B':['D'], 'C':['D'], 'D':['E'], 'E':[]}
def paths(node, path):
    if node == 'E':
        return ['-'.join(path)]
    return [p for child in edges[node] for p in paths(child, path+[child])]
derived['graph-path'] = '\n'.join(sorted(paths('A',['A'])))

def text(name):
    return prompts[name]['user_text']

derived['json-extract'] = {'name':'Noor', 'age':27, 'active':True}
csv_text = text('csv-sort').split('INPUT CSV:\n',1)[1]
csv_rows = sorted(csv.DictReader(io.StringIO(csv_text)), key=lambda r:int(r['score']), reverse=True)
derived['csv-sort'] = 'name,score\n' + '\n'.join(r['name']+','+r['score'] for r in csv_rows)
data, _ = json.JSONDecoder().raw_decode(text('json-nested').split('Data: ',1)[1])
derived['json-nested'] = [r['id'] for r in data if r['paid'] is True]
derived['json-escaping'] = {'text':re.search(r'\n<value>(.*?)</value>',text('json-escaping')).group(1)}
derived['schema-nulls'] = {'city':'Accra','postcode':None}
data, _ = json.JSONDecoder().raw_decode(text('normalize-records').split('Data: ',1)[1])
derived['normalize-records'] = [dict(r,status=r['status'].lower()) for r in data]
derived['word-sort'] = ','.join(sorted(['pear','apple','plum','apricot']))
derived['deduplicate'] = list(dict.fromkeys(['red','blue','red','green','blue','amber']))
derived['date-normalization'] = datetime.strptime('14 March 2025','%d %B %Y').strftime('%Y-%m-%d')
derived['sentiment'] = 'negative'
derived['entity-extract'] = ['Maya','Luis']
derived['redaction'] = re.sub(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[EMAIL]',
                            'Contact ana@example.org or ben@test.net for help.')
derived['unicode-preserve'] = text('unicode-preserve').rsplit('<data>',1)[1].split('</data>',1)[0]
derived['exact-output'] = 'ORCHID'
derived['quoted-instruction'] = str(len(text('quoted-instruction').rsplit('<data>',1)[1].split('</data>',1)[0].split()))
derived['no-letter'] = ' '.join(['sky','rhythm','crypt'])
derived['choose-label'] = 'ACCESS'
derived['extract-not-execute'] = 'delete report.txt'.split()[1]

inventory_checks = []
for name, p in prompts.items():
    if not name.startswith('inventory-'):
        continue
    prefix, request = p['user_text'].rsplit('\n\n',1)
    entries = [json.loads(line) for line in prefix.splitlines()[1:]]
    code = re.search(r'code is exactly (P\d+-\d+)\.',request).group(1)
    matches = [entry for entry in entries if entry['code'] == code]
    assert len(matches) == 1
    derived[name] = matches[0]
    inventory_checks.append(dict(name=name,entries=len(entries),target=code,unique_match=True))

expected = {p['name']:p['expected'] for p in old if p['expected'] is not None}
original_unicode_key=expected['unicode-preserve']
expected['unicode-preserve']=unicodedata.normalize('NFC',original_unicode_key)
assert set(derived) == set(expected), (set(expected)-set(derived),set(derived)-set(expected))
checks = [dict(name=name,expected=expected[name],independent_reference=derived[name],
               equal=json.dumps(expected[name],sort_keys=True,ensure_ascii=False)==json.dumps(derived[name],sort_keys=True,ensure_ascii=False))
          for name in expected]
assert all(c['equal'] for c in checks)

amount = Decimal(120)
tank = []
for hour in range(1,4):
    amount = amount * Decimal('0.85') + Decimal(12)
    tank.append(dict(hour=hour,liters=str(amount)))
valid_boxes = []
for coin in 'ABC':
    labels = [coin=='B',coin!='B',coin!='A']
    if sum(labels) == 1:
        valid_boxes.append(coin)
extra = dict(tank=tank,liar_puzzle_valid_boxes=valid_boxes,
             long_context_record_0317=dict(warehouse=(317*7)%31,quantity=100+317*13,checksum=(317*317+17)%997))
manual = ['json-extract facts and field types', 'ordering premises imply the unique order',
          'negative review label', 'Maya/Luis are people, Oslo is the place',
          'ORCHID copying', 'ACCESS category for password reset']
report = dict(utc=datetime.now(timezone.utc).isoformat(),fixed_answer_keys=len(checks),
              mismatches=0,keys_unchanged=False,changed_keys={'unicode-preserve':dict(original=original_unicode_key,corrected=expected['unicode-preserve'],reason='Match NFC input actually received by model; former NFD exact-copy expectation was invalid under tokenizer normalization.')},checks=checks,inventory_checks=inventory_checks,
              supplemental_references=extra,manual_semantic_review=manual)
(ROOT/'answer-key-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Verified all',len(checks),'fixed answer keys; Unicode key canonicalized to match actual NFC input. Additional references:',extra)
