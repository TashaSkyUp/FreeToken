"""Align fixed-answer scoring with the frozen v3 output contracts."""

import re
import runpy
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
legacy_check = runpy.run_path(str(ROOT.parent/'validation100/analyze.py'))['check_answer']

def check_answer(p, text):
    if p['expected'] is None:
        return None
    actual = text.strip()
    if p['name'] in ('ordering','graph-path'):
        # V3 explicitly requires comma spacing and sorted path lines.
        return actual == p['expected']
    if p['name'] == 'weighted-average':
        # This contract asks for a number, not an integer spelling.
        literal = r'[+-]?(?:(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|\d+/\d+)'
        if not re.fullmatch(literal,actual,flags=re.ASCII):
            return False
        try:
            return Fraction(actual) == Fraction(p['expected'])
        except (ValueError,ZeroDivisionError):
            return False
    return legacy_check(p,text)

if __name__ == '__main__':
    assert check_answer({'name':'weighted-average','expected':'8'},'8.0')
    assert check_answer({'name':'weighted-average','expected':'8'},'8e0')
    assert not check_answer({'name':'weighted-average','expected':'8'},'The answer is 8.')
    assert not check_answer({'name':'weighted-average','expected':'8'},'8.1')
    assert not check_answer({'name':'ordering','expected':'A,B'},'A, B')
    assert not check_answer({'name':'graph-path','expected':'A-B\nA-C'},'A-C\nA-B')
    assert check_answer({'name':'json','expected':[1,2]},'[1, 2]')
    assert not check_answer({'name':'json','expected':[1,2]},'```json\n[1,2]\n```')
    print('Eight synthetic scoring-contract checks pass; no model outputs used as fixtures.')
