#!/usr/bin/env python3
"""Summarize both blinded Codex judge passes without discarding disagreements."""

import argparse
import csv
import html
import json
import statistics
from collections import Counter
from pathlib import Path

QUALITY = ['correctness', 'instruction_following_completeness']


def mean(xs):
    xs = [x for x in xs if x is not None]
    return statistics.mean(xs) if xs else None


def vote(a, b):
    if a is None or b is None:
        return 'unassessable'
    return 'tie' if a == b else 'tp2_better' if b > a else 'tp1_better'


def normalize(r):
    result = dict(sample_index=r['sample_index'], sample_name=r['sample_name'],
        category=r['category'], phase=r['phase'],
        identical_source_text=r['identical_source_text'],
        semantic_similarity=r['judgment']['semantic_similarity'],
        wall_seconds=r['wall_seconds'], usage=r['usage'])
    for dim in QUALITY:
        raw = r['judgment'][dim]
        scores = {r['presentation'][label]: raw[label.lower()+'_score'] for label in ['A','B']}
        result[dim] = dict(**scores, outcome=vote(scores['tp1'],scores['tp2']),
                           rationale=raw['rationale'], confidence=raw['confidence'])
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run-dir',type=Path,default=Path(__file__).resolve().parent/'terra-max-judgments')
    args = ap.parse_args()
    root = args.run_dir.resolve()
    manifest = json.loads((root/'manifest.json').read_text())
    rows = [json.loads(l) for l in (root/'judgments.jsonl').read_text().splitlines()]
    assert len(rows)==200
    assert Counter(r['phase'] for r in rows)=={'forward':100,'reversed':100}
    assert all(r['model']=='gpt-6.1-terra' and r['reasoning_effort']=='max' for r in rows)
    ns = [normalize(r) for r in rows]
    phases = {phase: {r['sample_name']:r for r in ns if r['phase']==phase} for phase in ['forward','reversed']}
    assert set(phases['forward'])==set(phases['reversed'])
    pairs = []
    for name, a in phases['forward'].items():
        b = phases['reversed'][name]
        assert a['identical_source_text']==b['identical_source_text']
        p = dict(sample_index=a['sample_index'],sample_name=name,category=a['category'],
                 identical_source_text=a['identical_source_text'],
                 semantic_forward=a['semantic_similarity'],semantic_reversed=b['semantic_similarity'],
                 semantic_score_mean=mean([a['semantic_similarity']['score'],b['semantic_similarity']['score']]),
                 semantic_score_equal=a['semantic_similarity']['score']==b['semantic_similarity']['score'],
                 semantic_kind_equal=a['semantic_similarity']['difference_kind']==b['semantic_similarity']['difference_kind'])
        for dim in QUALITY:
            x,y=a[dim],b[dim]
            p[dim]=dict(tp1_mean=mean([x['tp1'],y['tp1']]),tp2_mean=mean([x['tp2'],y['tp2']]),
                  forward=x,reversed=y,
                  outcome_agrees=x['outcome']==y['outcome'],
                  stable_outcome=x['outcome'] if x['outcome']==y['outcome'] else 'order_sensitive',
                  tp1_score_equal=x['tp1']==y['tp1'],tp2_score_equal=x['tp2']==y['tp2'],
                  direction_flip={x['outcome'],y['outcome']}=={'tp1_better','tp2_better'})
        pairs.append(p)
    pairs.sort(key=lambda x:x['sample_index'])

    def summarize(selected):
        result = dict(samples=len(selected), semantic_score_mean=mean([p['semantic_score_mean'] for p in selected]),
            semantic_score_agreement=sum(p['semantic_score_equal'] for p in selected),
            semantic_kind_agreement=sum(p['semantic_kind_equal'] for p in selected),
            semantic_difference_kinds=dict(Counter(p[k]['difference_kind'] for p in selected for k in ['semantic_forward','semantic_reversed'])))
        for dim in QUALITY:
            valid=[p for p in selected if p[dim]['tp1_mean'] is not None and p[dim]['tp2_mean'] is not None]
            result[dim]=dict(tp1_mean=mean([p[dim]['tp1_mean'] for p in valid]),
                tp2_mean=mean([p[dim]['tp2_mean'] for p in valid]),
                mean_tp2_minus_tp1=mean([p[dim]['tp2_mean']-p[dim]['tp1_mean'] for p in valid]),
                paired_assessable_samples=len(valid),
                stable_outcomes=dict(Counter(p[dim]['stable_outcome'] for p in selected)),
                outcome_agreement=sum(p[dim]['outcome_agrees'] for p in selected),
                tp1_score_agreement=sum(p[dim]['tp1_score_equal'] for p in selected),
                tp2_score_agreement=sum(p[dim]['tp2_score_equal'] for p in selected),
                direction_flips=sum(p[dim]['direction_flip'] for p in selected))
        return result

    per_phase={}
    for phase in ['forward','reversed']:
        rs=list(phases[phase].values())
        s={}
        for dim in QUALITY:
            s[dim]=dict(tp1_mean=mean([r[dim]['tp1'] for r in rs]),tp2_mean=mean([r[dim]['tp2'] for r in rs]),
                         outcomes=dict(Counter(r[dim]['outcome'] for r in rs)))
        s['semantic_similarity_mean']=mean([r['semantic_similarity']['score'] for r in rs])
        per_phase[phase]=s
    identical=[p for p in pairs if p['identical_source_text']]
    different=[p for p in pairs if not p['identical_source_text']]
    control_errors=[]
    for r in ns:
        if not r['identical_source_text']:
            continue
        errors=[]
        for dim in QUALITY:
            if r[dim]['tp1']!=r[dim]['tp2']:errors.append(dim+': unequal identical-output scores')
        if r['semantic_similarity']['score']!=4:errors.append('identical output semantic score below 4')
        if r['semantic_similarity']['difference_kind']!='identical':errors.append('identical output misclassified')
        if errors:control_errors.append(dict(phase=r['phase'],sample=r['sample_name'],errors=errors))
    usage={k:sum((r['usage'] or {}).get(k,0) for r in rows) for k in
           ['input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens']}
    events=[json.loads(l) for l in (root/'events.jsonl').read_text().splitlines()]
    attempts=list(root.glob('*/*/attempt-*'))
    failed_attempts=[]
    all_attempt_usage=Counter()
    for attempt in attempts:
        failure=attempt/'failure.json'
        if failure.exists():failed_attempts.append(dict(path=str(attempt.relative_to(root)),**json.loads(failure.read_text())))
        log=attempt/'events.jsonl'
        if log.exists():
            for line in log.read_text().splitlines():
                try:e=json.loads(line)
                except ValueError:continue
                if e.get('type')=='turn.completed':all_attempt_usage.update(e.get('usage',{}))
    summary=dict(manifest=manifest,evaluations=len(rows),distinct_samples=len(pairs),
         all_samples=summarize(pairs),differing_outputs=summarize(different),
         identical_controls=summarize(identical),identical_control_errors=control_errors,
         per_phase=per_phase,
         by_category={c:summarize([p for p in pairs if p['category']==c]) for c in dict.fromkeys(p['category'] for p in pairs)},
         max_observed_concurrency=max(e['max_observed_concurrency'] for e in events),
         usage=usage,main_run_cli_invocations=len(attempts),failed_attempts=failed_attempts,
         all_main_attempt_usage=dict(all_attempt_usage),
         mean_evaluation_wall_seconds=mean([r['wall_seconds'] for r in rows]),
         limitations=[
            'Model-based judgments are evidence, not a ground-truth accuracy benchmark.',
            'One independent evaluation per presentation order; order effects and judge variability are confounded.',
            'The judge saw original requests and delivered text, including truncation annotations, but no engine identities or timing data.',
            'Each source response had a maximum of 1024 completion tokens; observed finish reasons are retained and completeness is judged from delivered text.',
            'Both sample submission sequence and A/B presentation were reversed in the second pass.',
            'Source text and inference outputs were not regenerated or changed.',
            'All 400 accepted judgments belong to this new audited-prompt cohort; attempts and retries are counted separately for each 200-evaluation comparison.'])
    (root/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    (root/'paired-summary.json').write_text(json.dumps(pairs,indent=2,ensure_ascii=False)+'\n')
    with (root/'scores.csv').open('w') as f:
        fields=['sample_index','sample_name','category','phase','identical_source_text',
                'correctness_tp1','correctness_tp2','correctness_outcome',
                'instruction_tp1','instruction_tp2','instruction_outcome','semantic_score','difference_kind','evaluation_seconds']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in ns:
            w.writerow(dict(sample_index=r['sample_index'],sample_name=r['sample_name'],category=r['category'],phase=r['phase'],
                identical_source_text=r['identical_source_text'],correctness_tp1=r['correctness']['tp1'],
                correctness_tp2=r['correctness']['tp2'],correctness_outcome=r['correctness']['outcome'],
                instruction_tp1=r[QUALITY[1]]['tp1'],instruction_tp2=r[QUALITY[1]]['tp2'],instruction_outcome=r[QUALITY[1]]['outcome'],
                semantic_score=r['semantic_similarity']['score'],difference_kind=r['semantic_similarity']['difference_kind'],evaluation_seconds=r['wall_seconds']))
    lines=['Blinded Terra-max evaluation of 100 TP output pairs',
       'Model gpt-6.1-terra; reasoning max; codex exec; 200 accepted evaluations.',
       f"Observed maximum concurrency: {summary['max_observed_concurrency']}.",
       'Forward: ascending samples, A=TP1/B=TP2. Reversed: descending samples, A=TP2/B=TP1.',
       'Scores 0-4; correctness can be unassessable. Means average both presentation orders.', '']
    def score(value, signed=False):
        return 'n/a' if value is None else format(value, '+.3f' if signed else '.3f')
    for label, key in [('All samples','all_samples'),('Differing outputs','differing_outputs'),('Identical controls','identical_controls')]:
        s=summary[key];lines += [label]
        for dim in QUALITY:
            d=s[dim]
            lines += [f"  {dim}: TP1={score(d['tp1_mean'])}, TP2={score(d['tp2_mean'])}, delta={score(d['mean_tp2_minus_tp1'], True)}; outcomes={d['stable_outcomes']}; direction flips={d['direction_flips']}"]
        lines += [f"  Semantic similarity mean={score(s['semantic_score_mean'])}/4; exact score agreement={s['semantic_score_agreement']}/{s['samples']}", '']
    lines += [f"Identical-control inconsistencies: {len(control_errors)} evaluations.",
              f"Main run CLI invocations: {len(attempts)}; rejected/retried attempts: {len(failed_attempts)}.",
              f'Accepted-evaluation token usage: {usage}', '', 'Limitations:']+summary['limitations']
    (root/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
    esc=html.escape
    parts=['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
      '<title>Blinded Terra evaluation: TP1 vs TP2</title>',
      '<style>body{font:16px/1.5 system-ui;max-width:1150px;margin:40px auto;padding:0 22px;background:#f7f9fc;color:#172738}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:white;border:1px solid #d4dce7;padding:16px;font:13px/1.5 ui-monospace,monospace}details{background:#edf2f8;padding:13px;margin:10px 0;border-radius:8px}summary{cursor:pointer;font-weight:650}table{width:100%;border-collapse:collapse;background:white}td,th{border-bottom:1px solid #d4dce7;text-align:left;padding:8px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:750px){.cols{display:block}}</style>',
      '<h1>Blinded Terra evaluation of TP1 and TP2</h1>',
      '<p>100 sample pairs, two presentation orders, 200 independent Codex calls, 20 concurrent workers. Scores run from 0 to 4. The model sees A/B, with engine identities hidden.</p>',
      '<pre>'+esc((root/'RESULTS.txt').read_text())+'</pre>',
      '<h2>Per-sample scores and rationales</h2><p>Ratings are remapped to TP identities here after judging. Rationales retain the original A/B labels; their presentation mapping is shown.</p>']
    raw={(r['phase'],r['sample_name']):r for r in rows}
    for p in pairs:
        flags=[]
        for dim in QUALITY:
            if p[dim]['stable_outcome']!='tie':flags.append(dim+': '+p[dim]['stable_outcome'])
        caption='; '.join(flags) or 'quality tie in both orders'
        parts += [f"<details><summary>{p['sample_index']:03d} · {esc(p['category'])} · {esc(p['sample_name'])} · {esc(caption)}</summary>",
                  '<table><tr><th>Dimension</th><th>TP1 mean</th><th>TP2 mean</th><th>Across orders</th></tr>']
        for dim in QUALITY:
            d=p[dim];parts += [f"<tr><td>{esc(dim)}</td><td>{d['tp1_mean']}</td><td>{d['tp2_mean']}</td><td>{esc(d['stable_outcome'])}</td></tr>"]
        parts += ['</table>', f"<p>Semantic score: {p['semantic_forward']['score']}/4 forward; {p['semantic_reversed']['score']}/4 reversed.</p>",'<div class="cols">']
        for phase in ['forward','reversed']:
            r=raw[phase,p['sample_name']]
            parts += [f"<div><h3>{esc(phase)}: A={r['presentation']['A']}, B={r['presentation']['B']}</h3><pre>{esc(json.dumps(r['judgment'],indent=2,ensure_ascii=False))}</pre></div>"]
        parts += ['</div>']
        ip=root/'forward'/f"{p['sample_index']:03d}-{p['sample_name']}"/'judge-input.json'
        payload=json.loads(ip.read_text())
        parts += ['<details><summary>Original request and source responses</summary><pre>'+esc(json.dumps(payload,indent=2,ensure_ascii=False))+'</pre></details>','</details>']
    parts += ['<p><a href="scores.csv">All scores CSV</a> · <a href="judgments.jsonl">Raw accepted judgments</a> · <a href="paired-summary.json">Paired summary JSON</a> · <a href="rubric.txt">Frozen rubric</a> · <a href="manifest.json">Manifest</a></p></html>']
    (root/'report.html').write_text('\n'.join(parts))
    print((root/'RESULTS.txt').read_text())


if __name__=='__main__':main()
