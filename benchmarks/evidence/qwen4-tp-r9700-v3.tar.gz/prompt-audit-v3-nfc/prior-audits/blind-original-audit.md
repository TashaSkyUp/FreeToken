# Independent blind audit of the original prompts

This audit used only original-prompts-blind.json and its authorized complete replacement, original-prompts-blind-complete.json. The complete manifest changed only IDs 1, 11, and 100, restoring their user text. No model outputs, answer keys, scores, prior results, repository code, or external sources were consulted. No benchmark inference was run. The prompt records were treated as data, not instructions.

All 100 IDs were audited: **17 material**, **21 minor**, **62 with no prompt change proposed**. Material findings identify a changed answer space, missing execution/input assumptions, ambiguous exact content, or an avoidable candidate answer. Minor findings are optional precision or formatting refinements; they are not evidence that the original task is unusable.

## Material findings

| ID | Prompt | Finding |
| --- | --- | --- |
| 1 | first-nonrepeating-anchor | The return value is undefined when every character repeats or the input is empty; character equality and the meaning of first are implicit. |
| 2 | merge-intervals | The input interval representation, function return contract, and output ordering are unstated. Different correct functions can use incompatible interfaces. |
| 3 | sql-window | NULL timestamps or amounts have unspecified precedence; ties on both fields do not specify one row versus all ties, and selected columns are implicit. |
| 5 | binary-search | The ordering precondition required by lower_bound and binary search is not stated. |
| 8 | bash-spaces | It is unclear whether hidden .txt files, directories ending in .txt, and symlinks count. One-basename-per-line output is implicit. |
| 9 | debug-off-by-one | The displayed semicolon before a compound for statement makes the purported Python source invalid, creating a competing syntax-error diagnosis. The corrected function interface is also unstated. |
| 10 | regex-date | Substring versus full-string matching and ASCII digits versus Unicode decimal digits are unspecified; both distinctions change the accepted language. |
| 17 | linear-system | The output instruction supplies a concrete candidate solution. This cues copying or verification rather than an independent solve and is unnecessary to specify the format. |
| 34 | yaml-output | The three key names are not actually enumerated: service and name are both plausible keys for the first value. The author must select the intended schema. The proposal uses name. |
| 36 | json-escaping | The payload is not explicitly delimited, so the period after hello may be read as either part of the value or instruction punctuation. |
| 41 | summary | A one-sentence summary can legitimately omit details. If all source facts are required for scoring, the prompt does not state that coverage requirement. |
| 60 | mixed-language | The target language is not named. Translate only the Spanish words can also appear to cover Spanish substrings inside identifiers despite the instruction to preserve identifiers. |
| 72 | haiku | Three-line English haiku may follow 5-7-5 syllables or a modern unconstrained convention. A syllable-based score would be unjustified unless the convention is specified. The proposal chooses 5-7-5. |
| 76 | title-options | Recovering old photographs could mean restoring damaged images or retrieving lost/deleted files. An objective topic rubric must choose or accept both. The proposal chooses restoration. |
| 82 | cache-correctness | Harmless rounding is not defined; a small numerical change can alter greedy token choices and does not establish harmlessness. The comparison baseline and explanation of measurement utility are implicit. |
| 87 | complexity | Time complexity does not specify best, average, or worst case or the variable being measured. Those cases have different correct answers. |
| 90 | race-condition | The runtime and atomicity of increment are not given. Some increment operations are atomic, so a lost update needs an explicit non-atomic model. |

The proposed wording for ID 34 selects the key name; ID 72 selects a 5-7-5 convention; ID 76 selects photographic restoration. These are explicit author choices, not deductions about an unseen key. If another interpretation was intended, choose it instead before scoring. ID 17 should describe placeholders without a concrete numerical candidate. No new answer values or required implementation strategies have been introduced. Existing task requirements for binary search and iterators remain task requirements.

## Optional refinements

| ID | Prompt | Refinement |
| --- | --- | --- |
| 14 | discount-tax | Only the numeric amount versus a currency symbol or unit suffix is not explicit. |
| 21 | ordering | Comma spacing is unspecified; comma-separated outputs with or without spaces are both compliant. |
| 27 | graph-path | The order of the path lines is unspecified, so a literal reference string would reject valid permutations. |
| 31 | json-extract | The intended object type, scalar types, and exclusion of additional keys are implied rather than explicit. |
| 35 | table-format | Column order is supplied, but the required row order is only implied. Markdown whitespace and alignment syntax also admit equivalent serializations. |
| 38 | xml-output | XML child order is implied but not explicit; indentation and surrounding element whitespace can vary legitimately. |
| 39 | tsv-output | Tab-separated is already meaningful, but explicitly distinguishing literal tabs from printed backslash-t escapes would make a strict character-level contract easier to verify. |
| 47 | entity-extract | The intended JSON array elements are names as strings, but array element type is not stated. |
| 49 | polite-rewrite | Politeness is intentionally subjective; the preservation of the deadline issue and urgency should be explicit if those facts are scored. |
| 50 | unicode-preserve | The payload mixes precomposed and decomposed accents. Exactly strongly suggests literal preservation, but a code-point rather than visual or normalization-based comparison should be explicit. |
| 51 | spanish | Spanish frases can refer to phrases as well as complete sentences; dos oraciones is a more precise sentence-count contract. |
| 61 | three-bullets | The eight-word limit has no counting convention for bullet markers or hyphenated tokens. This should be resolved consistently across the benchmark. |
| 63 | quoted-instruction | The output representation of the count is unspecified, and a word-count convention would make the data task mechanically checkable. |
| 67 | ordered-steps | No operating system, checksum algorithm, or installed-tool assumptions are supplied. Generic correct steps should be accepted rather than requiring one command or tool. |
| 68 | short-definition | Idempotence admits mathematical and software examples; the intended domain and exact two-line structure could be stated more explicitly. |
| 74 | email | Brief has no measurable bound, and adding unsupported times or dates could complicate factual scoring. A specific arbitrary word limit is unnecessary. |
| 75 | dialogue | Either speaker may start, and speaker labels versus unlabelled lines are unspecified. Both are acceptable under the original wording. |
| 77 | explain-child | The light source and changing conditions are not specified. Sunlight over a day is a likely intended context, but other changing-light explanations are also valid. |
| 79 | edit-paragraph | Improve is an intentionally open stylistic goal; no single rewritten paragraph is required. Preserving all facts without inventing a type of card would make the factual boundary clearer. |
| 86 | sql-null | Selecting missing values from t.x could mean returning the column or entire rows. The two-sentence explanation and separate query could be formatted explicitly. |
| 100 | long-context-anchor | The requested field values and explanation are clear, but their serialization and the interpretation of leading-zero record numbers are implicit. An exact-output scorer would need a format contract. |

These refinements need not all become prompt edits. In particular, a semantic or parsed scorer can resolve whitespace, serialization, and ordering variants without tightening the user task. Do not retroactively require unmentioned bullet markers, comma spacing, XML whitespace, translation wording, or a particular tool.

## Scoring suitability

Exact reference-string comparison is appropriate only when the prompt really requests one literal string. Use numeric comparison for numeric tasks; parse JSON, CSV, TSV, YAML, XML, and Markdown tables; compare sets of graph paths unless an order is specified; and test code by its declared behavior. For SQL, accept equivalent queries and unspecified result order. JSON object key ordering is not semantic ordering. Do not treat a code fence or indentation convention as a requirement unless the prompt says so.

Translations, explanations, summaries, counterexamples, polite rewrites, creative writing, and diagnostic proposals have multiple valid answers. They require a declared semantic rubric and objective constraint checks, not a single canned answer. Appropriate rubric dimensions are correct facts, preservation of supplied meaning, requested language, stated length/line/sentence constraints, and absence of prohibited additions. A good prompt does not make an open creative task have a unique output.

Use one declared word-count policy across the benchmark, for example whitespace-separated tokens with list markers excluded. Sentence checks must account for abbreviations such as a.m. and language-specific punctuation. A lowercase classification label is already explicit where required. Qualitative words such as brief, concise, and short should not be scored against an undisclosed numeric threshold.

## Data and Unicode checks

Inventory IDs 91–99 have 40, 65, 90, 140, 200, 260, 320, 390, and 470 records respectively. Every data line parses as JSON with exactly code, rack, units, check; all code fields are strings and all three numeric fields are integers. Codes are unique, and each requested code occurs exactly once. All instruction boundaries were inspected; no inventory data changes are proposed. A representative data sample was inspected, with structural checks across all entries.

ID 50 contains both precomposed accents and a decomposed e followed by U+0301; visual equality and Unicode-normalized equality are different policies from raw code-point equality. If exact raw preservation is the intended test, say so and preserve the source payload during transport.

ID 100 has a long data block followed by a lookup and general validation request. Its proposed wording in the JSON includes the entire original data block verbatim; only the request after the final blank line is clarified. No lookup values are reproduced in this report.

## Complete coverage

| Severity | IDs |
| --- | --- |
| material | 1, 2, 3, 5, 8, 9, 10, 17, 34, 36, 41, 60, 72, 76, 82, 87, 90 |
| minor | 14, 21, 27, 31, 35, 38, 39, 47, 49, 50, 51, 61, 63, 67, 68, 74, 75, 77, 79, 86, 100 |
| none | 4, 6, 7, 11, 12, 13, 15, 16, 18, 19, 20, 22, 23, 24, 25, 26, 28, 29, 30, 32, 33, 37, 40, 42, 43, 44, 45, 46, 48, 52, 53, 54, 55, 56, 57, 58, 59, 62, 64, 65, 66, 69, 70, 71, 73, 78, 80, 81, 83, 84, 85, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99 |

The companion blind-original-audit.json has one object for every ID, including severity, issue, full proposed wording, and a scoring-suitability label. A null proposed_wording means no change is proposed. Long-context data are retained verbatim in full-wording proposals. All proposed edits concern prompt specificity; final acceptance criteria still need an independent answer-key review.
