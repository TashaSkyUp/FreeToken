# Blind audit of the judging instruction

**Material clarifications are needed before judging.** The existing three dimensions and 0–4 scale are suitable, but several boundaries permit inconsistent scores. This audit used only judge-rubric-for-blind-audit.txt, containing instructions and placeholder payloads. No generated response, answer key, prior judgment, or score was accessed. No inference was run.

Audited instruction SHA-256: `334cd9344ed3cdbff5c4f5c90bad834b3815c55bdcd92aa9bedfe86c4837ffcb`.

The fixes below concern scoring policy, not presentation style. They preserve the three dimensions, the scale, independent A/B quality scores, one symmetric similarity score, and the existing difference-class enum.

## 1. Make correctness anchors exclusive and define unassessable cases

The current “4 = no material error” also permits a minor error, which separately qualifies for 3. “0 = unusable” and “null only when correctness cannot meaningfully be determined” also overlap for empty, irrelevant, or unfinished responses. Different evaluators can assign different scores without violating the instruction.

Replace the correctness anchors and null guidance with:

> 4 = no identified factual, logical, mathematical, or technical error in the assessable content delivered; 3 = a minor localized content error; 2 = meaningful correct content mixed with at least one material content error; 1 = predominantly incorrect, with limited correct task-relevant content; 0 = no usable task-relevant content, or a fundamentally incorrect answer. An empty or wholly irrelevant response receives 0, not null. Use null only when task-relevant content is present but its correctness cannot be assessed from the supplied request/data and your own reasoning; explain the specific limitation. Multiple valid answers and creative freedom do not justify null.

This proposal chooses an explicit empty-response policy consistent with the existing unusable = 0 anchor. Another policy is possible, but it must be stated before judging and used consistently.

## 2. Allocate defects consistently between correctness and instruction/completeness

The phrase “unless they also prevent task fulfillment” is too broad: nearly any wrong factual answer can be described as preventing fulfillment. The unfinished-code guidance also leaves unclear whether truncation alone lowers both dimensions. These choices materially affect the interpretation of the two quality scores.

Replace that exception and clarify partial-source treatment with:

> Score a defect in its primary dimension once by default. Put false claims, wrong computed results, invalid reasoning, and demonstrated defects in proposed code behavior under correctness. Put missing requested parts, incomplete delivery, violated length/line/count constraints, and presentation or serialization violations under instruction-following/completeness. A wrong answer does not by itself lower instruction-following if all requested parts are attempted in the required form. Lower both dimensions only for separately identifiable defects, and name those defects in the rationales; do not count “the correct answer was not supplied” as a second omission.
>
> For an abrupt cutoff, do not invent a continuation. Count the missing remainder under completeness. Assess any independently judgeable delivered claims or code under correctness. A syntax or logic defect already demonstrated in the delivered material is a correctness issue; syntax that is incomplete solely because the text ends is not automatically an additional correctness failure. Use the stated null policy when the relevant partial content cannot be assessed. A high correctness score for a valid delivered portion does not imply a complete runnable solution.

The existing instruction/completeness anchors can remain after this allocation rule. Format-only failures should not reduce correctness when the underlying answer is intact. Conversely, a formatting-looking change that alters behavior or the literal requested data is substantive.

## 3. Resolve semantic-score overlap and meaning-sensitive formatting

“0 = incompatible” conflicts with score 2 when two answers share substantial content but disagree on an essential detail. The parenthetical “including whitespace” can also be misread as declaring whitespace universally immaterial. Python indentation, characters within string values, table delimiters, and exact-copy payloads can be semantically significant.

Replace the similarity anchors and formatting guidance with:

> 4 = equivalent meaning and behavior, allowing presentation changes or paraphrases that preserve all substantive content; 3 = the same core answer and key claims, with small nonessential additions, omissions, or details; 2 = substantial shared meaning or behavior, but at least one essential claim, detail, or delivered part differs; 1 = limited substantive overlap, with predominantly different answers or behavior; 0 = no substantive shared answer content, or wholly incompatible overall answers. One conflicting detail does not automatically force 0 when substantial content is shared. A shared topic alone does not establish substantive similarity.
>
> Treat a whitespace, punctuation, or layout change as formatting-only only when it leaves the interpreted content and behavior unchanged. Preserve significance inside code, string values, required delimiters, and exact-copy data. Similarity is symmetric and independent of quality: two wrong responses can be equivalent, and two valid creative responses can differ substantially. Compare partial responses only as delivered; do not assume missing endings would agree.

## 4. Give the difference classes a deterministic boundary

Different valid content can also literally be a changed answer or claim. Paraphrases and formatting changes can coexist. Substantive omissions, including truncation, are not explicitly assigned to a class. The enum needs precedence to produce comparable labels.

Add:

> Choose exactly one difference class, using these boundaries in order. `identical`: the decoded response texts are character-for-character identical, regardless of finish metadata. `formatting_only`: only presentation differs, with no change to substantive meaning or behavior. `paraphrase_only`: wording or expression differs but substantive meaning and behavior are equivalent; harmless formatting changes may also occur. `different_valid_content`: substantive content differs, but both alternatives are valid choices allowed by the request, such as different valid examples or stories. `changed_claim_or_answer`: a substantive claim, computed result, behavior, or required delivered content differs and the difference is not simply a permitted choice of valid content; this includes material additions or omissions. `uncertain`: the supplied information is insufficient to choose among the content-difference classes; explain why.
>
> A content-difference class is not a winner label. Quality and similarity still use their own anchors. When response texts are identical, assign equal quality scores and similarity 4 even if their finish reasons differ.

## 5. Clarify the candidate cap and control position/verbosity bias

The 1024-token note refers to candidate generation, while the evaluator also has a separate output instruction. The distinction should be explicit. Finish metadata can otherwise become a proxy penalty rather than evidence about the delivered answer. The existing instruction not to reward A/B position or verbosity is sound but should be connected to how scores are assigned.

Add:

> The maximum of 1024 completion tokens applies to generating each candidate response; it is not an answer-length target and does not itself specify the evaluator's output budget. Judge only the delivered candidate text. A `length` finish reason does not by itself mean a requested answer is incomplete or deserve a penalty; a `stop` finish reason does not prove completeness. Apply the same criteria to the visible text in either case. Do not infer equal character lengths or equal content needs from an equal token maximum.
>
> Assign each candidate's correctness and instruction/completeness scores against the request and absolute anchors before comparing semantic content. Do not grade one relative to the other's quality, verbosity, confidence, formatting, or position. A concise answer that fulfills the request can receive full scores; additional accurate but unrequested material does not earn extra credit, and prohibited additions affect instruction-following. The same delivered text must receive the same quality scores under either label. Keep the existing limit of at most 100 words per rationale, which is a maximum rather than a target.

## Runtime checks that the audited file cannot establish

The instruction references a “supplied response schema,” but the schema is not included in this audit file. This is a conditional blocker: ensure the actual evaluation call supplies it. It must represent separate A/B correctness and instruction/completeness scores, one symmetric semantic score, the difference class, and rationales, with only correctness allowing the stated null case. If an API response schema is already supplied, no additional schema needs to be pasted into the instruction.

An instruction cannot establish whether the caller counterbalances A/B position. Before aggregating results, confirm that source-to-position assignment is prespecified and balanced or randomized, or otherwise account for order. A fixed source always in A remains a position-bias risk despite the instruction not to favor A. This check requires no access to candidate content or scores.

Keep the untrusted-data boundary. The original request is used only as the specification against which candidates are evaluated; the evaluator should not answer it or obey instructions inside either candidate. Keep the prohibition on tools and the requirement to return only schema-valid JSON.

The first five items are the material instruction fixes proposed before judging. No change to the frozen benchmark prompts, candidate responses, three dimensions, 0–4 scale, or difference-class enum is proposed.

## Final verification of judge-rubric-v2.txt

**All five material instruction findings are resolved. No remaining material blocker was identified.**

Verified file SHA-256: `7b0c47c1c4f6e5bf5b0d6681e8538937eff9275eae425f4597fa75c93c8a1e97`.

The revised text makes the correctness anchors exclusive, defines zero versus null, allocates defects between correctness and completeness, handles cutoff material without assuming a continuation, resolves similarity/formatting boundaries, orders the difference classes, and states that finish metadata and the candidate 1024-token cap are not automatic scoring penalties. It retains exactly the three dimensions and the 0–4 scale, and explicitly requires equal quality scores for identical delivered text under either label.

The task owner reports that the runtime schema is supplied through Codex exec --output-schema and contains separate A/B correctness (nullable) and completeness scores, symmetric similarity, and the class/rationale/confidence fields. The task owner also reports checking all 100 forward and reversed samples: sources swap A/B and sample submission order reverses. These reports address the two runtime checks; this auditor did not inspect runtime payloads, candidate outputs, answer keys, or scores.

This final verification read only judge-rubric-v2.txt. It appends to the original audit without rewriting it. No inference was run and no additional rubric changes are proposed.
