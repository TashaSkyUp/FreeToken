# Independent blind audit of the revised prompts

**No remaining material prompt issues require a fix before the full rerun.** All 100 current user turns were reviewed: 0 material findings, 4 optional minor refinements, and 96 prompts with no further change proposed. This conclusion concerns prompt specificity; it does not verify unseen answer keys, scoring implementation, model behavior, or results.

File audited: revised-prompts-blind.json.

```text
SHA-256: a30521be0c8695968e27eecdbc2b78f19baac0ec65a22833b9acbac2a339ae92
```

The hash identifies the exact file reviewed. The initial all-100 revised review was followed by a targeted review of the six changed prompts, IDs 9, 29, 54, 67, 68, and 89. Comparison with the authorized first revised blind manifest confirmed that these were the only intervening changes. Only the original blind manifests and authorized revised blind manifests were consulted. No outputs, keys, scores, prior results, repository implementation, or external sources were accessed. No benchmark inference was run.

## Fixes confirmed

- ID 9 now presents valid multiline Python, removing a competing syntax-error diagnosis.
- ID 29 again asks the mass word problem without supplying its algebraic formulation.
- ID 54 no longer adds a separate nondeterminism-limitations question.
- ID 67 no longer supplies the four steps the model is asked to produce.
- ID 68 specifies a software operation that can change stored state. This sets the domain without giving the definition or suggesting that identical return values define idempotence.
- ID 89 no longer adds a latency-versus-throughput comparison.
- ID 17 uses output placeholders instead of the original concrete numerical candidate.

## Optional refinements

| ID | Finding |
| --- | --- |
| 11 | Optional precision refinement: the prompt explicitly forbids intermediate rounding and leaves final precision implicit. If literal exact-decimal scoring is intended, explicitly forbid final rounding too. Equivalent exact numeric formatting should remain acceptable. |
| 82 | Optional experimental-control refinement: the same-prompt comparison does not explicitly hold model weights, numerical precision, and decoding settings fixed. The intended paired comparison is apparent, and diagnostic selection remains the model's task. |
| 85 | Optional difficulty-preservation refinement: stable-key reuse and server-side deduplication supply part of the mechanism that the original question asked the model to explain. The task remains coherent and scorable. |
| 90 | Optional difficulty-preservation refinement: the final counter outcome is supplied along with the necessary non-atomic execution model. The interleaving and prevention method still must be produced. |

Full optional wording appears in the JSON. These points do not block the rerun. The task owner has accepted the reviewed hash with no further edits: ID 11 permits mathematically equivalent final formatting, ID 82 leaves diagnostic selection open, and IDs 85 and 90 retain their domain tasks with explicit assumptions. These choices are compatible with this report's absence of material findings.

## Data preservation and feasibility

Every inventory data line in IDs 91–99 and every one of the 500 record lines in ID 100 matches the original complete blind manifest verbatim. Inventory sizes remain 40, 65, 90, 140, 200, 260, 320, 390, and 470. Each inventory has valid JSON records with the intended fields and scalar types, unique codes, and exactly one occurrence of the requested code. All instruction boundaries and representative samples were inspected, with structural checks across all entries.

ID 100 contains record numbers 0000 through 0499 exactly once, and all supplied records satisfy the formulas printed in the prompt. Its requested record occurs once. No lookup values are reproduced in this report. ID 50 retains its original payload code point for code point, including decomposed e followed by U+0301. No unintended task-data mutation was found.

The current output contracts are feasible. More explicit language, line, sentence, and word limits clarify presentation rather than add substantive questions. The chosen YAML schema and 5-7-5 haiku convention are explicit. ID 76 permits restoration or recovery of old photographs; the rubric should accept both.

## Scoring boundaries

Explanations, translations, diagnostic proposals, rewriting, and creative writing still require semantic rubrics. Parse structured formats rather than comparing incidental whitespace or JSON object-key order. Test code by its specified behavior and accept equivalent valid SQL. Enforce only presentation constraints stated in the prompt.

Use the specified whitespace-based word counts. Sentence checks should handle language-specific punctuation and abbreviations such as a.m.; haiku checks should allow common pronunciation variants. A raw code-point check is now justified for ID 50 because that policy is explicit. These recommendations do not substitute for the independent answer-key review.

## Complete coverage

| Severity | Count | IDs |
| --- | --- | --- |
| material | 0 | None |
| minor | 4 | 11, 82, 85, 90 |
| none | 96 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 83, 84, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100 |

blind-revised-audit.json contains all 100 IDs, severity, issue, full suggested change, and the reviewed manifest hash. A null suggested_change means no edit is proposed. No prompt manifest was edited by this auditor.
