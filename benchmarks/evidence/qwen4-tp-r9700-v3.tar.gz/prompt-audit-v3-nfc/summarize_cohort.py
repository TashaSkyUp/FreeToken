"""Build a complete, inspectable result catalog from the frozen four-way run."""

import hashlib
import html
import json
import re
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'inference'
helpers = runpy.run_path(str(ROOT.parent/'validation100/analyze.py'))
performance, distribution = helpers['performance'], helpers['distribution']
check = runpy.run_path(str(ROOT/'scoring_v3.py'))['check_answer']
assert json.loads((OUT/'state.json').read_text())['stage'] == 'complete'
prompts = json.loads((ROOT/'prompts.json').read_text())
by_name = {p['name']:p for p in prompts}
labels = ['v1-tp1', 'v1-tp2', 'v2-tp1', 'v2-tp2']
rows = {label: [json.loads(line) for line in (OUT/f'{label}-responses.jsonl').read_text().splitlines()]
        for label in labels}
core = {label: {row['name']: row for row in values if row['kind'] == 'core'}
        for label, values in rows.items()}
assert all(len(values) == 110 for values in rows.values())
common = [p['name'] for p in prompts if p['category'] != 'long-context' and
          len({(core[label][p['name']]['text'], core[label][p['name']]['finish_reason'],
                core[label][p['name']]['usage']['completion_tokens']) for label in labels}) == 1]
configurations, failures = {}, []
for label in labels:
    data = list(core[label].values())
    repeats = [row for row in rows[label] if row['kind'] == 'cache-repeat']
    fixed = [dict(name=p['name'], passed=check(p, core[label][p['name']]['text']))
             for p in prompts if p['expected'] is not None]
    failures.extend(dict(configuration=label, name=p['name'], index=p['index'],
                         category=p['category'], prompt=p['user_text'], expected=p['expected'],
                         actual=core[label][p['name']]['text'],
                         completion_tokens=core[label][p['name']]['usage']['completion_tokens'],
                         finish_reason=core[label][p['name']]['finish_reason'])
                    for p in prompts if p['expected'] is not None and
                    not check(p, core[label][p['name']]['text']))
    settings = json.loads((OUT/f'{label}-settings.json').read_text())
    configs = json.loads((OUT/f'{label}-summary.json').read_text())
    cache_matches = re.findall(r'resolved moe_cache_size=(\d+) num_pages=(\d+)',
                              (OUT/f'{label}-server.log').read_text())
    assert len(cache_matches) == 1
    slots, pages = map(int, cache_matches[0])
    configurations[label] = dict(
        core_responses=len(data), cache_repeat_attempts=len(repeats),
        fixed_checks=len(fixed), fixed_passes=sum(item['passed'] for item in fixed),
        fixed_failures=[item['name'] for item in fixed if not item['passed']],
        capped_core=sum(row['finish_reason'] == 'length' for row in data),
        capped_all=sum(row['finish_reason'] == 'length' for row in rows[label]),
        max_completion_tokens=max(row['usage']['completion_tokens'] for row in rows[label]),
        completion_tokens=sum(row['usage']['completion_tokens'] for row in rows[label]),
        cache_hits=sum(row['cache_n'] > 0 for row in repeats),
        cache_fixed_checks=sum(by_name[row['name']]['expected'] is not None for row in repeats),
        cache_fixed_passes=sum(check(by_name[row['name']], row['text'])
                               for row in repeats if by_name[row['name']]['expected'] is not None),
        cold_repeat_exact_matches=sum(row['text'] == core[label][row['name']]['text'] for row in repeats),
        cold_repeat_exact_or_json_value_matches=sum(
            row['text'] == core[label][row['name']]['text'] or
            helpers['json_equal'](row['text'], core[label][row['name']]['text']) is True
            for row in repeats),
        startup_to_healthy_seconds=configs['ready_seconds'],
        expert_slots_per_rank=slots, kv_pages=pages,
        short_uncached=performance([row for row in data if row['category'] != 'long-context']),
        long_uncached=performance([row for row in data if row['category'] == 'long-context']),
        cache_hit_requests=performance([row for row in repeats if row['cache_n'] > 0]),
        same_outputs_all_four=performance([core[label][name] for name in common]),
        all_core_uncached=all(row['cache_n'] == 0 for row in data),
        inference_source_sha=settings['main_sha'])

paired_time_cost = {}
for tp in [1, 2]:
    a, b = core[f'v1-tp{tp}'], core[f'v2-tp{tp}']
    paired_time_cost[f'tp{tp}'] = dict(
        identical_output_requests=len(common),
        response_percent=distribution([100*(b[name]['wall_seconds']/a[name]['wall_seconds']-1)
                                       for name in common]),
        ttft_percent=distribution([100*(b[name]['ttft_seconds']/a[name]['ttft_seconds']-1)
                                   for name in common]),
        decode_ms_per_token_percent=distribution([
            100*(b[name]['timings']['predicted_per_token_ms']/a[name]['timings']['predicted_per_token_ms']-1)
            for name in common if a[name]['usage']['completion_tokens'] > 1]))

service = [json.loads(line) for line in (OUT/'service-observations.jsonl').read_text().splitlines()]
resource = [json.loads(line) for line in (OUT/'resource-timeline.jsonl').read_text().splitlines()]
memory_by_label = {}
for label in labels:
    samples = [item for item in resource if item['state'].get('label') == label]
    memory_by_label[label] = dict(
        samples=len(samples), ram_available_GiB=distribution([item['memory']['MemAvailable']/2**30 for item in samples]),
        host_cpu_cores=distribution([item['server'].get('cpu_cores_used_interval') for item in samples]),
        process_rss_GiB=distribution([item['server']['rss_bytes']/2**30 for item in samples]))

comparisons = {}
for name, left, right in [('v1-cross-tp', 'v1-tp1', 'v1-tp2'),
                          ('v2-cross-tp', 'v2-tp1', 'v2-tp2'),
                          ('tp1-profile', 'v1-tp1', 'v2-tp1')]:
    different = [p['name'] for p in prompts if core[left][p['name']]['text'] != core[right][p['name']]['text']]
    comparisons[name] = dict(left=left, right=right, exact_matches=100-len(different),
                             differing_names=different)

report = dict(utc=datetime.now(timezone.utc).isoformat(), distinct_prompts=100,
              inference_responses=440, configurations=configurations, comparisons=comparisons,
              same_outputs_all_four_short=common, paired_v2_time_cost_percent=paired_time_cost,
              resource_summary=memory_by_label,
              service_observations=dict(samples=len(service),
                  busy_samples=sum(bool(item.get('comfy_running') or item.get('comfy_pending')) for item in service),
                  observation_errors=sum('observation_error' in item for item in service)),
              historical_unicode_correction='The earlier NFD exact-copy expectation was invalid under NFC tokenizer input. Preserve historical 35/42 and 34/42 reports with correction; valid-case denominators are 35/41 and 34/41. The new cohort corrects that input and key and retains 42 checks.',
              limitations=[
                  'Purpose-built regression set; one sequential pass per configuration.',
                  'Prompts, cap and judging rubric changed; compare precision profiles and TP modes within this revision.',
                  'Identical-output agreement does not establish correctness or general capability.',
                  'Auto expert cache residency differs between TP modes; observed speed includes this effect.',
                  'No timed warmup phase; existing disk and JIT caches are used.',
                  'Per-request decode times are means, not individual inter-token gaps.',
                  'Service observations are sampled; they do not prove absence of every concurrent workload.'])
quality = {}
for label in ['profile-quality', 'tp-quality']:
    path = ROOT/'quality'/label/'terra-max-judgments/summary.json'
    if path.exists():
        judged = json.loads(path.read_text())
        quality[label] = {key: judged[key] for key in ['evaluations', 'distinct_samples', 'all_samples',
            'differing_outputs', 'identical_control_errors', 'max_observed_concurrency',
            'main_run_cli_invocations', 'failed_attempts']}
report['quality'] = quality
(ROOT/'cohort-summary.json').write_text(json.dumps(report, indent=2)+'\n')
(ROOT/'all-fixed-check-failures.json').write_text(json.dumps(failures, ensure_ascii=False, indent=2)+'\n')
escape = html.escape
parts = ['<!doctype html><meta charset="utf-8"><title>Audited1024-token benchmark failures</title>',
         '<style>body{font:16px system-ui;max-width:1100px;margin:40px auto;padding:0 20px;color:#18202a}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f5f7;padding:16px;border-radius:6px}summary{cursor:pointer;padding:10px}details{border-top:1px solid #ccc}code{background:#f3f5f7}</style>',
         '<h1>All fixed-check failures</h1>',
         '<p>Every failed fixed-answer/format check in the four-configuration run. '
         'These are 42 checks per configuration; a pass does not assess every dimension of a response. '
         'Independent blinded judges assess all 100 prompts separately. No output normalization hides failures.</p>']
for p in prompts:
    selected = [failure for failure in failures if failure['name'] == p['name']]
    if not selected:
        continue
    expected_display = p['expected'] if isinstance(p['expected'], str) else json.dumps(p['expected'], ensure_ascii=False, indent=2)
    parts += [f'<details><summary>#{p["index"]} {escape(p["name"])} — {len(selected)} configurations fail</summary>',
              '<h3>Prompt</h3><pre>'+escape(p['user_text'])+'</pre>',
              '<h3>Expected fixed answer</h3><pre>'+escape(expected_display)+'</pre>']
    for label in labels:
        row = core[label][p['name']]
        passed = check(p, row['text'])
        parts += [f'<h3>{label}: {"pass" if passed else "fail"}</h3>',
                  '<p>'+escape(f'{row["usage"]["completion_tokens"]} tokens; finish={row["finish_reason"]}; wall={row["wall_seconds"]:.3f}s')+'</p>',
                  '<pre>'+escape(row['text'])+'</pre>']
    parts.append('</details>')
(ROOT/'all-fixed-check-failures.html').write_text('\n'.join(parts)+'\n')
print(json.dumps(dict(responses=440, matched_short_outputs=len(common),
                     comparisons=comparisons,
                     scores={label:configurations[label]['fixed_passes'] for label in labels},
                     failing_configuration_samples=len(failures), quality_comparisons=list(quality)), indent=2))
