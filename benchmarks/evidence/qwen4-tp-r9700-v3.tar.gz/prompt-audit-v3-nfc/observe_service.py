"""Record concurrent service state and launch environment without changing either."""

import json
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'inference'
observed = set()
while True:
    state = json.loads((OUT/'state.json').read_text())
    row = dict(utc=datetime.now(timezone.utc).isoformat(), state=state)
    try:
        with urllib.request.urlopen('http://127.0.0.1:8188/queue', timeout=3) as response:
            queue = json.load(response)
        row.update(comfy_running=len(queue['queue_running']),
                   comfy_pending=len(queue['queue_pending']))
    except (OSError, ValueError) as error:
        row['observation_error'] = repr(error)
    pid = state.get('server_pid')
    if pid and pid not in observed:
        try:
            pairs = Path(f'/proc/{pid}/environ').read_bytes().split(b'\0')
            env = dict(pair.decode().split('=', 1) for pair in pairs if b'=' in pair)
            selected = {key: value for key, value in env.items()
                        if key in {'ROCM_HOME', 'PYTORCH_ROCM_ARCH', 'HIP_VISIBLE_DEVICES',
                                   'OMP_NUM_THREADS', 'OMP_WAIT_POLICY', 'LD_PRELOAD', 'PYTHONPATH'}
                        or key.startswith('FREETOKEN_')}
            (OUT/f'{state["label"]}-observed-environment.json').write_text(
                json.dumps(dict(pid=pid, utc=row['utc'], environment=selected), indent=2)+'\n')
            observed.add(pid)
        except (OSError, ValueError):
            pass
    with (OUT/'service-observations.jsonl').open('a') as output:
        output.write(json.dumps(row)+'\n')
    if state['stage'] in {'complete', 'failed'}:
        break
    time.sleep(15)
