# Blind encoded-prompt audit

Reviewed all **100** exact user turns in `actual-user-turns-blind.json`. This audit used only that manifest; no answer keys, earlier audits, experiment outcomes, external services, or model runs were consulted. Prompt manifests were not edited.

| Severity | Count |
| --- | ---: |
| none | 97 |
| minor — optional refinement | 2 |
| material | 1 |

## Material blocker

**100 — long-context-anchor:** the supplied formulas determine every requested field from the target record index, allowing the lookup to be bypassed. Replace the formula-validation follow-up with structural validation: record IDs 0000–0499 appear exactly once, and all three values are nonnegative integers. Preserve the inventory and requested record. Exact proposed wording is in the JSON report.

No other material blocker was found. The task boundaries and output requirements are mutually compatible; no further material missing assumption or unnecessary difficulty was identified.

## Optional refinements

- **11 — tank-anchor:** explicitly forbid rounding the final amount as well as intermediate values.
- **16 — weighted-average:** constrain the numeric spelling only if literal output matching requires it; the current wording permits equivalent integer/decimal spellings.

These are minor wording refinements and do not block reruns.

## Coverage and format checks

All 100 instruction boundaries were read in full. Long inventories were sampled. Structural checks on the same manifest confirmed that each requested code in IDs 91–99 occurs once, integer fields are integers, and ID 100 contains unique consecutive record IDs 0000–0499. All 100 user-turn strings are NFC; the Unicode-copy payload uses precomposed accents. The delimiter, literal-tab, JSON-escaping, and mixed-language preservation instructions are clear. The per-prompt JSON records cover every ID from 1 through 100 and separate optional refinements from the material issue.

Reviewed manifest SHA256: `854f8b2ab72e0b7ef43ec2c9d370018476aa9a6bd4f5df12c8c02538d162d327`

## Final verification

Verified the two-prompt delta against `audit-input-before-final-fixes/actual-user-turns-blind.json`. Only `user_text` in IDs **11** and **100** changed; the other 98 prompts are unchanged.

- **11:** final rounding is now explicitly forbidden; resolved.
- **100:** generative formulas are removed and replaced with structural validation of unique IDs 0000–0499 and nonnegative integer fields; resolved. Inventory data and requested record are unchanged.

**No material issue remains across the 100 prompts**, based on the original audit plus this delta verification. ID 16 retains the accepted numeric-answer contract allowing equivalent spellings. The original findings above are preserved as historical findings.

Baseline manifest SHA256: `854f8b2ab72e0b7ef43ec2c9d370018476aa9a6bd4f5df12c8c02538d162d327`

Final manifest SHA256: `008c85a8b27c24b2dd163b6f29f284d7f771ef4e45c6f0f9fa05111f2045dbbc`
