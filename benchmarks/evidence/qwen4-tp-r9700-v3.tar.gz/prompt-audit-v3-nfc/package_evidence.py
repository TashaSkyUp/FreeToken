"""Archive the complete audited cohort and reproducible scratch harnesses."""

import gzip
import hashlib
import io
import json
import platform
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parent
TREE = Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-pr')
SOURCE = Path('/root/experiments/FreeToken/.worktrees/qwen4-tp-fp64')
assert json.loads((ROOT/'pipeline-state.json').read_text())['stage'] == 'complete'
assert len(json.loads((ROOT/'cohort-summary.json').read_text())['quality']) == 2
payload = {}

def add(name, path):
    path = Path(path)
    assert path.is_file(), path
    data = path.read_bytes()
    assert name not in payload or payload[name] == data
    payload[name] = data

for path in sorted(ROOT.rglob('*')):
    if not path.is_file() or path.suffix not in {'.py', '.json', '.jsonl', '.csv', '.log', '.md', '.txt', '.html'}:
        continue
    rel = path.relative_to(ROOT)
    if '__pycache__' in rel.parts or path.name in {'archive-verification.json', 'WORK_STATE.json'}:
        continue
    if 'quality' in rel.parts and path.name in {'events.jsonl', 'stderr.log'}:
        continue
    add(str(Path(ROOT.name)/rel), path)

for name in ['run.py', 'analyze.py', 'monitor.py']:
    add('validation100/'+name, REPRO/'validation100'/name)
add('pr-draft/benchmark.py', REPRO/'pr-draft/benchmark.py')
add('historical-environment.json', REPRO/'environment.json')
add('checkpoint.json', REPRO/'checkpoint.json')
add('activate-rocm.sh', REPRO.parent/'activate-rocm.sh')
add('divergence-v2/validation100-fp64/prompts.json', REPRO/'divergence-v2/validation100-fp64/prompts.json')
add('prompt-audit-v3/prompts.json', REPRO/'prompt-audit-v3/prompts.json')
add('prompt-audit-v3/attempt-stopped-for-tokenizer-audit.json', REPRO/'prompt-audit-v3/attempt-stopped-for-tokenizer-audit.json')
add('reasoning-budget-audit/configuration-audit.json', REPRO/'reasoning-budget-audit/configuration-audit.json')
add('reasoning-budget-audit/comparison.json', REPRO/'reasoning-budget-audit/comparison.json')
add('docs/qwen4-exp-tp-r9700.md', TREE/'docs/qwen4-exp-tp-r9700.md')

actual = {str(path.relative_to(SOURCE)): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in sorted((SOURCE/'python/freetoken').rglob('*.py'))}
for label in ['v1-tp1', 'v1-tp2', 'v2-tp1', 'v2-tp2']:
    settings = json.loads((ROOT/'inference'/f'{label}-settings.json').read_text())
    assert settings['source_hashes'] == actual
payload[ROOT.name+'/final-source-verification.json'] = (json.dumps(dict(
    head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip(),
    verified_files=len(actual), hashes=actual), indent=2)+'\n').encode()

library_paths = [REPRO/'rccl/librccl.so',
    Path('/root/experiments/FreeToken/.venv/lib/python3.12/site-packages/torch/lib/libamdhip64.so')]
library_paths.extend(sorted((SOURCE/'python/freetoken/kernel').rglob('*.so')))
libraries = []
for path in library_paths:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(8*1024*1024), b''):
            digest.update(chunk)
    libraries.append(dict(path=str(path), resolved=str(path.resolve()),
                          bytes=path.stat().st_size, sha256=digest.hexdigest()))
payload[ROOT.name+'/runtime-library-hashes.json'] = (json.dumps(dict(
    python=platform.python_version(), kernel=platform.release(), libraries=libraries), indent=2)+'\n').encode()
payload['README.txt'] = b'''Audited Qwen3.8-Flash-Next NVFP4 tensor-parallel evidence, v3.

Read docs/qwen4-exp-tp-r9700.md and prompt-audit-v3-nfc/cohort-summary.json.
The new cohort has100 prompts, four configurations (five/seven flags x TP1/TP2),
10 cache repeats each, and440 inference responses. All have max_tokens1024 and
thinking disabled. Prompt specificity, actual tokenized input, answer-key and
judge-rubric audits are retained. The Unicode key correction is explicit.

The two quality directories contain200 accepted judgments each:100 forward,
then100 with both submission and A/B order reversed. Codex CLI uses
gpt-6.1-terra/max, at most20 concurrent. Profile-quality aliases refer to two
arithmetic profiles, both actual TP1. TP-quality compares V2 TP1 against V2 TP2.
Invocations, final judgments and retries are retained. Raw Codex CLI events,
hidden reasoning, authentication, native binaries and model weights are omitted.

The earlier NFC-invalid attempt is preserved locally and represented here by
its stop record and original frozen inputs; its responses are not in the new
cohort. A separate launch failure before any response is retained under
failed-startup-missing-rocm-activation. The69 existing tests ran earlier in the
same task on identical engine source; copied logs record their real commands.

Scripts are workspace-specific scratch harnesses, not maintained project tests.
The original execution root was
/root/experiments/FreeToken/.local-build/qwen38-repro/prompt-audit-v3-nfc.
Source the local activate-rocm.sh environment (ROCM_HOME=/opt/rocm-7.2.3), then
run run_inference.py and postprocess.py. Adjust local model/library/worktree
paths elsewhere. Frozen input and result files refuse accidental overwrites.
The dependency helpers are retained at their original relative paths.

SSE text chunk times preserve client delivery observations. A chunk may contain
partial or multiple tokens; chunk gaps are not individual GPU token times.
Startup/model load, cold-prefix request latency and cache-hit latency are kept
separate. One sequential pass and automatic expert cache sizing limit inference
about general speed or pure TP communication scaling.

MANIFEST.json hashes every other archive member; it does not hash itself.
'''
payload['README.txt'] = payload['README.txt'].replace(b'has100',b'has 100').replace(b'and440',b'and 440').replace(b'max_tokens1024',b'max_tokens=1024').replace(b'contain200',b'contain 200').replace(b'each:100',b'each: 100').replace(b'then100',b'then 100').replace(b'most20',b'most 20').replace(b'The69',b'The 69')
manifest = {name:dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            for name,data in sorted(payload.items())}
payload['MANIFEST.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
target = TREE/'benchmarks/evidence/qwen4-tp-r9700-v3.tar.gz'
with target.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(mode='w', fileobj=zipped) as archive:
            for name,data in sorted(payload.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o644, 0
                archive.addfile(member, io.BytesIO(data))
with tarfile.open(target, 'r:gz') as archive:
    assert set(archive.getnames()) == set(payload)
    for name,info in manifest.items():
        data = archive.extractfile(name).read()
        assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256']
result = dict(path=str(target), bytes=target.stat().st_size,
              sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
              hashed_payload_members=len(manifest), source_files_verified=len(actual))
(ROOT/'archive-verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
