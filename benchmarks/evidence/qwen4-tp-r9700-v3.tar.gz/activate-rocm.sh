export ROCM_HOME=/opt/rocm-7.2.3
export PATH="$ROCM_HOME/bin:$PATH"
export PYTORCH_ROCM_ARCH=gfx1201
export FREETOKEN_ROCM_ARCH=gfx1201
export OMP_WAIT_POLICY=PASSIVE
source /root/experiments/FreeToken/.venv/bin/activate
